using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;

namespace PipeModels;

public class YmlSerialize<T>
{
    public T Source { get; set; }
    public string FilePath { get; set; }
    private string serializedYaml; // Ее сохраняем
    private string loadedString; // Считывем сохраненное
    public T? DeSerialized { get; set; }

    public YmlSerialize(T ssource, string filePath)
    {
        this.Source = ssource;
        this.FilePath = filePath;
    }

    public void DoSerialize()
    {
        //this.serializedJson = JsonSerializer.Serialize(this.Source);
        var yamlSerializer = new SerializerBuilder()
            .WithNamingConvention(CamelCaseNamingConvention.Instance)
            .Build();
        this.serializedYaml = yamlSerializer.Serialize(this.Source);
    }

    public void DoSave()
    {
        if (this.serializedYaml != null)
            File.WriteAllText(this.FilePath, this.serializedYaml);
        else {;}
    }

    public void DoRead()
    {
        using (Stream stream = new FileStream(this.FilePath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
        {
            if (File.Exists(this.FilePath) && stream.Length > 0)
                using (StreamReader reader = new StreamReader(stream))
                    this.loadedString = reader.ReadToEnd();
            else {;}
        }
    }
    // public void DoDeserialize()
    // {
    //     if ((this.loadedString != null) && (this.loadedString.Length > 0))
    //     {
    //         this.DeSerialized = JsonSerializer.Deserialize<T>(this.loadedString);
    //     }
    //     else {; }
    // }
}
