using PipeModels;
using System.Text.Json;
using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;

Model mSocrBase = new Model
{
    Name = "socrBase1",
    FlowName = "socrBase1Flow",
    SelectSql = """
        SELECT
            [LEVEL],
            [SCNAME],
            [SOCRNAME],
            CAST([KOD_T_ST] AS INT)
        FROM
            [dbo].[SOCRBASE];
        """,
    ParamNames = new string[4] { "first", "second", "third", "fourth" }
};

List<Model> lml1 = new List<Model>();
lml1.Add(mSocrBase);

Flow fSocrBase = new Flow
{
    Name = "socrBase1Flow",
    Models = lml1
};

Job jSocrBase = new Job()
{
    Name = "socrBase1Job",
    JobFlow = fSocrBase
};
// ------------------------------------

Model mAltNames = new Model
{
    Name = "altNames1",
    FlowName = "altNames1Flow",
    SelectSql = """
        SELECT
            TRIM([OLDCODE]),
            TRIM([NEWCODE]),
            [LEVEL]
        FROM
            [dbo].[ALTNAMES];
    """,
    ParamNames = new string[4] { "first", "second", "third", "fourth" }
};

List<Model> lml2 = new List<Model>();
lml2.Add(mAltNames);

Flow fAltNames = new Flow
{
    Name = "altNames1Flow",
    Models = lml2
};

Job jAltNames = new Job
{
    Name = "antNames1Job",
    JobFlow = fAltNames
};


string jsonFilePath = Path.Join(Directory.GetCurrentDirectory(), "test1.json");
JsSerialize<Job> js = new JsSerialize<Job>(jSocrBase, jsonFilePath);
js.DoSerialize();
js.DoSave();
js.DoRead();
js.DoDeserialize();
Job jss = js.DeSerialized;
string postJson = JsonSerializer.Serialize(jss);
string jsonFilePath2 = Path.Join(Directory.GetCurrentDirectory(), "test2.json");
File.WriteAllText(jsonFilePath2, postJson);

string yamlFilePath = Path.Join(Directory.GetCurrentDirectory(), "test1.yaml");
YmlSerialize<Job> yml = new YmlSerialize<Job>(jSocrBase, yamlFilePath);
yml.DoSerialize();
yml.DoSave();
yml.DoRead();