using System.Text.Json;

namespace PipeModels;

public class JsSerialize<T>
{
    public T Source { get; set; }
    public string FilePath { get; set; }
    private string serializedJson; // Ее сохраняем
    private string loadedString; // Считывем сохраненное
    public T? DeSerialized { get; set; }
    
    public JsSerialize(T ssource, string filePath)
    {
        this.Source = ssource;
        this.FilePath = filePath;
    }

    public void DoSerialize() => this.serializedJson = JsonSerializer.Serialize(this.Source);

    public void DoSave()
    {
        if (this.serializedJson != null)
            File.WriteAllText(this.FilePath, this.serializedJson);
        else {;}
    }

    public void DoRead()
    {
        using (Stream stream = new FileStream(this.FilePath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
        {
            if (File.Exists(this.FilePath) && stream.Length > 0)
                using (StreamReader reader = new StreamReader(stream))
                    this.loadedString = reader.ReadToEnd();
            else {;}
        }
    }
    public void DoDeserialize()
    {
        if ((this.loadedString != null) && (this.loadedString.Length > 0))
        {
            this.DeSerialized = JsonSerializer.Deserialize<T>(this.loadedString);
        }
        else {;}
    }
}
