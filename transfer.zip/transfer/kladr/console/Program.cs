using CommandLine;
using Options;
using Import.kladr.mssql;
using Import.kladr.pgsql;
using ImportGar.mssql;
using ImportGar.pgsql;
using Shared;
using static Shared.MyLogger;
//--------------

// TODO:
// import.basePqSql выровнять с baseMsSql.
// garMsSql доделать импорт справочников - xmlUtils, OneImport=>OneFile... ревью
// garMsSql xmlUtils -> логгинг ошибок импорта из mssql, конвертации
// garPgSql masters OneOmport=>OneFile Facts=> Batch (2-й вариант)
// gar Masters vs Facts.... Naming, Options, dbObjects

// using cli -> use for kladr
// using cli -> use for gar
// mvc make simple repository class (SocrBase)
// common objects to shared = folders ??
// rework logging entries
// kladr 2,3 steps after import aka dbt => etl
// kladr jobs => etl
// model pipeline ondisk-stru, deserialize into class => etl
// socrbase, altnames, nmaps into steps raw vs stage vs ods shemas gar vs kladr dbs

// Backlog
// gar - xsd files to stru ->
// gar import - validate xml by schema
//      https://learn.microsoft.com/ru-ru/dotnet/standard/linq/validate-xsd
//      https://www.c-sharpcorner.com/article/how-to-validate-xml-using-xsd-in-c-sharp/

GeoType gtp = 0;
TargetDb tdb = 0;
List<string> kladrObjectList = new List<string>();
string[] allKladrObjects = new string[] { "SocrBase", "AltNames", "Kladr", "Street", "Doma", "NameMap" };
List<string> garObjectList = new List<string>();
string[] allGarObjects = new string[] {
    "AddHouseTypes", "AddrObjTypes", "AppartmentTypes", "HouseTypes",
    "NormativeDocsKinds", "NormativeDocsTypes",
    "ObjectLevels", "OperationTypes", "ParamTypes", "RoomTypes",
    "AddrObj", "AddrObjDivision", "AddrObjParams", "AdmHierarchy", "Apartments",
    "ApartmentsParams", "CarPlaces", "CarPlacesParams", "ChangeHistory", "Houses",
    "HousesParams", "MunHierarchy", "NormativeDocs", "ReestrObjects", "Rooms",
    "RoomsParams", "Steads", "SteadsParams"
};

Parser.Default.ParseArguments<CliOptions>(args)
    .WithParsed<CliOptions>(o =>
        {
            if (o.GeoType.ToLower().Equals("kladr"))
            {
                gtp = GeoType.kladr; // dotnet run -- --geotype kladr --objects kladr socrbase --targetdb mssql

                string[] allKladrObjectsLowercase = new string[allKladrObjects.Length];
                for (int i = 0; i < allKladrObjects.Length; i++)
                    allKladrObjectsLowercase[i] = allKladrObjects[i].ToLower();
                foreach (var s in o.Objects)
                {
                    int i = Array.IndexOf(allKladrObjectsLowercase, s.ToLower());
                    if (i >= 0)
                    {
                        if (!kladrObjectList.Contains<string>(s))
                            kladrObjectList.Add(allKladrObjects[i].ToLower());
                    }
                }
            }
            else if (o.GeoType.ToLower().Equals("gar"))
            {
                gtp = GeoType.gar; // dotnet run -- --geotype gar --targetdb pgsql

                string[] allGarObjectsLowercase = new string[allGarObjects.Length];
                for (int i = 0; i < allKladrObjects.Length; i++)
                    allGarObjectsLowercase[i] = allGarObjects[i].ToLower();
                foreach (var s in o.Objects)
                {
                    int i = Array.IndexOf(allGarObjectsLowercase, s.ToLower());
                    if (i >= 0)
                    {
                        if (!garObjectList.Contains<string>(s))
                            garObjectList.Add(allGarObjects[i]);
                    }
                }
            }

            if (o.TargetDb.ToLower().Trim().Equals("mssql"))
            {
                tdb = TargetDb.mssql;
            }
            else if (o.TargetDb.ToLower().Trim().Equals("pgsql"))
            {
                tdb = TargetDb.pgsql;
            }
        }
    );

InitLogger();
Log.Information("Классификатор: {geotype}", gtp);
Log.Information("Целевая БД: {targetDb}", tdb);

if (gtp == GeoType.kladr)
    foreach (var s in kladrObjectList)
        Log.Information("Объект: {kladrObjects}", s.ToString());

// if (gtp == GeoType.gar)
//     Log.Information("Объекты: {garObjects}", garObjectList.ToString());

string kladrSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "my_dev", "files", "kladr");
//string kladrSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "dotNetProjects", "files", "kladr");
//string garSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "dotNetProjects", "files", "gar");
string garSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "my_dev", "files", "gar");

string MsSqlConnectionString = ConnectionString.GetConnectionString(TargetDb.mssql);
string PgSqlConnectionString = ConnectionString.GetConnectionString(TargetDb.pgsql);

ImportKladr(TargetDb.pgsql);
//ImportGar(TargetDb.pgsql);
// dotnet run -- --geotype kladr --objects kladr socrbase --targetdb pgsql
void ImportKladr(TargetDb tdb = TargetDb.mssql)
{
    DateTime StartDt = DateTime.Now;
    Log.Debug("StartDt: {dt}", StartDt);

    switch (tdb)
    {
        case TargetDb.mssql:
            Log.Information("Импорт DBF => Ms SQL");
            DoImportMsSql.ConnectionString = MsSqlConnectionString;
            DoImportMsSql.SourceDirPath = kladrSourceDirPath;
            DoImportMsSql.DoImportSynch();
            break;
        case TargetDb.pgsql:
            Log.Information("Импорт DBF => PG DB");
            DoImportPgSql.ConnectionString = PgSqlConnectionString;
            DoImportPgSql.SourceDirPath = kladrSourceDirPath;
            DoImportPgSql.DoImportParallel();
            break;
    }

    DateTime FinishDt = DateTime.Now;
    TimeSpan Duration = FinishDt - StartDt;
    Log.Information("Обработка завершена в {finishDt}, продолжительность {Duration}", FinishDt, Duration);
}

void ImportGar(TargetDb tdb = TargetDb.mssql)
{
    DateTime StartDt = DateTime.Now;
    Log.Debug("StartDt: {dt}", StartDt);

    switch (tdb)
    {
        case TargetDb.mssql:
            Log.Information("Импорт XML => MS SQL");
            ImportGarToMsSql impMsSql = new ImportGarToMsSql(garSourceDirPath);
            impMsSql.DoImport(MsSqlConnectionString);
            break;
        case TargetDb.pgsql:
            Log.Information("Импорт XML => PG DB");
            ImportGarToPgSql impPgSql = new ImportGarToPgSql(garSourceDirPath);
            impPgSql.DoImport(PgSqlConnectionString);
            impPgSql.DoImportFacts(PgSqlConnectionString);
            break;
    }

    DateTime FinishDt = DateTime.Now;
    TimeSpan Duration = FinishDt - StartDt;
    Log.Information("Обработка завершена в {finishDt}, продолжительность {Duration}", FinishDt, Duration);
}