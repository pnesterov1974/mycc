using CommandLine;
using Options;
using ImportKladr.mssql;
using ImportKladr.pgsql;
using ImportGar.mssql;
using ImportGar.pgsql;
using Shared;
using Shared.Transformations.mssql;
using Shared.Transformations.pqsql;
using static Shared.MyLogger;
using Data.mesh.pgsql;
using System.Data;

//--------------

// TODO:

// SourceConnection vs DestConnection. Concept  Read and Write in datamesh
// Clean MsSql Reader
// gar - xsd files to stru ->
// gar import - validate xml by schema
//      https://learn.microsoft.com/ru-ru/dotnet/standard/linq/validate-xsd
//      https://www.c-sharpcorner.com/article/how-to-validate-xml-using-xsd-in-c-sharp/
// gar import facts pgsql -> mssql
// using cli -> use for kladr
// using cli -> use for gar
// using cli -- list of accessable values in cli model
// mvc make simple repository class (SocrBase)
// common objects to shared = folders ??
// rework logging entries
// kladr 2,3 steps after import aka dbt.
// kladr jobs
// model pipeline ondisk-stru, deserialize into class
// kladr async...
// socrbase, altnames, nmaps into steps raw vs stage vs ods shemas gar vs kladr dbs

GeoType gtp = 0;
TargetDb tdb = 0;
List<string> kladrObjectList = new List<string>();
string[] allKladrObjects = new string[] { "SocrBase", "AltNames", "Kladr", "Street", "Doma", "NameMap" };
List<string> garObjectList = new List<string>();
string[] allGarObjects = new string[] {
    "AddHouseTypes", "AddrObjTypes", "AppartmentTypes", "HouseTypes", "NormativeDocsKinds", "NormativeDocsTypes",
    "ObjectLevels", "OperationTypes", "ParamTypes", "RoomTypes",
    "AddrObj", "AddrObjDivision", "AddrObjParams", "AdmHierarchy", "Apartments",
    "ApartmentsParams", "CarPlaces", "CarPlacesParams", "ChangeHistory", "Houses",
    "HousesParams", "MunHierarchy", "NormativeDocs", "ReestrObjects", "Rooms",
    "RoomsParams", "Steads", "SteadsParams"
};

Parser.Default.ParseArguments<CliOptions>(args)
    .WithParsed<CliOptions>(o =>
        {
            if (o.GeoType.ToLower().Equals("kladr"))
            {
                gtp = GeoType.kladr; // dotnet run -- --geotype kladr --objects kladr socrbase --targetdb mssql

                string[] allKladrObjectsLowercase = new string[allKladrObjects.Length];
                for (int i = 0; i < allKladrObjects.Length; i++)
                    allKladrObjectsLowercase[i] = allKladrObjects[i].ToLower();
                foreach (var s in o.Objects)
                {
                    int i = Array.IndexOf(allKladrObjectsLowercase, s.ToLower());
                    if (i >= 0)
                    {
                        if (!kladrObjectList.Contains<string>(s))
                            kladrObjectList.Add(allKladrObjects[i].ToLower());
                    }
                }
            }
            else if (o.GeoType.ToLower().Equals("gar"))
            {
                gtp = GeoType.gar; // dotnet run -- --geotype gar --targetdb pgsql

                string[] allGarObjectsLowercase = new string[allGarObjects.Length];
                for (int i = 0; i < allKladrObjects.Length; i++)
                    allGarObjectsLowercase[i] = allGarObjects[i].ToLower();
                foreach (var s in o.Objects)
                {
                    int i = Array.IndexOf(allGarObjectsLowercase, s.ToLower());
                    if (i >= 0)
                    {
                        if (!garObjectList.Contains<string>(s))
                            garObjectList.Add(allGarObjects[i]);
                    }
                }
            }

            if (o.TargetDb.ToLower().Trim().Equals("mssql"))
            {
                tdb = TargetDb.mssql;
            }
            else if (o.TargetDb.ToLower().Trim().Equals("pgsql"))
            {
                tdb = TargetDb.pgsql;
            }
        }
    );

InitLogger();
Log.Information("Классификатор: {geotype}", gtp);
Log.Information("Целевая БД: {targetDb}", tdb);

if (gtp == GeoType.kladr)
    foreach(var s in kladrObjectList)
        Log.Information("Объект: {kladrObjects}",s.ToString());

// if (gtp == GeoType.gar)
//     Log.Information("Объекты: {garObjects}", garObjectList.ToString());

string kladrSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "my_dev", "files", "kladr");
//string kladrSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "dotNetProjects", "files", "kladr");
//string garSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "dotNetProjects", "files", "gar");
string garSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "my_dev", "files", "gar");

string MsSqlConnectionString = ConnectionString.GetConnectionString(TargetDb.mssql);
string PgSqlConnectionString = ConnectionString.GetConnectionString(TargetDb.pgsql);

//TestMechPgSql();
//ReadJson();
ImportKladr(TargetDb.pgsql);
//ImportGar(TargetDb.pgsql);
//ReadWritePgData();
// dotnet run -- --geotype kladr --objects kladr socrbase --targetdb pgsql
void ImportKladr(TargetDb tdb = TargetDb.mssql)
{
    DateTime StartDt = DateTime.Now;
    Log.Debug("StartDt: {dt}", StartDt);

    switch (tdb)
    {
        case TargetDb.mssql:
            Log.Information("Импорт DBF => Ms SQL");
            ImportKladrToMsSql.DoImport(MsSqlConnectionString, kladrSourceDirPath, kladrObjectList);
            break;
        case TargetDb.pgsql:
            Log.Information("Импорт DBF => PG DB");
            ImportKladrToPgSql.DoImport(PgSqlConnectionString, kladrSourceDirPath, kladrObjectList);
            break;
    }

    DateTime FinishDt = DateTime.Now;
    TimeSpan Duration = FinishDt - StartDt;
    Log.Information("Обработка завершена в {finishDt}, продолжительность {Duration}", FinishDt, Duration);
}

void ImportGar(TargetDb tdb = TargetDb.mssql)
{
    DateTime StartDt = DateTime.Now;
    Log.Debug("StartDt: {dt}", StartDt);

    switch (tdb)
    {
        case TargetDb.mssql:
            Log.Information("Импорт XML => MS SQL");
            ImportGarToMsSql impMsSql = new ImportGarToMsSql(garSourceDirPath);
            impMsSql.DoImport(MsSqlConnectionString);
            break;
        case TargetDb.pgsql:
            Log.Information("Импорт XML => PG DB");
            ImportGarToPgSql impPgSql = new ImportGarToPgSql(garSourceDirPath);
            //impPgSql.DoImport(PgSqlConnectionString);
            impPgSql.DoImportFacts(PgSqlConnectionString);
            break;
    }

    DateTime FinishDt = DateTime.Now;
    TimeSpan Duration = FinishDt - StartDt;
    Log.Information("Обработка завершена в {finishDt}, продолжительность {Duration}", FinishDt, Duration);
}

void ReadWritePgData()
{
    PgSqlData pgRead = new PgSqlData(PgSqlConnectionString, SocrBasePgSql.SQL);
    pgRead.Read();
    DataTable pgd = pgRead.Data;
    //WritePgSqlData pgWrite = new WritePgSqlData(PgSqlConnectionString, "public", "socrbase2", pgd);
                                    //{
                                    //    Data = pgd
                                    //};
    //pgWrite.Write();
}

// void ReadJson()
// {
//     string selectSql = SocrBaseMsSql.SQL;
//     MsSqlData msd = new MsSqlData(MsSqlConnectionString, selectSql);
//     string js = msd.AsJson;
//     Console.WriteLine(js);
// }

// void TestMechMsSql()
// {
//     TransformObjectInfo toiKladr1 = new TransformObjectInfo
//     {
//         TargetSchemaName = Kladr1MsSql.TargetSchemaName,
//         TargetTableName = Kladr1MsSql.TargetTableName,
//         ConnectionString = MsSqlConnectionString,
//         SelectSql = Kladr1MsSql.SQL,

//     };
//     InsertIntoMsSql insKladr1 = new InsertIntoMsSql(toiKladr1);
//     insKladr1.InsertInto();

//     TransformObjectInfo toiStreet1 = new TransformObjectInfo
//     {
//         TargetSchemaName = Street1MsSql.TargetSchemaName,
//         TargetTableName = Street1MsSql.TargetTableName,
//         ConnectionString = MsSqlConnectionString,
//         SelectSql = Street1MsSql.SQL,

//     };
//     InsertIntoMsSql insStreet1 = new InsertIntoMsSql(toiStreet1);
//     insStreet1.InsertInto();

//     TransformObjectInfo toiDoma1 = new TransformObjectInfo
//     {
//         TargetSchemaName = Doma1MsSql.TargetSchemaName,
//         TargetTableName = Doma1MsSql.TargetTableName,
//         ConnectionString = MsSqlConnectionString,
//         SelectSql = Doma1MsSql.SQL,

//     };
//     InsertIntoMsSql insDoma1 = new InsertIntoMsSql(toiDoma1);
//     insDoma1.InsertInto();

// }

void TestMechPgSql()
{
    TransformObjectInfo toiKladr1 = new TransformObjectInfo
    {
        TargetSchemaName = Kladr1PgSql.TargetSchemaName,
        TargetTableName = Kladr1PgSql.TargetTableName,
        ConnectionString = PgSqlConnectionString,
        SelectSql = Kladr1PgSql.SQL
    };
    InsertIntoPgSql inKladr1 = new InsertIntoPgSql(toiKladr1);
    inKladr1.InsertInto();

    TransformObjectInfo toiStreet1 = new TransformObjectInfo
    {
        TargetSchemaName = Street1PgSql.TargetSchemaName,
        TargetTableName = Street1PgSql.TargetTableName,
        ConnectionString = PgSqlConnectionString,
        SelectSql = Street1PgSql.SQL
    };
    InsertIntoPgSql inStreet1 = new InsertIntoPgSql(toiStreet1);
    inStreet1.InsertInto();

    TransformObjectInfo toiDoma1 = new TransformObjectInfo
    {
        TargetSchemaName = Doma1PgSql.TargetSchemaName,
        TargetTableName = Doma1PgSql.TargetTableName,
        ConnectionString = PgSqlConnectionString,
        SelectSql = Doma1PgSql.SQL
    };
    InsertIntoPgSql inDoma1 = new InsertIntoPgSql(toiDoma1);
    inDoma1.InsertInto();
}
