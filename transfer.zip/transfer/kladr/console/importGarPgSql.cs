using Import.gar.pgsql;
using Shared;

namespace ImportGar.pgsql;

public class ImportGarToPgSql: GarSource
{
    public ImportGarToPgSql(string sourceDirPath): base(sourceDirPath) { ; }

    public void DoImport(string connectionString)
    {
        ImportObjectInfo NormativeDocsKinds = new ImportObjectInfo
        {
            TargetTableName = "normative_docs_kinds",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_NORMATIVE_DOCS_KINDS"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportNormativeDocsKinds ndk = new ImportNormativeDocsKinds(NormativeDocsKinds);
        ndk.DoImport();

        ImportObjectInfo AddHouseTypes = new ImportObjectInfo
        {
            TargetTableName = "add_house_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_ADDHOUSE_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportAddHouseTypes aht = new ImportAddHouseTypes(AddHouseTypes);
        aht.DoImport();

        ImportObjectInfo AddrObjTypes = new ImportObjectInfo
        {
            TargetTableName = "addr_obj_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_ADDR_OBJ_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportAddrObjTypes aot = new ImportAddrObjTypes(AddrObjTypes);
        aot.DoImport();

        ImportObjectInfo AppartmentTypes = new ImportObjectInfo
        {
            TargetTableName = "appartment_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_APARTMENT_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportAppartmentTypes apt = new ImportAppartmentTypes(AppartmentTypes);
        apt.DoImport();

        ImportObjectInfo HouseTypes = new ImportObjectInfo
        {
            TargetTableName = "house_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_HOUSE_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportHouseTypes ht = new ImportHouseTypes(HouseTypes);
        ht.DoImport();

        ImportObjectInfo NormativeDocsTypes = new ImportObjectInfo
        {
            TargetTableName = "normative_docs_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_NORMATIVE_DOCS_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportNormativeDocTypes ndt = new ImportNormativeDocTypes(NormativeDocsTypes);
        ndt.DoImport();

        ImportObjectInfo ObjectLevels = new ImportObjectInfo
        {
            TargetTableName = "object_levels",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_OBJECT_LEVELS"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportObjectLevels ol = new ImportObjectLevels(ObjectLevels);
        ol.DoImport();

        ImportObjectInfo OparationTypes = new ImportObjectInfo
        {
            TargetTableName = "operation_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_OPERATION_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportOperationTypes opt = new ImportOperationTypes(OparationTypes);
        opt.DoImport();

        ImportObjectInfo ParamTypes = new ImportObjectInfo
        {
            TargetTableName = "param_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_PARAM_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportParamTypes prt = new ImportParamTypes(ParamTypes);
        prt.DoImport();

        ImportObjectInfo RoomTypes = new ImportObjectInfo
        {
            TargetTableName = "room_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_ROOM_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportRoomTypes rmt = new ImportRoomTypes(RoomTypes);
        rmt.DoImport();
    }

    public void DoImportFacts(string connectionString)
    {
        // ImportObjectsInfo AddrObj = new ImportObjectsInfo
        // {
        //     TargetTableName = "addr_obj",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_ADDR_OBJ"],
        //     ConnectionString = connectionString
        // };
        // ImportAddrObj aobj = new ImportAddrObj(AddrObj);
        // aobj.DoImportData();

        // ImportObjectsInfo AddrObjDivision = new ImportObjectsInfo
        // {
        //     TargetTableName = "addr_obj_division",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_ADDR_OBJ_DIVISION"],
        //     ConnectionString = connectionString
        // };
        // ImportAddrObjDivision aobjd = new ImportAddrObjDivision(AddrObjDivision);
        // aobjd.DoImportData();

        // ImportObjectsInfo AddrObjParams = new ImportObjectsInfo
        // {
        //     TargetTableName = "addr_obj_params",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_ADDR_OBJ_PARAMS"],
        //     ConnectionString = connectionString
        // };
        // ImportAddrObjParams aobjp = new ImportAddrObjParams(AddrObjParams);
        // aobjp.DoImportData();

        // ImportObjectsInfo AdmHierarchy = new ImportObjectsInfo
        // {
        //     TargetTableName = "adm_hierarchy",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_ADM_HIERARCHY"],
        //     ConnectionString = connectionString
        // };
        // ImportAdmHierarchy admh = new ImportAdmHierarchy(AdmHierarchy);
        // admh.DoImportData();

        // ImportObjectsInfo Apartments = new ImportObjectsInfo
        // {
        //     TargetTableName = "apartments",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_APARTMENTS"],
        //     ConnectionString = connectionString
        // };
        //ImportApartments apa = new ImportApartments(Apartments);
        //apa.DoImportData();// ImportObjectsInfo Apartments = new ImportObjectsInfo
        
        // ImportObjectsInfo ApartmentsParams = new ImportObjectsInfo
        // {
        //     TargetTableName = "apartments_params",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_APARTMENTS_PARAMS"],
        //     ConnectionString = connectionString
        // };
        // ImportApartmentsParams apap = new ImportApartmentsParams(ApartmentsParams);
        // apap.DoImportData();

        // ImportObjectsInfo CarPlaces = new ImportObjectsInfo
        // {
        //     TargetTableName = "carplaces",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_CARPLACES"],
        //     ConnectionString = connectionString
        // };
        // ImportCarPlaces carp = new ImportCarPlaces(CarPlaces);
        // carp.DoImportData();

        // ImportObjectsInfo CarPlacesParams = new ImportObjectsInfo
        // {
        //     TargetTableName = "carplaces_params",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_CARPLACES_PARAMS"],
        //     ConnectionString = connectionString
        // };
        // ImportCarPlacesParams carpp = new ImportCarPlacesParams(CarPlacesParams);
        // carpp.DoImportData();

        // ImportObjectsInfo ChangeHistory = new ImportObjectsInfo
        // {
        //     TargetTableName = "change_history",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_CHANGE_HISTORY"],
        //     ConnectionString = connectionString
        // };
        // ImportChangeHistory ch = new ImportChangeHistory(ChangeHistory);
        // ch.DoImportData();

        // ImportObjectsInfo Houses = new ImportObjectsInfo
        // {
        //     TargetTableName = "houses",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_HOUSES"],
        //     ConnectionString = connectionString
        // };
        // ImportHouses h = new ImportHouses(Houses);
        // h.DoImportData();

        // ImportObjectsInfo HousesParams = new ImportObjectsInfo
        // {
        //     TargetTableName = "houses_params",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_HOUSES_PARAMS"],
        //     ConnectionString = connectionString
        // };
        // ImportHousesParams hp = new ImportHousesParams(HousesParams);
        // hp.DoImportData();

        // ImportObjectsInfo MunHierarchy = new ImportObjectsInfo
        // {
        //     TargetTableName = "mun_hierarchy",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_MUN_HIERARCHY"],
        //     ConnectionString = connectionString
        // };
        // ImportMunHierarchy mh = new ImportMunHierarchy(MunHierarchy);
        // mh.DoImportData();

        // ImportObjectsInfo NormativeDocs = new ImportObjectsInfo
        // {
        //     TargetTableName = "normative_docs",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_NORMATIVE_DOCS"],
        //     ConnectionString = connectionString
        // };
        // ImportNormativeDocs nd = new ImportNormativeDocs(NormativeDocs);
        // nd.DoImportData();

        // ImportObjectsInfo ReestrObjects = new ImportObjectsInfo
        // {
        //     TargetTableName = "reestr_objects",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_REESTR_OBJECTS"],
        //     ConnectionString = connectionString
        // };
        // ImportReestrObjects ro = new ImportReestrObjects(ReestrObjects);
        // ro.DoImportData();

        // ImportObjectsInfo Rooms = new ImportObjectsInfo
        // {
        //     TargetTableName = "rooms",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_ROOMS"],
        //     ConnectionString = connectionString
        // };
        // ImportRooms room = new ImportRooms(Rooms);
        // room.DoImportData();

        // ImportObjectsInfo RoomsParams = new ImportObjectsInfo
        // {
        //     TargetTableName = "rooms_params",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_ROOMS_PARAMS"],
        //     ConnectionString = connectionString
        // };
        // ImportRoomsParams rmp = new ImportRoomsParams(RoomsParams);
        // rmp.DoImportData();

        // ImportObjectsInfo Steads = new ImportObjectsInfo
        // {
        //     TargetTableName = "steads",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_STEADS"],
        //     ConnectionString = connectionString
        // };
        // ImportSteads std = new ImportSteads(Steads);
        // std.DoImportData();

        ImportObjectsInfo SteadsParams = new ImportObjectsInfo
        {
            TargetTableName = "steads_params",
            TargetSchemaName = "gar",
            SourceFilePaths = this.Facts["AS_STEADS_PARAMS"],
            ConnectionString = connectionString
        };
        ImportSteadsParams stdp = new ImportSteadsParams(SteadsParams);
        stdp.DoImportData();
    }
}