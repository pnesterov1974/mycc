using Shared;

namespace Import.kladr;

interface IKladrImport
{
    public ImportObjectInfo Ioi { get; set; }
    public void DoImport();
}