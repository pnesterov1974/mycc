namespace Import.gar;
public class NormativeDocsKinds
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
}

public class AddHouseTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? ShortName { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

public class AddrObjTypes
{
    public int Id { get; set; }
    public int Level { get; set; }
    public string Name { get; set; } = string.Empty;
    public string ShortName { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

public class AppartmentTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? ShortName { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

public class HouseTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? ShortName { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

public class NormativeDocsTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

public class ObjectLevels
{
    public int Level { get; set; }
    public string Name { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

public class OperationTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

public class ParamTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

public class RoomTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

// --------------------------------------------------------------------------------------
// GAR Facts

public class AddrObj
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ObjectGUID { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string TypeName { get; set; } = string.Empty;
    public string Level { get; set; } = string.Empty;
    public string OperTypeID { get; set; } = string.Empty;
    public string PrevId { get; set; } = string.Empty;
    public string NextId { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
    public string IsActive { get; set; } = string.Empty;
    public string IsActual { get; set; } = string.Empty;

}

public class AddrObjDivision
{
    public string Id { get; set; } = string.Empty;
    public string ParentId { get; set; } = string.Empty;
    public string ChildId { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
}

public class AddrObjParams
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string ChangeIdend { get; set; } = string.Empty;
    public string TypeId { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;

}

public class AdmHierarchy
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ParentObjId { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string RegionCode { get; set; } = string.Empty;
    public string PrevId { get; set; } = string.Empty;
    public string NextId { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
    public string IsActive { get; set; } = string.Empty;
    public string Path { get; set; } = string.Empty;
}

public class Apartments
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ObjectGuid { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string Number { get; set; } = string.Empty;
    public string ApartType { get; set; } = string.Empty;
    public string OperTypeID { get; set; } = string.Empty;
    public string PrevId { get; set; } = string.Empty;
    public string NextId { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
    public string IsActual { get; set; } = string.Empty;
    public string IsActive { get; set; } = string.Empty;
}

public class ApartmentsParams
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string ChangeIdend { get; set; } = string.Empty;
    public string TypeId { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
}

public class CarPlace
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ObjectGuid { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string Number { get; set; } = string.Empty;
    public string OperTypeID { get; set; } = string.Empty;
    public string PrevId { get; set; } = string.Empty;
    public string NextId { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
    public string IsActual { get; set; } = string.Empty;
    public string IsActive { get; set; } = string.Empty;
}

public class CarPlacesParams
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string ChangeIdend { get; set; } = string.Empty;
    public string TypeId { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
}

public class ChangeHistory
{
    public string ChangeId { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string AdrObjectId { get; set; } = string.Empty;
    public string OperTypeId { get; set; } = string.Empty;
    public string ChangeDate { get; set; } = string.Empty;
}

public class Houses
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ObjectGuid { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string HouseNum { get; set; } = string.Empty;
    public string HouseType { get; set; } = string.Empty;
    public string OperTypeID { get; set; } = string.Empty;
    public string PrevId { get; set; } = string.Empty;
    public string NextId { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
    public string IsActual { get; set; } = string.Empty;
    public string IsActive { get; set; } = string.Empty;
}

public class HousesParams
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string ChangeIdend { get; set; } = string.Empty;
    public string TypeId { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
}

public class MunHierarchy
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ParentObjId { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string Oktmo { get; set; } = string.Empty;
    public string PrevId { get; set; } = string.Empty;
    public string NextId { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
    public string IsActive { get; set; } = string.Empty;
    public string Path { get; set; } = string.Empty;
}

public class NormativeDocs
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Date { get; set; } = string.Empty;
    public string Number { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;
    public string Kind { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
}

public class ReestrObjects
{
    public string ObjectId { get; set; } = string.Empty;
    public string ObjectGuid { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string LevelId { get; set; } = string.Empty;
    public string CreateDate { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string IsActive { get; set; } = string.Empty;
}

public class Rooms
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ObjectGuid { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string Number { get; set; } = string.Empty;
    public string RoomType { get; set; } = string.Empty;
    public string OperTypeID { get; set; } = string.Empty;
    public string PrevId { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
    public string IsActual { get; set; } = string.Empty;
    public string IsActive { get; set; } = string.Empty;
}

public class RoomsParams
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string ChangeIdend { get; set; } = string.Empty;
    public string TypeId { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
}

public class Steads
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ObjectGuid { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string Number { get; set; } = string.Empty;
    public string OperTypeID { get; set; } = string.Empty;
    public string PrevId { get; set; } = string.Empty;
    public string NextId { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
    public string IsActual { get; set; } = string.Empty;
    public string IsActive { get; set; } = string.Empty;
}

public class SteadsParams
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string ChangeIdend { get; set; } = string.Empty;
    public string TypeId { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
}