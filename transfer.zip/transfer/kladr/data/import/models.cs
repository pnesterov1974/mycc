namespace Import.gar;
public class NormativeDocsKinds
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
}

class AddHouseTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? ShortName { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class AddrObjTypes
{
    public int Id { get; set; }
    public int Level { get; set; }
    public string Name { get; set; } = string.Empty;
    public string ShortName { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class AppartmentTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? ShortName { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class HouseTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? ShortName { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class NormativeDocsTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class ObjectLevels
{
    public int Level { get; set; }
    public string Name { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class OperationTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class ParamTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class RoomTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

// --------------------------------------------------------------------------------------
// GAR Facts

class AddrObj
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ObjectGUID { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string TypeName { get; set; } = string.Empty;
    public string Level { get; set; } = string.Empty;
    public string OperTypeID { get; set; } = string.Empty;
    public string PrevId { get; set; } = string.Empty;
    public string NextId { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
    public string IsActive { get; set; } = string.Empty;
    public string IsActual { get; set; } = string.Empty;

}

class AddrObjDivision
{
    public string Id { get; set; } = string.Empty;
    public string ParentId { get; set; } = string.Empty;
    public string ChildId { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
}

class AddrObjParams
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string ChangeIdend { get; set; } = string.Empty;
    public string TypeId { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;

}

class AdmHierarchy
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ParentObjId { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string RegionCode { get; set; } = string.Empty;
    public string PrevId { get; set; } = string.Empty;
    public string NextId { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
    public string IsActive { get; set; } = string.Empty;
    public string Path { get; set; } = string.Empty;
}

class Apartments
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ObjectGuid { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string Number { get; set; } = string.Empty;
    public string ApartType { get; set; } = string.Empty;
    public string OperTypeID { get; set; } = string.Empty;
    public string PrevId { get; set; } = string.Empty;
    public string NextId { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
    public string IsActual { get; set; } = string.Empty;
    public string IsActive { get; set; } = string.Empty;
}

class ApartmentsParams
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string ChangeIdend { get; set; } = string.Empty;
    public string TypeId { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
}

class CarPlace
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ObjectGuid { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string Number { get; set; } = string.Empty;
    public string OperTypeID { get; set; } = string.Empty;
    public string PrevId { get; set; } = string.Empty;
    public string NextId { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
    public string IsActual { get; set; } = string.Empty;
    public string IsActive { get; set; } = string.Empty;
}

class CarPlacesParams
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string ChangeIdend { get; set; } = string.Empty;
    public string TypeId { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
}

class ChangeHistory
{
    public string ChangeId { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string AdrObjectId { get; set; } = string.Empty;
    public string OperTypeId { get; set; } = string.Empty;
    public string ChangeDate { get; set; } = string.Empty;
}

class Houses
{
    public string Id { get; set; } = string.Empty;
    public string ObjectId { get; set; } = string.Empty;
    public string ObjectGuid { get; set; } = string.Empty;
    public string ChangeId { get; set; } = string.Empty;
    public string HouseNum { get; set; } = string.Empty;
    public string HouseType { get; set; } = string.Empty;
    public string OperTypeID { get; set; } = string.Empty;
    public string PrevId { get; set; } = string.Empty;
    public string NextId { get; set; } = string.Empty;
    public string UpdateDate { get; set; } = string.Empty;
    public string StartDate { get; set; } = string.Empty;
    public string EndDate { get; set; } = string.Empty;
    public string IsActual { get; set; } = string.Empty;
    public string IsActive { get; set; } = string.Empty;
}