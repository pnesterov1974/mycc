using System.Xml;

namespace xmlUtils;

public static class XMLUtils
{
    public static string GetStringNotNullNodeValue(XmlElement xnode, string attrName)
    {
        string res = string.Empty;
        try
        {
            XmlNode? attr = xnode.Attributes.GetNamedItem(attrName);
            res = attr.Value;
        }
        catch
        { ; }
        return res;
    }

    public static string? GetStringNullNodeValue(XmlElement xnode, string attrName)
    {
        string? res = null;
        try
        {
            XmlNode? attr = xnode.Attributes.GetNamedItem(attrName);
            res = attr.Value;
        }
        catch
        { ; }
        return res;
    }

    public static int GetIntNodeValue(XmlElement xnode, string attrName)
    {
        XmlNode attr = xnode.Attributes.GetNamedItem(attrName);
        int res = int.Parse(attr.Value);
        return res;
    }

    public static DateOnly GetDateOnlyNodeValue(XmlElement xnode, string attrName)
    {
        XmlNode attr = xnode.Attributes.GetNamedItem(attrName);
        DateOnly res = DateOnly.Parse(attr.Value);
        return res;
    }
}

    // public static T GetNodeValue<T>(XmlElement xnode, string attrName)
    // {
    //     XmlNode attr = xnode.Attributes.GetNamedItem(attrName);
    //     T res = attr.Value as T;
    //     return Null; 
    // }