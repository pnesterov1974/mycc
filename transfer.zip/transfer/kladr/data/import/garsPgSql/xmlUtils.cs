using System.Xml;

namespace xmlUtils;

public static class XMLUtils
{
    public static string GetStringNodeValue(XmlElement xnode, string attrName)
    {
        XmlNode attr = xnode.Attributes.GetNamedItem(attrName);
        string res = attr.Value;
        return res;
    }

    // public static T GetNodeValue<T>(XmlElement xnode, string attrName)
    // {
    //     XmlNode attr = xnode.Attributes.GetNamedItem(attrName);
    //     T res = attr.Value as T;
    //     return Null; 
    // }
}