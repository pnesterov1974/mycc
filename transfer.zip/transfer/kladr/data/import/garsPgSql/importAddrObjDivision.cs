using System.Xml;
using Data;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Import.gar.pgsql;
public class ImportAddrObjDivision : BasePgSql
{
    protected ImportObjectsInfo objectsInfo { get; set; }
    public ImportAddrObjDivision(ImportObjectsInfo objectsInfo) => this.objectsInfo = objectsInfo;

    // TODO: FineTune: clearInAdvance, try-catch, log_events backward_rename ??
    public int DoImportData(bool clearDestTableInAdvance = true)
    {
        if (clearDestTableInAdvance)
        {
            bool cl = this.ClearDestTable(this.objectsInfo.ConnectionString, this.objectsInfo.TargetTableFullName);
        }

        int TotalRecords = 0;
        foreach (var s in this.objectsInfo.SourceFilePaths)
        {
            Log.Information("Импорт из файла {file}", s.FileFullPath);

            if (File.Exists(s.FileFullPath))
            {
                Log.Information("Файл {file} существует", s.FileFullPath);
                List<AddrObjDivision> data = this.ReadSourceDataOneFile(s.FileFullPath);
                TotalRecords += this.WriteDataOneFile(data, s.FileName);
            }
            else
            {
                Log.Warning("Файл {file} НЕ существует, обработка пропускается", s.FileFullPath);
            }
        }
        return TotalRecords;
    }

    private List<AddrObjDivision> ReadSourceDataOneFile(string fileFullPath)
    {
        List<AddrObjDivision> res = new List<AddrObjDivision>();
        Log.Information("Обработка файла ...{file}", fileFullPath);
        XmlDocument xDoc = new XmlDocument();
        xDoc.Load(fileFullPath);
        XmlElement? xRoot = xDoc.DocumentElement;
        if (xRoot != null)
        {
            int i = 0;
            foreach (XmlElement xnode in xRoot)
            {
                XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                string id = idAttr.Value;

                XmlNode ParentIdAttr = xnode.Attributes.GetNamedItem("PARENTID");
                string parentId = ParentIdAttr.Value;

                XmlNode ChildIdAttr = xnode.Attributes.GetNamedItem("CHILDID");
                string childId = ChildIdAttr.Value;

                XmlNode ChangeIdAttr = xnode.Attributes.GetNamedItem("CHANGEID");
                string changeId = ChangeIdAttr.Value;

                i += 1;
                res.Add(new AddrObjDivision
                    {
                        Id = id,
                        ParentId = parentId,
                        ChildId = childId,
                        ChangeId = changeId
                    }
                );
            }
        }
        else
        {
            Log.Information("Элементы не найдены");
        }
        return res;
    }

    private int WriteDataOneFile(List<AddrObjDivision> data, string fileName, int bufferRecs=20000)
    {
        int RecordCount = 0;
        int CurBufferRecs = 0;
        Log.Information("Необходимо записать в таблицу {cnt} строк", data.Count);
        using var conn = new NpgsqlConnection(this.objectsInfo.ConnectionString);
        conn.Open();

        var batch = new NpgsqlBatch(conn);

        foreach (var d in data)
        {
            var bcmd = new NpgsqlBatchCommand($"""
                INSERT INTO {this.objectsInfo.TargetTableFullName} (
                    id, parentid, childid, changeid
                )
                VALUES (
                   @id, @parentid, @childid, @changeid
                );
                """
            );

            bcmd.Parameters.AddWithValue("@id", d.Id);
            bcmd.Parameters.AddWithValue("@parentid", d.ParentId);
            bcmd.Parameters.AddWithValue("@childid", d.ChildId);
            bcmd.Parameters.AddWithValue("@changeid", d.ChangeId);

            batch.BatchCommands.Add(bcmd);
            CurBufferRecs += 1;
            if (CurBufferRecs >= bufferRecs)
            {
                RecordCount += batch.ExecuteNonQuery();
                Log.Information("{table} import: imported {recs}", this.objectsInfo.TargetTableFullName, RecordCount);
                CurBufferRecs = 0;
                batch.BatchCommands.Clear();
            }
        }
        if (CurBufferRecs > 0)
        {
            RecordCount += batch.ExecuteNonQuery();
            Log.Information("{table} import: imported {recs}", this.objectsInfo.TargetTableName, RecordCount);
            batch.BatchCommands.Clear();
        }
        Log.Information("Загружено записей {recs} из {file}", RecordCount, fileName);
        return RecordCount;
    }
}