using System.Xml;
using Data;
using Data.Import.gar;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Data.Import.gar.pgsql;
public class ImportParamTypes: BasePgSql
{
    protected ImportObjectInfo objectInfo { get; set; }
    public ImportParamTypes(ImportObjectInfo objectInfo) => this.objectInfo = objectInfo;

    private List<ParamTypes> GetSourceData()
    {
        List<ParamTypes> res = new List<ParamTypes>();
        Log.Information("Импорт из файла ...{file}", this.objectInfo.SourceFileName);
        XmlDocument xDoc = new XmlDocument();
        xDoc.Load(this.objectInfo.SourceFilePath);
        XmlElement? xRoot = xDoc.DocumentElement;
        if (xRoot != null)
        {
            foreach (XmlElement xnode in xRoot)
            {
                XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                int id = int.Parse(idAttr.Value);
                XmlNode NameAttr = xnode.Attributes.GetNamedItem("NAME");
                string name = NameAttr.Value;
                XmlNode CodeAttr = xnode.Attributes.GetNamedItem("CODE");
                string code = CodeAttr.Value;
                XmlNode? DescAttr = xnode.Attributes.GetNamedItem("DESC");
                string? desc = DescAttr?.Value;
                XmlNode IsActiveAttr = xnode.Attributes.GetNamedItem("ISACTIVE");
                string _isActive = IsActiveAttr.Value;
                bool isActive = false;
                if (_isActive.ToLower().Equals("true"))
                {
                    isActive = true;
                }
                else if (_isActive.ToLower().Equals("false"))
                {
                    isActive = false;
                }
                XmlNode? UpdateDateAttr = xnode.Attributes.GetNamedItem("UPDATEDATE");
                DateOnly updateDate = DateOnly.Parse(UpdateDateAttr.Value);
                XmlNode? StartDateAttr = xnode.Attributes.GetNamedItem("STARTDATE");
                DateOnly startDate = DateOnly.Parse(StartDateAttr.Value);
                XmlNode? EndDateAttr = xnode.Attributes.GetNamedItem("ENDDATE");
                DateOnly endDate = DateOnly.Parse(EndDateAttr.Value);
                res.Add(new ParamTypes
                    {
                        Id = id,
                        Name = name,
                        Code = code,
                        Desc = desc,
                        IsActive = isActive,
                        UpdateDate = updateDate,
                        StartDate = startDate,
                        EndDate = endDate
                    }
                );
                //Log.Information("ID:{id} == NAME:{name} == CODE:{code} == DESC:{desc} == ISACTIVE:{isactive} == UPDATEDATE:{updatedate} == STARTDATE:{startdate} == ENDDATE:{enddate}", id, name, code, desc, isActive, updateDate, startDate, endDate);
            }
        }
        else
        {
            Log.Information("Элементы не найдены");
        }
        return res;
    }

    public void DoImport(bool clearDestTableInAdvance = true)
    {
        Log.Information("Импорт из файла {file}", this.objectInfo.SourceFilePath);

        if (File.Exists(this.objectInfo.SourceFilePath))
        {
            Log.Information("Файл {file} существует...", this.objectInfo.SourceFileName);
            if (!clearDestTableInAdvance ||
                (clearDestTableInAdvance &&
                    this.ClearDestTable(
                        this.objectInfo.ConnectionString,
                        this.objectInfo.TargetTableFullName
                    )
                )
           )
            {
                var data = this.GetSourceData();

                using var conn = new NpgsqlConnection(this.objectInfo.ConnectionString);
                conn.Open();

                var batch = new NpgsqlBatch(conn);

                foreach (var d in data)
                {
                    var bcmd = new NpgsqlBatchCommand(
                        $"INSERT INTO {this.objectInfo.TargetTableFullName}(id, name, code, descr, isactive, updatedate, startdate, enddate) VALUES (@id, @name, @code, @desc, @isactive, @updatedate, @startdate, @enddate);"
                        );

                    bcmd.Parameters.AddWithValue("@id", d.Id);
                    bcmd.Parameters.AddWithValue("@name", d.Name);
                    bcmd.Parameters.AddWithValue("@code", d.Code);
                    bcmd.Parameters.AddWithValue("@desc", d.Desc);
                    bcmd.Parameters.AddWithValue("@isactive", d.IsActive);
                    bcmd.Parameters.AddWithValue("@updatedate", d.UpdateDate);
                    bcmd.Parameters.AddWithValue("@startdate", d.StartDate);
                    bcmd.Parameters.AddWithValue("@enddate", d.EndDate);

                    Log.Debug(bcmd.CommandText);

                    batch.BatchCommands.Add(bcmd);
                }

                int recs = batch.ExecuteNonQuery();
                Log.Information("Загружено записей {recs} из {file}", recs, this.objectInfo.SourceFileName);
            }
        }
        else
        {
            Log.Information("Файл {file} не найден", this.objectInfo.SourceFilePath);
        }
    }
}
