using System.Xml;
using Data;
using Data.Import.gar;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Data.Import.gar.pgsql;
public class ImportHouses : BasePgSql
{
    protected ImportObjectsInfo objectsInfo { get; set; }
    public ImportHouses(ImportObjectsInfo objectsInfo) => this.objectsInfo = objectsInfo;

    public void DoImportData(bool clearDestTableInAdvance = true)
    {
        if (clearDestTableInAdvance)
        {
            bool cl = this.ClearDestTable(this.objectsInfo.ConnectionString, this.objectsInfo.TargetTableFullName);
        }

        Log.Information("Начинаю импорт {table} ...", this.objectsInfo.TargetTableName);

        DateTime dtStart = DateTime.Now;
        int totalRecCount = this.ReadSourceDataAllFiles(this.objectsInfo.SourceFilePaths);
        DateTime dtFinish = DateTime.Now;

        TimeSpan duration = dtFinish - dtStart;
        Log.Information(
            "Импорт {table} закончен, всего загружено {records} записей... время обрадоьки: {duration}",
            this.objectsInfo.TargetTableName, totalRecCount, duration
            );
    }

    private int ReadSourceDataAllFiles(List<GarFileInfo> filePaths, int sourceBatchSize = 100000)
    {
        List<Houses> currentBatch = new List<Houses>(sourceBatchSize + 1);
        int currentBatchCount = 0;
        int recordCount = 0;
        Log.Information("Размер буфера на считывание {recbatchsize} ...", sourceBatchSize);
        foreach (var gfi in filePaths)
        {
            string filePath = gfi.FileFullPath;
            Log.Information("Обработка файла ...{file}", filePath);
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(filePath);
            XmlElement? xRoot = xDoc.DocumentElement;
            if (xRoot != null)
            {
                foreach (XmlElement xnode in xRoot)
                {
                    XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                    string id = idAttr.Value;

                    XmlNode ObjectIdAttr = xnode.Attributes.GetNamedItem("OBJECTID");
                    string objectId = ObjectIdAttr.Value;

                    XmlNode ObjectGuidAttr = xnode.Attributes.GetNamedItem("OBJECTGUID");
                    string objectGuid = ObjectGuidAttr.Value;

                    XmlNode ChangeIdAttr = xnode.Attributes.GetNamedItem("CHANGEID");
                    string changeId = ChangeIdAttr.Value;

                    string houseNum = string.Empty;
                    try
                    {
                        XmlNode HouseNumAttr = xnode.Attributes.GetNamedItem("HOUSENUM");
                        houseNum = HouseNumAttr.Value;
                    }
                    catch
                    {
                        ;
                    }

                    string houseType = string.Empty;
                    try
                    {
                        XmlNode HouseTypeAttr = xnode.Attributes.GetNamedItem("HOUSETYPE");
                        houseType = HouseTypeAttr.Value;
                    }
                    catch
                    {
                        ;
                    }

                    XmlNode OperTypeIdAttr = xnode.Attributes.GetNamedItem("OPERTYPEID");
                    string operTypeId = OperTypeIdAttr.Value;

                    XmlNode PrevIdAttr = xnode.Attributes.GetNamedItem("PREVID");
                    string prevId = PrevIdAttr.Value;

                    string nextId = string.Empty;
                    try
                    {
                        XmlNode NextIDAttr = xnode.Attributes.GetNamedItem("NEXTID");
                        nextId = NextIDAttr.Value;
                    }
                    catch
                    {
                        ;
                    }

                    XmlNode UpdateDateAttr = xnode.Attributes.GetNamedItem("UPDATEDATE");
                    string updateDate = UpdateDateAttr.Value;

                    XmlNode StartDateAttr = xnode.Attributes.GetNamedItem("STARTDATE");
                    string startDate = StartDateAttr.Value;

                    XmlNode EndDateAttr = xnode.Attributes.GetNamedItem("ENDDATE");
                    string endDate = EndDateAttr.Value;

                    XmlNode IsActiveAttr = xnode.Attributes.GetNamedItem("ISACTIVE");
                    string isActive = IsActiveAttr.Value;

                    XmlNode IsActualAttr = xnode.Attributes.GetNamedItem("ISACTUAL");
                    string isActual = IsActualAttr.Value;

                    currentBatchCount += 1;

                    currentBatch.Add(new Houses
                    {
                        Id = id,
                        ObjectId = objectId,
                        ObjectGuid = objectGuid,
                        ChangeId = changeId,
                        HouseNum = houseNum,
                        HouseType = houseType,
                        OperTypeID = operTypeId,
                        PrevId = prevId,
                        NextId = nextId,
                        UpdateDate = updateDate,
                        StartDate = startDate,
                        EndDate = endDate,
                        IsActual = isActual,
                        IsActive = isActive
                    }
                    );
                    if (currentBatchCount >= sourceBatchSize)
                    {
                        Log.Information("Считано из источника {currentBatch} (текущая пачка) -> загрузка в БД", currentBatchCount);
                        recordCount += this.WriteDataOneBatch(currentBatch);
                        Log.Information("Всего обработано {recordCount} записей", recordCount);
                        currentBatchCount = 0;
                        currentBatch = new List<Houses>(sourceBatchSize + 1);
                    }
                }
            }
            else
            {
                Log.Information("Элементы для файла {filepath} не найдены", filePath);
            }
        }
        if (currentBatchCount > 0)
        {
            recordCount += this.WriteDataOneBatch(currentBatch);
        }
        Log.Information("Всего обработано {recordCount} записей", recordCount);
        return recordCount;
    }

    private int WriteDataOneBatch(List<Houses> data, int targetBatchSize = 20000)
    {
        int recordCount = 0;
        int curBufferRecs = 0;
        using var conn = new NpgsqlConnection(this.objectsInfo.ConnectionString);
        conn.Open();

        var batch = new NpgsqlBatch(conn);

        foreach (var d in data)
        {
            var bcmd = new NpgsqlBatchCommand($"""
                INSERT INTO {this.objectsInfo.TargetTableFullName} (
                    id, objectid, objectguid, changeid, housenum, housetype, opertypeid, previd, nextid, updatedate, startdate, enddate, isactual, isactive
                )
                VALUES (
                    @id, @objectid, @objectguid, @changeid, @housenum, @housetype, @opertypeid, @previd, @nextid, @updatedate, @startdate, @enddate, @isactual, @isactive
                );
                """
            );

            bcmd.Parameters.AddWithValue("@id", d.Id);
            bcmd.Parameters.AddWithValue("@objectid", d.ObjectId);
            bcmd.Parameters.AddWithValue("@objectguid", d.ObjectGuid);
            bcmd.Parameters.AddWithValue("@changeid", d.ChangeId);
            bcmd.Parameters.AddWithValue("@housenum", d.HouseNum);
            bcmd.Parameters.AddWithValue("@housetype", d.HouseType);
            bcmd.Parameters.AddWithValue("@opertypeid", d.OperTypeID);
            bcmd.Parameters.AddWithValue("@previd", d.PrevId);
            bcmd.Parameters.AddWithValue("@nextid", d.NextId);
            bcmd.Parameters.AddWithValue("@updatedate", d.UpdateDate);
            bcmd.Parameters.AddWithValue("@startdate", d.StartDate);
            bcmd.Parameters.AddWithValue("@enddate", d.EndDate);
            bcmd.Parameters.AddWithValue("@isactive", d.IsActive);
            bcmd.Parameters.AddWithValue("@isactual", d.IsActual);

            batch.BatchCommands.Add(bcmd);
            curBufferRecs += 1;
            if (curBufferRecs >= targetBatchSize)
            {
                recordCount += batch.ExecuteNonQuery();
                Log.Information("Записано в БД {recordCount} из {recordsInSourceBatch}", recordCount, data.Count);
                curBufferRecs = 0;
                batch.BatchCommands.Clear();
            }
        }
        if (curBufferRecs > 0)
        {
            recordCount += batch.ExecuteNonQuery();
            Log.Information("Записано в БД {recordCount} из {recordsInSourceBatch}", recordCount, data.Count);
            batch.BatchCommands.Clear();
        }
        return recordCount;
    }
}