using System.Xml;
using Data;
using Data.Import.gar;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Data.Import.gar.pgsql;
public class ImportChangeHistory : BasePgSql
{
    protected ImportObjectsInfo objectsInfo { get; set; }
    public ImportChangeHistory(ImportObjectsInfo objectsInfo) => this.objectsInfo = objectsInfo;

    public void DoImportData(bool clearDestTableInAdvance = true)
    {
        if (clearDestTableInAdvance)
        {
            bool cl = this.ClearDestTable(this.objectsInfo.ConnectionString, this.objectsInfo.TargetTableFullName);
        }

        Log.Information("Начинаю импорт {table} ...", this.objectsInfo.TargetTableName);

        DateTime dtStart = DateTime.Now;
        int totalRecCount = this.ReadSourceDataAllFiles(this.objectsInfo.SourceFilePaths);
        DateTime dtFinish = DateTime.Now;

        TimeSpan duration = dtFinish - dtStart;
        Log.Information(
            "Импорт {table} закончен, всего загружено {records} записей... время обрадоьки: {duration}", 
            this.objectsInfo.TargetTableName, totalRecCount, duration
            );
    }

    private int ReadSourceDataAllFiles(List<GarFileInfo> filePaths, int sourceBatchSize = 100000)
    {
        List<ChangeHistory> currentBatch = new List<ChangeHistory>(sourceBatchSize + 1);
        int currentBatchCount = 0;
        int recordCount = 0;
        Log.Information("Размер буфера на считывание {recbatchsize} ...", sourceBatchSize);
        foreach (var gfi in filePaths)
        {
            string filePath = gfi.FileFullPath;
            Log.Information("Обработка файла ...{file}", filePath);
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(filePath);
            XmlElement? xRoot = xDoc.DocumentElement;
            if (xRoot != null)
            {
                foreach (XmlElement xnode in xRoot)
                {
                    XmlNode ChangeIdAttr = xnode.Attributes.GetNamedItem("CHANGEID");
                    string changeId = ChangeIdAttr.Value;

                    XmlNode ObjectIdAttr = xnode.Attributes.GetNamedItem("OBJECTID");
                    string objectId = ObjectIdAttr.Value;

                    XmlNode AdrObjectIdAttr = xnode.Attributes.GetNamedItem("ADROBJECTID");
                    string adrObjectId = AdrObjectIdAttr.Value;

                    XmlNode OperTypeIdAttr = xnode.Attributes.GetNamedItem("OPERTYPEID");
                    string operTypeId = OperTypeIdAttr.Value;

                    XmlNode ChangeDateAttr = xnode.Attributes.GetNamedItem("CHANGEDATE");
                    string changeDate = ChangeDateAttr.Value;

                    currentBatchCount += 1;

                    currentBatch.Add(new ChangeHistory
                        {
                            ChangeId = changeId,
                            ObjectId = objectId,
                            AdrObjectId = adrObjectId,
                            OperTypeId = operTypeId,
                            ChangeDate = changeDate
                        }
                    );
                    if (currentBatchCount >= sourceBatchSize)
                    {
                        Log.Information("Считано из источника {currentBatch} (текущая пачка) -> загрузка в БД", currentBatchCount);
                        recordCount += this.WriteDataOneBatch(currentBatch);
                        Log.Information("Всего обработано {recordCount} записей", recordCount);
                        currentBatchCount = 0;
                        currentBatch = new List<ChangeHistory>(sourceBatchSize + 1);
                    }
                }
            }
            else
            {
                Log.Information("Элементы для файла {filepath} не найдены", filePath);
            }
        }
        if (currentBatchCount > 0)
        {
            recordCount += this.WriteDataOneBatch(currentBatch);
        }
        Log.Information("Всего обработано {recordCount} записей", recordCount);
        return recordCount;
    }

    private int WriteDataOneBatch(List<ChangeHistory> data, int targetBatchSize = 20000)
    {
        int recordCount = 0;
        int curBufferRecs = 0;
        using var conn = new NpgsqlConnection(this.objectsInfo.ConnectionString);
        conn.Open();

        var batch = new NpgsqlBatch(conn);

        foreach (var d in data)
        {
            var bcmd = new NpgsqlBatchCommand($"""
                INSERT INTO {this.objectsInfo.TargetTableFullName} (
                    changeid, objectid, adrobjectid, opertypeid, changedate
                )
                VALUES (
                    @changeid, @objectid, @adrobjectid, @opertypeid, @changedate
                );
                """
            );

            bcmd.Parameters.AddWithValue("@changeid", d.ChangeId);
            bcmd.Parameters.AddWithValue("@objectid", d.ObjectId);
            bcmd.Parameters.AddWithValue("@adrobjectid", d.AdrObjectId);
            bcmd.Parameters.AddWithValue("@opertypeid", d.OperTypeId);
            bcmd.Parameters.AddWithValue("@changedate", d.ChangeDate);

            batch.BatchCommands.Add(bcmd);
            curBufferRecs += 1;
            if (curBufferRecs >= targetBatchSize)
            {
                recordCount += batch.ExecuteNonQuery();
                Log.Information("Записано в БД {recordCount} из {recordsInSourceBatch}", recordCount, data.Count);
                curBufferRecs = 0;
                batch.BatchCommands.Clear();
            }
        }
        if (curBufferRecs > 0)
        {
            recordCount += batch.ExecuteNonQuery();
            Log.Information("Записано в БД {recordCount} из {recordsInSourceBatch}", recordCount, data.Count);
            batch.BatchCommands.Clear();
        }
        return recordCount;
    }
}