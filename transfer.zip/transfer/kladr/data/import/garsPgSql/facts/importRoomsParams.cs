using System.Xml;
using Data;
using Data.Import.gar;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Data.Import.gar.pgsql;
public class ImportRoomsParams : BasePgSql
{
    protected ImportObjectsInfo objectsInfo { get; set; }
    public ImportRoomsParams(ImportObjectsInfo objectsInfo) => this.objectsInfo = objectsInfo;

    public void DoImportData(bool clearDestTableInAdvance = true)
    {
        if (clearDestTableInAdvance)
        {
            bool cl = this.ClearDestTable(this.objectsInfo.ConnectionString, this.objectsInfo.TargetTableFullName);
        }

        Log.Information("Начинаю импорт {table} ...", this.objectsInfo.TargetTableName);

        DateTime dtStart = DateTime.Now;
        int totalRecCount = this.ReadSourceDataAllFiles(this.objectsInfo.SourceFilePaths);
        DateTime dtFinish = DateTime.Now;

        TimeSpan duration = dtFinish - dtStart;
        Log.Information(
            "Импорт {table} закончен, всего загружено {records} записей... время обрадоьки: {duration}", 
            this.objectsInfo.TargetTableName, totalRecCount, duration
            );
    }

    private int ReadSourceDataAllFiles(List<GarFileInfo> filePaths, int sourceBatchSize = 100000)
    {
        List<RoomsParams> currentBatch = new List<RoomsParams>(sourceBatchSize + 1);
        int currentBatchCount = 0;
        int recordCount = 0;
        Log.Information("Размер буфера на считывание {recbatchsize} ...", sourceBatchSize);
        foreach (var gfi in filePaths)
        {
            string filePath = gfi.FileFullPath;
            Log.Information("Обработка файла ...{file}", filePath);
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(filePath);
            XmlElement? xRoot = xDoc.DocumentElement;
            if (xRoot != null)
            {
                foreach (XmlElement xnode in xRoot)
                {
                    XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                    string id = idAttr.Value;

                    XmlNode ObjectIdAttr = xnode.Attributes.GetNamedItem("OBJECTID");
                    string objectId = ObjectIdAttr.Value;

                    XmlNode ChangeIdAttr = xnode.Attributes.GetNamedItem("CHANGEID");
                    string changeId = ChangeIdAttr.Value;

                    XmlNode ChangeIdendAttr = xnode.Attributes.GetNamedItem("CHANGEIDEND");
                    string changeIdend = ChangeIdendAttr.Value;

                    XmlNode TypeIdAttr = xnode.Attributes.GetNamedItem("TYPEID");
                    string typeId = TypeIdAttr.Value;

                    XmlNode ValueAttr = xnode.Attributes.GetNamedItem("VALUE");
                    string value = ValueAttr.Value;


                    XmlNode UpdateDateAttr = xnode.Attributes.GetNamedItem("UPDATEDATE");
                    string updateDate = UpdateDateAttr.Value;

                    XmlNode StartDateAttr = xnode.Attributes.GetNamedItem("STARTDATE");
                    string startDate = StartDateAttr.Value;

                    XmlNode EndDateAttr = xnode.Attributes.GetNamedItem("ENDDATE");
                    string endDate = EndDateAttr.Value;

                    currentBatchCount += 1;

                    currentBatch.Add(new RoomsParams
                        {
                            Id = id,
                            ObjectId = objectId,
                            ChangeId = changeId,
                            ChangeIdend = changeIdend,
                            TypeId = typeId,
                            Value = value,
                            UpdateDate = updateDate,
                            StartDate = startDate,
                            EndDate = endDate
                        }
                    );
                    if (currentBatchCount >= sourceBatchSize)
                    {
                        Log.Information("Считано из источника {currentBatch} (текущая пачка) -> загрузка в БД", currentBatchCount);
                        recordCount += this.WriteDataOneBatch(currentBatch);
                        Log.Information("Всего для {table} обработано {recordCount} записей", this.objectsInfo.TargetTableName, recordCount);
                        currentBatchCount = 0;
                        currentBatch = new List<RoomsParams>(sourceBatchSize + 1);
                    }
                }
            }
            else
            {
                Log.Information("Элементы для файла {filepath} не найдены", filePath);
            }
        }
        if (currentBatchCount > 0)
        {
            recordCount += this.WriteDataOneBatch(currentBatch);
        }
        Log.Information("Всего обработано {recordCount} записей", recordCount);
        return recordCount;
    }

    private int WriteDataOneBatch(List<RoomsParams> data, int targetBatchSize = 20000)
    {
        int recordCount = 0;
        int curBufferRecs = 0;
        using var conn = new NpgsqlConnection(this.objectsInfo.ConnectionString);
        conn.Open();

        var batch = new NpgsqlBatch(conn);

        foreach (var d in data)
        {
            var bcmd = new NpgsqlBatchCommand($"""
                INSERT INTO {this.objectsInfo.TargetTableFullName} (
                    id, objectid, changeid, changeidend, typeid, value, updatedate, startdate, enddate
                )
                VALUES (
                    @id, @objectid, @changeid, @changeidend, @typeid, @value, @updatedate, @startdate, @enddate
                );
                """
            );

            bcmd.Parameters.AddWithValue("@id", d.Id);
            bcmd.Parameters.AddWithValue("@objectid", d.ObjectId);
            bcmd.Parameters.AddWithValue("@changeid", d.ChangeId);
            bcmd.Parameters.AddWithValue("@changeidend", d.ChangeIdend);
            bcmd.Parameters.AddWithValue("@typeid", d.TypeId);
            bcmd.Parameters.AddWithValue("@value", d.Value);
            bcmd.Parameters.AddWithValue("@updatedate", d.UpdateDate);
            bcmd.Parameters.AddWithValue("@startdate", d.StartDate);
            bcmd.Parameters.AddWithValue("@enddate", d.EndDate);

            batch.BatchCommands.Add(bcmd);
            curBufferRecs += 1;
            if (curBufferRecs >= targetBatchSize)
            {
                recordCount += batch.ExecuteNonQuery();
                Log.Information("Записано в БД {recordCount} из {recordsInSourceBatch}", recordCount, data.Count);
                curBufferRecs = 0;
                batch.BatchCommands.Clear();
            }
        }
        if (curBufferRecs > 0)
        {
            recordCount += batch.ExecuteNonQuery();
            Log.Information("Записано в БД {recordCount} из {recordsInSourceBatch}", recordCount, data.Count);
            batch.BatchCommands.Clear();
        }
        return recordCount;
    }
}