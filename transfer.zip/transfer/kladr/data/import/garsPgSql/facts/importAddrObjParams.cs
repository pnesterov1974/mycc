using System.Xml;
using Data;
using Data.Import.gar;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Import.gar.pgsql;
public class ImportAddrObjParams : BasePgSql
{
    protected ImportObjectsInfo objectsInfo { get; set; }
    public ImportAddrObjParams(ImportObjectsInfo objectsInfo) => this.objectsInfo = objectsInfo;

    // TODO: FineTune: clearInAdvance, try-catch, log_events backward_rename ??
    public int DoImportData(bool clearDestTableInAdvance = true)
    {
        if (clearDestTableInAdvance)
        {
            bool cl = this.ClearDestTable(this.objectsInfo.ConnectionString, this.objectsInfo.TargetTableFullName);
        }

        int TotalRecords = 0;
        foreach (var s in this.objectsInfo.SourceFilePaths)
        {
            Log.Information("Импорт из файла {file}", s.FileFullPath);

            if (File.Exists(s.FileFullPath))
            {
                Log.Information("Файл {file} существует", s.FileFullPath);
                List<AddrObjParams> data = this.ReadSourceDataOneFile(s.FileFullPath);
                TotalRecords += this.WriteDataOneFile(data, s.FileName);
            }
            else
            {
                Log.Warning("Файл {file} НЕ существует, обработка пропускается", s.FileFullPath);
            }
        }
        return TotalRecords;
    }

    private List<AddrObjParams> ReadSourceDataOneFile(string fileFullPath)
    {
        List<AddrObjParams> res = new List<AddrObjParams>();
        Log.Information("Обработка файла ...{file}", fileFullPath);
        XmlDocument xDoc = new XmlDocument();
        xDoc.Load(fileFullPath);
        XmlElement? xRoot = xDoc.DocumentElement;
        if (xRoot != null)
        {
            int i = 0;
            foreach (XmlElement xnode in xRoot)
            {
                XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                string id = idAttr.Value;

                XmlNode ObjectIdAttr = xnode.Attributes.GetNamedItem("OBJECTID");
                string objectId = ObjectIdAttr.Value;

                XmlNode ChangeIdAttr = xnode.Attributes.GetNamedItem("CHANGEID");
                string changeId = ChangeIdAttr.Value;

                XmlNode ChangeIdendAttr = xnode.Attributes.GetNamedItem("CHANGEIDEND");
                string changeIdend = ChangeIdendAttr.Value;

                XmlNode TypeIdAttr = xnode.Attributes.GetNamedItem("TYPEID");
                string typeId = TypeIdAttr.Value;

                XmlNode ValueAttr = xnode.Attributes.GetNamedItem("VALUE");
                string value = ValueAttr.Value;

                XmlNode UpdateDateAttr = xnode.Attributes.GetNamedItem("UPDATEDATE");
                string updateDate = UpdateDateAttr.Value;

                XmlNode StartDateAttr = xnode.Attributes.GetNamedItem("STARTDATE");
                string startDate = StartDateAttr.Value;

                XmlNode EndDateAttr = xnode.Attributes.GetNamedItem("ENDDATE");
                string endDate = EndDateAttr.Value;

                i += 1;
                res.Add(new AddrObjParams
                    {
                        Id = id,
                        ObjectId = objectId,
                        ChangeId = changeId,
                        ChangeIdend = changeIdend,
                        TypeId = typeId,
                        Value = value,
                        UpdateDate = updateDate,
                        StartDate = startDate,
                        EndDate = endDate
                    }
                );
            }
        }
        else
        {
            Log.Information("Элементы не найдены");
        }
        return res;
    }

    private int WriteDataOneFile(List<AddrObjParams> data, string fileName, int bufferRecs=20000)
    {
        int RecordCount = 0;
        int CurBufferRecs = 0;
        Log.Information("Необходимо записать в таблицу {cnt} строк", data.Count);
        using var conn = new NpgsqlConnection(this.objectsInfo.ConnectionString);
        conn.Open();

        var batch = new NpgsqlBatch(conn);

        foreach (var d in data)
        {
            var bcmd = new NpgsqlBatchCommand($"""
                INSERT INTO {this.objectsInfo.TargetTableFullName} (
                    id, objectid, changeid, changeidend, typeid, value, startdate, updatedate, enddate 
                )
                VALUES (
                   @id, @objectid, @changeid, @changeidend, @typeid, @value, @startdate, @updatedate, @enddate
                );
                """
            );

            bcmd.Parameters.AddWithValue("@id", d.Id);
            bcmd.Parameters.AddWithValue("@objectid", d.ObjectId);
            bcmd.Parameters.AddWithValue("@changeid", d.ChangeId);
            bcmd.Parameters.AddWithValue("@changeidend", d.ChangeIdend);
            bcmd.Parameters.AddWithValue("@typeid", d.TypeId);
            bcmd.Parameters.AddWithValue("@value", d.Value);
            bcmd.Parameters.AddWithValue("@startdate", d.StartDate);
            bcmd.Parameters.AddWithValue("@updatedate", d.UpdateDate);
            bcmd.Parameters.AddWithValue("@enddate", d.EndDate);

            batch.BatchCommands.Add(bcmd);
            CurBufferRecs += 1;
            if (CurBufferRecs >= bufferRecs)
            {
                RecordCount += batch.ExecuteNonQuery();
                Log.Information("{table} import: imported {recs}", this.objectsInfo.TargetTableFullName, RecordCount);
                CurBufferRecs = 0;
                batch.BatchCommands.Clear();
            }
        }
        if (CurBufferRecs > 0)
        {
            RecordCount += batch.ExecuteNonQuery();
            Log.Information("{table} import: imported {recs}", this.objectsInfo.TargetTableName, RecordCount);
            batch.BatchCommands.Clear();
        }
        Log.Information("Загружено записей {recs} из {file}", RecordCount, fileName);
        return RecordCount;
    }
}