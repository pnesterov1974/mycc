using System.Xml;
using Data;
using Data.Import.gar;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Data.Import.gar.pgsql;
public class ImportNormativeDocs : BasePgSql
{
    protected ImportObjectsInfo objectsInfo { get; set; }
    public ImportNormativeDocs(ImportObjectsInfo objectsInfo) => this.objectsInfo = objectsInfo;

    public void DoImportData(bool clearDestTableInAdvance = true)
    {
        if (clearDestTableInAdvance)
        {
            bool cl = this.ClearDestTable(this.objectsInfo.ConnectionString, this.objectsInfo.TargetTableFullName);
        }

        Log.Information("Начинаю импорт {table} ...", this.objectsInfo.TargetTableName);

        DateTime dtStart = DateTime.Now;
        int totalRecCount = this.ReadSourceDataAllFiles(this.objectsInfo.SourceFilePaths);
        DateTime dtFinish = DateTime.Now;

        TimeSpan duration = dtFinish - dtStart;
        Log.Information(
            "Импорт {table} закончен, всего загружено {records} записей... время обрадоьки: {duration}",
            this.objectsInfo.TargetTableName, totalRecCount, duration
            );
    }

    private int ReadSourceDataAllFiles(List<GarFileInfo> filePaths, int sourceBatchSize = 100000)
    {
        List<NormativeDocs> currentBatch = new List<NormativeDocs>(sourceBatchSize + 1);
        int currentBatchCount = 0;
        int recordCount = 0;
        Log.Information("Размер буфера на считывание {recbatchsize} ...", sourceBatchSize);
        foreach (var gfi in filePaths)
        {
            string filePath = gfi.FileFullPath;
            Log.Information("Обработка файла ...{file}", filePath);
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(filePath);
            XmlElement? xRoot = xDoc.DocumentElement;
            if (xRoot != null)
            {
                foreach (XmlElement xnode in xRoot)
                {
                    XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                    string id = idAttr.Value;

                    string name = string.Empty;
                    try
                    {
                        XmlNode NameAttr = xnode.Attributes.GetNamedItem("NAME");
                        name = NameAttr.Value;
                    }
                    catch
                    {
                        ;
                    }

                    XmlNode DateAttr = xnode.Attributes.GetNamedItem("DATE");
                    string date = DateAttr.Value;

                    XmlNode NumberAttr = xnode.Attributes.GetNamedItem("NUMBER");
                    string number = NumberAttr.Value;


                    XmlNode TypeAttr = xnode.Attributes.GetNamedItem("TYPE");
                    string type = TypeAttr.Value;

                    XmlNode KindAttr = xnode.Attributes.GetNamedItem("KIND");
                    string kind = KindAttr.Value;

                    XmlNode UpdateDateAttr = xnode.Attributes.GetNamedItem("UPDATEDATE");
                    string updateDate = UpdateDateAttr.Value;

                    currentBatchCount += 1;

                    currentBatch.Add(new NormativeDocs
                    {
                        Id = id,
                        Name = name,
                        Date = date,
                        Number = number,
                        Type = type,
                        Kind = kind,
                        UpdateDate = updateDate
                    }
                    );
                    if (currentBatchCount >= sourceBatchSize)
                    {
                        Log.Information("Считано из источника {currentBatch} (текущая пачка) -> загрузка в БД", currentBatchCount);
                        recordCount += this.WriteDataOneBatch(currentBatch);
                        Log.Information("Всего обработано {recordCount} записей", recordCount);
                        currentBatchCount = 0;
                        currentBatch = new List<NormativeDocs>(sourceBatchSize + 1);
                    }
                }
            }
            else
            {
                Log.Information("Элементы для файла {filepath} не найдены", filePath);
            }
        }
        if (currentBatchCount > 0)
        {
            recordCount += this.WriteDataOneBatch(currentBatch);
        }
        Log.Information("Всего обработано {recordCount} записей", recordCount);
        return recordCount;
    }

    private int WriteDataOneBatch(List<NormativeDocs> data, int targetBatchSize = 20000)
    {
        int recordCount = 0;
        int curBufferRecs = 0;
        using var conn = new NpgsqlConnection(this.objectsInfo.ConnectionString);
        conn.Open();

        var batch = new NpgsqlBatch(conn);

        foreach (var d in data)
        {
            var bcmd = new NpgsqlBatchCommand($"""
                INSERT INTO {this.objectsInfo.TargetTableFullName} (
                    id, name, date, number, type, kind, updatedate
                )
                VALUES (
                    @id, @name, @date, @number, @type, @kind, @updatedate
                );
                """
            );

            bcmd.Parameters.AddWithValue("@id", d.Id);
            bcmd.Parameters.AddWithValue("@name", d.Name);
            bcmd.Parameters.AddWithValue("@date", d.Date);
            bcmd.Parameters.AddWithValue("@number", d.Number);
            bcmd.Parameters.AddWithValue("@type", d.Type);
            bcmd.Parameters.AddWithValue("@kind", d.Kind);
            bcmd.Parameters.AddWithValue("@updatedate", d.UpdateDate);

            batch.BatchCommands.Add(bcmd);
            curBufferRecs += 1;
            if (curBufferRecs >= targetBatchSize)
            {
                recordCount += batch.ExecuteNonQuery();
                Log.Information("Записано в БД {recordCount} из {recordsInSourceBatch}", recordCount, data.Count);
                curBufferRecs = 0;
                batch.BatchCommands.Clear();
            }
        }
        if (curBufferRecs > 0)
        {
            recordCount += batch.ExecuteNonQuery();
            Log.Information("Записано в БД {recordCount} из {recordsInSourceBatch}", recordCount, data.Count);
            batch.BatchCommands.Clear();
        }
        return recordCount;
    }
}