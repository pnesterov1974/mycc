using System.Xml;
using Data;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Import.gar.pgsql;
public class ImportRooms: BasePgSql
{
    protected ImportObjectsInfo objectsInfo { get; set; }
    public ImportRooms(ImportObjectsInfo objectsInfo) => this.objectsInfo = objectsInfo;

    // TODO: FineTune: clearInAdvance, try-catch, log_events backward_rename ??
    public int DoImportData(bool clearDestTableInAdvance = true)
    {
        if (clearDestTableInAdvance)
        {
            bool cl = this.ClearDestTable(this.objectsInfo.ConnectionString, this.objectsInfo.TargetTableFullName);
        }

        int TotalRecords = 0;
        foreach (var s in this.objectsInfo.SourceFilePaths)
        {
            Log.Information("Импорт из файла {file}", s.FileFullPath);

            if (File.Exists(s.FileFullPath))
            {
                Log.Information("Файл {file} существует", s.FileFullPath);
                List<Rooms> data = this.ReadSourceDataOneFile(s.FileFullPath);
                TotalRecords += this.WriteDataOneFileBatches(data, s.FileName);
            }
            else
            {
                Log.Warning("Файл {file} НЕ существует, обработка пропускается", s.FileFullPath);
            }
        }
        return TotalRecords;
    }

    private List<Rooms> ReadSourceDataOneFile(string fileFullPath)
    {
        List<Rooms> res = new List<Rooms>();
        Log.Information("Обработка файла ...{file}", fileFullPath);
        XmlDocument xDoc = new XmlDocument();
        xDoc.Load(fileFullPath);
        XmlElement? xRoot = xDoc.DocumentElement;
        if (xRoot != null)
        {
            int i = 0;
            foreach (XmlElement xnode in xRoot)
            {
                XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                string id = idAttr.Value;

                XmlNode ObjectIdAttr = xnode.Attributes.GetNamedItem("OBJECTID");
                string objectId = ObjectIdAttr.Value;

                XmlNode ObjectGuidAttr = xnode.Attributes.GetNamedItem("OBJECTGUID");
                string objectGuid = ObjectGuidAttr.Value;

                XmlNode ChangeIdAttr = xnode.Attributes.GetNamedItem("CHANGEID");
                string changeId = ChangeIdAttr.Value;

                XmlNode NumberAttr = xnode.Attributes.GetNamedItem("NUMBER");
                string number = NumberAttr.Value;

                XmlNode RoomTypeAttr = xnode.Attributes.GetNamedItem("ROOMTYPE");
                string roomType = RoomTypeAttr.Value;

                XmlNode OperTypeIdAttr = xnode.Attributes.GetNamedItem("OPERTYPEID");
                string operTypeid = OperTypeIdAttr.Value;

                XmlNode PrevIDAttr = xnode.Attributes.GetNamedItem("PREVID");
                string prevId = PrevIDAttr.Value;

                XmlNode UpdateDateAttr = xnode.Attributes.GetNamedItem("UPDATEDATE");
                string updateDate = UpdateDateAttr.Value;

                XmlNode StartDateAttr = xnode.Attributes.GetNamedItem("STARTDATE");
                string startDate = StartDateAttr.Value;

                XmlNode EndDateAttr = xnode.Attributes.GetNamedItem("ENDDATE");
                string endDate = EndDateAttr.Value;

                XmlNode IsActualAttr = xnode.Attributes.GetNamedItem("ISACTUAL");
                string isActual = IsActualAttr.Value;

                XmlNode IsActiveAttr = xnode.Attributes.GetNamedItem("ISACTIVE");
                string isActive = IsActiveAttr.Value;

                i += 1;
                res.Add(new Rooms
                {
                    Id = id,
                    ObjectId = objectId,
                    ObjectGuid = objectGuid,
                    ChangeId = changeId,
                    Number = number,
                    RoomType = roomType,
                    OperTypeID = operTypeid,
                    PrevId = prevId,
                    UpdateDate = updateDate,
                    StartDate = startDate,
                    EndDate = endDate,
                    IsActual = isActual,
                    IsActive = isActive
                }
                );
            }
        }
        else
        {
            Log.Information("Элементы не найдены");
        }
        return res;
    }

    private int WriteDataOneFileBatches(List<Rooms> data, string fileName, int bufferRecs = 20000)
    {
        int RecordCount = 0;
        int CurBufferRecs = 0;
        Log.Information("Необходимо записать в таблицу {cnt} строк", data.Count);
        using var conn = new NpgsqlConnection(this.objectsInfo.ConnectionString);
        conn.Open();

        var batch = new NpgsqlBatch(conn);

        foreach (var d in data)
        {
            var bcmd = new NpgsqlBatchCommand($"""
                INSERT INTO {this.objectsInfo.TargetTableFullName} (
                    id, objectId, objectguid, changeid, number, roomtype, opertypeid, previd, updatedate,
                    startdate, enddate, isactual, isactive
                )
                VALUES (
                    @id, @objectId, @objectguid, @changeid, @number, @roomtype, @opertypeid, @previd, @updatedate,
                    @startdate, @enddate, @isactual, @isactive
                );
                """
            );

            bcmd.Parameters.AddWithValue("@id", d.Id);
            bcmd.Parameters.AddWithValue("@objectid", d.ObjectId);
            bcmd.Parameters.AddWithValue("@objectguid", d.ObjectGuid);
            bcmd.Parameters.AddWithValue("@changeid", d.ChangeId);
            bcmd.Parameters.AddWithValue("@number", d.Number);
            bcmd.Parameters.AddWithValue("@roomtype", d.RoomType);
            bcmd.Parameters.AddWithValue("@opertypeid", d.OperTypeID);
            bcmd.Parameters.AddWithValue("@previd", d.PrevId);
            bcmd.Parameters.AddWithValue("@updatedate", d.UpdateDate);
            bcmd.Parameters.AddWithValue("@startdate", d.StartDate);
            bcmd.Parameters.AddWithValue("@enddate", d.EndDate);
            bcmd.Parameters.AddWithValue("@isactual", d.IsActual);
            bcmd.Parameters.AddWithValue("@isactive", d.IsActive);

            batch.BatchCommands.Add(bcmd);
            CurBufferRecs += 1;
            if (CurBufferRecs >= bufferRecs)
            {
                RecordCount += batch.ExecuteNonQuery();
                Log.Information("{table} import: imported {recs}", this.objectsInfo.TargetTableFullName, RecordCount);
                CurBufferRecs = 0;
                batch.BatchCommands.Clear();
            }
        }
        if (CurBufferRecs > 0)
        {
            RecordCount += batch.ExecuteNonQuery();
            Log.Information("{table} import: imported {recs}", this.objectsInfo.TargetTableName, RecordCount);
            batch.BatchCommands.Clear();
        }
        Log.Information("Загружено записей {recs} из {file}", RecordCount, fileName);
        return RecordCount;
    }
}