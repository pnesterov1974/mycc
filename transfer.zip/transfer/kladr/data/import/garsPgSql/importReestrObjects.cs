using System.Xml;
using Data;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Import.gar.pgsql;
public class ImportReestrObjects : BasePgSql
{
    protected ImportObjectsInfo objectsInfo { get; set; }
    public ImportReestrObjects(ImportObjectsInfo objectsInfo) => this.objectsInfo = objectsInfo;

    public void DoImportData(bool clearDestTableInAdvance = true)
    {
        if (clearDestTableInAdvance)
        {
            bool cl = this.ClearDestTable(this.objectsInfo.ConnectionString, this.objectsInfo.TargetTableFullName);
        }

        Log.Information("Начинаю импорт {table} ...", this.objectsInfo.TargetTableName);

        DateTime dtStart = DateTime.Now;
        int totalRecCount = this.ReadSourceDataAllFiles(this.objectsInfo.SourceFilePaths);
        DateTime dtFinish = DateTime.Now;

        TimeSpan duration = dtFinish - dtStart;
        Log.Information(
            "Импорт {table} закончен, всего загружено {records} записей... время обрадоьки: {duration}",
            this.objectsInfo.TargetTableName, totalRecCount, duration
            );
    }

    private int ReadSourceDataAllFiles(List<GarFileInfo> filePaths, int sourceBatchSize = 100000)
    {
        List<ReestrObjects> currentBatch = new List<ReestrObjects>(sourceBatchSize + 1);
        int currentBatchCount = 0;
        int recordCount = 0;
        Log.Information("Размер буфера на считывание {recbatchsize} ...", sourceBatchSize);
        foreach (var gfi in filePaths)
        {
            string filePath = gfi.FileFullPath;
            Log.Information("Обработка файла ...{file}", filePath);
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(filePath);
            XmlElement? xRoot = xDoc.DocumentElement;
            if (xRoot != null)
            {
                foreach (XmlElement xnode in xRoot)
                {
                    XmlNode ObjectIdAttr = xnode.Attributes.GetNamedItem("OBJECTID");
                    string objectId = ObjectIdAttr.Value;

                    XmlNode ObjectGuidAttr = xnode.Attributes.GetNamedItem("OBJECTGUID");
                    string objectGuid = ObjectGuidAttr.Value;

                    XmlNode ChangeIdAttr = xnode.Attributes.GetNamedItem("CHANGEID");
                    string changeId = ChangeIdAttr.Value;

                    XmlNode LevelIdAttr = xnode.Attributes.GetNamedItem("LEVELID");
                    string levelId = LevelIdAttr.Value;

                    XmlNode CreateDateAttr = xnode.Attributes.GetNamedItem("CREATEDATE");
                    string createDate = CreateDateAttr.Value;

                    XmlNode UpdateDateAttr = xnode.Attributes.GetNamedItem("UPDATEDATE");
                    string updateDate = UpdateDateAttr.Value;

                    XmlNode IsActiveAttr = xnode.Attributes.GetNamedItem("ISACTIVE");
                    string isActive = IsActiveAttr.Value;

                    currentBatchCount += 1;

                    currentBatch.Add(new ReestrObjects
                    {
                        ObjectId = objectId,
                        ObjectGuid = objectGuid,
                        ChangeId = changeId,
                        LevelId = levelId,
                        CreateDate = createDate,
                        UpdateDate = updateDate,
                        IsActive = isActive
                    }
                    );
                    if (currentBatchCount >= sourceBatchSize)
                    {
                        Log.Information("Считано из источника {currentBatch} (текущая пачка) -> загрузка в БД", currentBatchCount);
                        recordCount += this.WriteDataOneBatch(currentBatch);
                        Log.Information("Всего обработано {recordCount} записей", recordCount);
                        currentBatchCount = 0;
                        currentBatch = new List<ReestrObjects>(sourceBatchSize + 1);
                    }
                }
            }
            else
            {
                Log.Information("Элементы для файла {filepath} не найдены", filePath);
            }
        }
        if (currentBatchCount > 0)
        {
            recordCount += this.WriteDataOneBatch(currentBatch);
        }
        Log.Information("Всего обработано {recordCount} записей", recordCount);
        return recordCount;
    }

    private int WriteDataOneBatch(List<ReestrObjects> data, int targetBatchSize = 20000)
    {
        int recordCount = 0;
        int curBufferRecs = 0;
        using var conn = new NpgsqlConnection(this.objectsInfo.ConnectionString);
        conn.Open();

        var batch = new NpgsqlBatch(conn);

        foreach (var d in data)
        {
            var bcmd = new NpgsqlBatchCommand($"""
                INSERT INTO {this.objectsInfo.TargetTableFullName} (
                    objectid, objectguid, changeid, levelid, createdate, updatedate, isactive
                )
                VALUES (
                    @objectid, @objectguid, @changeid, @levelid, @createdate, @updatedate, @isactive
                );
                """
            );

            bcmd.Parameters.AddWithValue("@objectid", d.ObjectId);
            bcmd.Parameters.AddWithValue("@objectguid", d.ObjectGuid);
            bcmd.Parameters.AddWithValue("@changeid", d.ChangeId);
            bcmd.Parameters.AddWithValue("@levelid", d.LevelId);
            bcmd.Parameters.AddWithValue("@createdate", d.CreateDate);
            bcmd.Parameters.AddWithValue("@updatedate", d.UpdateDate);
            bcmd.Parameters.AddWithValue("@isactive", d.IsActive);

            batch.BatchCommands.Add(bcmd);
            curBufferRecs += 1;
            if (curBufferRecs >= targetBatchSize)
            {
                recordCount += batch.ExecuteNonQuery();
                Log.Information("Записано в БД {recordCount} из {recordsInSourceBatch}", recordCount, data.Count);
                curBufferRecs = 0;
                batch.BatchCommands.Clear();
            }
        }
        if (curBufferRecs > 0)
        {
            recordCount += batch.ExecuteNonQuery();
            Log.Information("Записано в БД {recordCount} из {recordsInSourceBatch}", recordCount, data.Count);
            batch.BatchCommands.Clear();
        }
        return recordCount;
    }
}