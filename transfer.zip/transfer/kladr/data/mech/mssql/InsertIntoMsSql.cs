using Microsoft.Data.SqlClient;
using static Shared.MyLogger;

namespace Data.mesh.mssql;
public class InsertIntoMsSql
{
    protected string connectionString { get; set; } = string.Empty;
    protected string selectSql { get; set; } = string.Empty;
    public string TargetTableName { get; set; }
    public string TargetSchemaName { get; set; }
    private string TargetFullName
    {
        get => string.Join('.', this.TargetSchemaName, this.TargetTableName);
    }
    public InsertIntoMsSql(string connectionString, string selectSql, string targetSchemaName, string targetTableName)
    {
        this.connectionString = connectionString;
        this.selectSql = selectSql;
        this.TargetSchemaName = targetSchemaName;
        this.TargetTableName = targetTableName;
    }

    public void InsertInto(bool truncateTableInAdvance = true)
    {
        //ClearTable clt = new ClearTable(this.connectionString, this.TargetSchemaName, this.TargetTableName);
        //if (truncateTableInAdvance & clt.ClearDestTable())
        if (truncateTableInAdvance) // TRUNCATE TABLE HERE
        {
            string _Sql = $"INSERT INTO {this.TargetFullName} SELECT q.* FROM (\n{this.selectSql}\n) q;";
            Log.Information("Материализация SELECT-запроса");
            Log.Debug("\n {sql}", _Sql);
            int RecordCount = 0;
            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(_Sql, conn))
                {
                    try
                    {
                        conn.Open();
                        RecordCount = cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Ошибка чтения меты для модели: {@message}", ex.Message);
                    }
                    finally
                    {
                        if (RecordCount > 0)
                        {
                            Log.Information("OK - Материализовано: {records} в объект {dbobject}", RecordCount, this.TargetFullName);
                        }
                    }
                }
            }
        }
    }

    private void DbLogTransformation(bool success) // LOG_TO_DB Prototype
    {
        using (SqlConnection conn = new SqlConnection(this.connectionString))
        {
            string isql = $"INSERT INTO dbo.TransformationLog(dttm, TransformationName, Status) VALUES (GETDATE(), '{success}', {success})";
            using (SqlCommand cmd = new SqlCommand(isql, conn))
            {
                try
                {
                    conn.Open();
                    int q = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Log.Information("Ошибка трансформации: {@message}", ex.Message);
                }
            }
        }
    }
}
