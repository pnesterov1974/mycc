using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Data.mesh.pgsql;
public class MergePgSql: BasePgSql
{
    protected TransformObjectInfo objectInfo { get; set; }

    public MergePgSql(TransformObjectInfo toi) => objectInfo = toi;

    public void DoMerge() // INSERT INTO ON CONFLICT
    {
        string _Sql = $"INSERT INTO {this.objectInfo.TargetTableFullName} SELECT q.* FROM (\n{this.objectInfo.SelectSql}\n) q;";
        Log.Information("Материализация SELECT-запроса");
        Log.Debug("\n {sql}", _Sql);
        int RecordCount = 0;
        DateTime dtStart = DateTime.Now;
        using (var conn = new NpgsqlConnection(this.objectInfo.ConnectionString))
        {
            conn.Open();
            using (var cmd = new NpgsqlCommand(_Sql, conn))
            {
                try
                {
                    RecordCount = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Log.Error("{table} ошибка импорта: \n", this.objectInfo.TargetTableFullName, ex.Message);
                }
            }
            DateTime dtFinish = DateTime.Now;
            TimeSpan duration = dtFinish - dtStart;
            Log.Information("{table} завершено ок за {duration}, обработано {recs} записей", this.objectInfo.TargetTableFullName, duration, RecordCount);
        }
    }
}