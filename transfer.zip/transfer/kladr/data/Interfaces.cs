using System.Data;

namespace Data;

public interface IDataForJson
{
    public DataTable Data { get; }
    public void Read();
}
