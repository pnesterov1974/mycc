using System.Text;

namespace Shared;

public interface IObjectInfo
{
    public string TargetTableName { get; set; }
    public string TargetSchemaName { get; set; }
    public int BufferRecs { get; set; }
    public string ConnectionString { get; set; }
    public string TargetTableFullName { get; }
    public string ToString();
}

public class ImportObjectInfo : IObjectInfo
{
    public string TargetTableName { get; set; }
    public string TargetSchemaName { get; set; }
    public int BufferRecs { get; set; }
    public string SourceFileName { get; set; }
    public string SourceDirPath { get; set; }
    public string ConnectionString { get; set; }

    public string TargetTableFullName
    {
        get => string.Join('.', this.TargetSchemaName, this.TargetTableName);
    }

    public string SourceFilePath
    {
        get => Path.Join(SourceDirPath, SourceFileName);
    }

    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        sb.Append($"DestinationSchemaName:\t{this.TargetSchemaName}\n");
        sb.Append($"DestinationTableName:\t{this.TargetTableName}\n");
        sb.Append($"BufferRecs:\t{this.BufferRecs}\n");
        sb.Append($"SourceFileName:\t{this.SourceFileName}\n");
        sb.Append($"SourceDirPath:\t{this.SourceDirPath}\n");
        sb.Append($"ConnectionString:\t{this.ConnectionString}\n");
        return sb.ToString();
    }
}