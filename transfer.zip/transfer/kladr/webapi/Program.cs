using Data.mesh.mssql;
using Data.mesh.pgsql;
using Shared;
using Shared.Transformations.mssql;
using Shared.Transformations.pqsql;
using static Shared.MyLogger;

const TargetDb tdb = TargetDb.pgsql;
string connString = ConnectionString.GetConnectionString(tdb);
InitLogger();

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseDeveloperExceptionPage();
app.UseSwagger();
app.UseSwaggerUI();

app.MapGet("/", () => "Hello World!");

app.MapGet("/socrbase", () =>
{
    switch (tdb)
    {
        case TargetDb.mssql:
            {
                MsSqlData msd = new MsSqlData(connString, SocrBaseMsSql.SQL);
                return msd.AsJson;
            }
        case TargetDb.pgsql:
            {
                PgSqlData psd = new PgSqlData(connString, SocrBasePgSql.SQL);
                return psd.AsJson;
            }
    }
});

app.MapGet("/altnames", () =>
{
    switch (tdb)
    {
        case TargetDb.mssql:
            {
                MsSqlData msd = new MsSqlData(connString, AltNamesMsSql.SQL);
                return msd.AsJson;
            }
        case TargetDb.pgsql:
            {
                PgSqlData psd = new PgSqlData(connString, AltNamesPgSql.SQL);
                Log.Information(AltNamesPgSql.SQL);
                return psd.AsJson;
            }
    }
});

app.MapGet("/kladr", () =>
{
    switch (tdb)
    {
        case TargetDb.mssql:
            {
                MsSqlData msd = new MsSqlData(connString, KladrMsSql.SQL);
                return msd.AsJson;
            }
        case TargetDb.pgsql:
            {
                //Log.Information(KladrPgSql.SQL);
                PgSqlData psd = new PgSqlData(connString, KladrPgSql.SQL);
                return psd.AsJson;
            }
    }
});

app.MapGet("/street", () =>
{
    switch (tdb)
    {
        case TargetDb.mssql:
            {
                MsSqlData msd = new MsSqlData(connString, StreetMsSql.SQL);
                return msd.AsJson;
            }
        case TargetDb.pgsql:
            {
                PgSqlData psd = new PgSqlData(connString, StreetPgSql.SQL);
                return psd.AsJson;
            }
    }
});

app.MapGet("/doma", () =>
{
    switch (tdb)
    {
        case TargetDb.mssql:
            {
                MsSqlData msd = new MsSqlData(connString, DomaMsSql.SQL);
                return msd.AsJson;
            }
        case TargetDb.pgsql:
            {
                PgSqlData psd = new PgSqlData(connString, DomaPgSql.SQL);
                return psd.AsJson;
            }
    }
});

app.Run();
