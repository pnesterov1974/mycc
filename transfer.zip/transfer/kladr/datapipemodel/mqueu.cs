namespace Model;
// https://metanit.com/sharp/tutorial/4.7.php
public class QModel
{
    public Queue<Model> MQ { get; set; }
    public QModel()
    {
        MQ = new Queue<Model>();
    }
    public void AddToQModel(IModel model)
    {
        MQ.Enque(model);
    }
    public void ClearQModel(IModel model)
    {
        MQ.Clear();
    }
    public void ProcessQModel()
    {
        foreach(IModel model in MQ)
        {
            ProcessItem(MQ.Dequeue(model));
        }
    }
    public ProcessItem(IModel model)
    {
        // Launch Model
        // After of before serialization ??
        //
    }
}