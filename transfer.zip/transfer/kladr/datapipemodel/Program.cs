﻿using System.Xml.Serialization;
using System.Text.Json;
using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;
using Tomlet;
using Model;

Console.WriteLine("Hello, World!");

string destDirPath = Path.Join(Directory.GetCurrentDirectory(), "_dest");
if (!Path.Exists(destDirPath))
{
    Directory.CreateDirectory(destDirPath);
}

Model1 model1 = new Model1();
XmlSerializer xmlSerializer1 = new XmlSerializer(typeof(Model1));
using (FileStream fs = new FileStream(Path.Join(destDirPath, "model1.xml"), FileMode.OpenOrCreate))
{
    xmlSerializer1.Serialize(fs, model1);
    Console.WriteLine("Object model1 has been serialized in XML");
}

Model2 model2 = new Model2();
XmlSerializer xmlSerializer2 = new XmlSerializer(typeof(Model2));
using (FileStream fs = new FileStream(Path.Join(destDirPath, "model2.xml"), FileMode.OpenOrCreate))
{
    xmlSerializer2.Serialize(fs, model2);
    Console.WriteLine("Object model2 has been serialized in XML");
}

Model3 model3 = new Model3();
XmlSerializer xmlSerializer3 = new XmlSerializer(typeof(Model3));
using (FileStream fs = new FileStream(Path.Join(destDirPath, "model3.xml"), FileMode.OpenOrCreate))
{
    xmlSerializer3.Serialize(fs, model3);
    Console.WriteLine("Object model3 has been serialized in XML");
}

// List<IModel> ls = new List<IModel>();
// ls.Add(new Model1());
// ls.Add(new Model2());
// ls.Add(new Model3());

// XmlSerializer xmlSerializerList = new XmlSerializer(typeof(List<IModel>));
// using (FileStream fs = new FileStream(Path.Join(destDirPath, "modelList.xml"), FileMode.OpenOrCreate))
// {
//     xmlSerializerList.Serialize(fs, ls);
//     Console.WriteLine("Object ls has been serialized in XML");
// }

string json1 = JsonSerializer.Serialize(model1);
File.WriteAllText(Path.Join(destDirPath, "model1.json"), json1);
Console.WriteLine("Object model1 has been serialized in JSON");

string json2 = JsonSerializer.Serialize(model2);
File.WriteAllText(Path.Join(destDirPath, "model2.json"), json1);
Console.WriteLine("Object model2 has been serialized in JSON");

string json3 = JsonSerializer.Serialize(model3);
File.WriteAllText(Path.Join(destDirPath, "model3.json"), json1);
Console.WriteLine("Object model3 has been serialized in JSON");

var serializer1 = new SerializerBuilder()
    .WithNamingConvention(CamelCaseNamingConvention.Instance)
    .Build();
var yaml1 = serializer1.Serialize(model1);
File.WriteAllText(Path.Join(destDirPath, "model1.yaml"), yaml1);
Console.WriteLine("Object model1 has been serialized in YAML");

string tomlString = TomletMain.TomlStringFrom(model1);
File.WriteAllText(Path.Join(destDirPath, "model1.toml"), tomlString);
Console.WriteLine("Object model1 has been serialized in TOML");