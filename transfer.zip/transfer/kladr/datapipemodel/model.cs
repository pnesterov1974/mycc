namespace Model;

public interface IModel
{
    public string ModelName { get; set; }
    public string[] ModelInDependencies { get; set; }
    public string ModelSql { get; set; }
    public string[] ModelParameters { get; set; }
}

public class Model1 : IModel
{
    public string ModelName { get; set; } = "KladrAreasLevel1Master";
    public string[] ModelInDependencies { get; set; } = new string[3] {"m1", "m2", "m3"};
    public string ModelSql { get; set; } = """
        SELECT
            area_code,
            kladr_name,
            kladr_socr,
            kladr_ocatd,
            kladr_status
        FROM
            public.kladr_1
            WHERE kladr_level = 1;
    """;
    public string[] ModelParameters { get; set; } = new string[4] {"p1", "p2", "p3", "p4"};
}

public class Model2 : IModel
{
    public string ModelName { get; set; } = "KladrDistrictLevel2Master";
    public string[] ModelInDependencies { get; set; } = new string[3] {"m11", "m22", "m33"};
    public string ModelSql { get; set; } = """
        SELECT
            area_code,
            district_code,
            kladr_name,
            kladr_socr,
            kladr_ocatd,
            kladr_status
        FROM
            public.kladr_1
            WHERE kladr_level = 2;
    """;
    public string[] ModelParameters { get; set; } = new string[4] {"p12", "p22", "p32", "p42"};
}

public class Model3 : IModel
{
    public string ModelName { get; set; } = "KladrCityLevel3Master";
    public string[] ModelInDependencies { get; set; } = new string[3] {"m12", "m22", "m32"};
    public string ModelSql { get; set; } = """
        SELECT
            area_code,
            district_code,
            city_code,
            kladr_name,
            kladr_socr,
            kladr_ocatd,
            kladr_status
        FROM
            public.kladr_1
        WHERE kladr_level = 3;
    """;
    public string[] ModelParameters { get; set; } = new string[4] {"p13", "p23", "p33", "p43"};
}


