using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;
using YamlModels;

namespace YamlOps;
static class YamlOperations
{
    public static void SaveTransformationModel(TransformationModel tm, string filePath)
    {
        var serializer = new SerializerBuilder()
            .WithNamingConvention(CamelCaseNamingConvention.Instance)
            .Build();
        var yaml = serializer.Serialize(tm);
        File.WriteAllText(filePath, yaml);
    }

    public static void SaveConnectionAsset(ConnectionAsset ca, string filePath)
    {
        var serializer = new SerializerBuilder()
            .WithNamingConvention(CamelCaseNamingConvention.Instance)
            .Build();
        var yaml = serializer.Serialize(ca);
        File.WriteAllText(filePath, yaml);
    }
    public static void ReadTransformationModel(string filePath)
    {
        string yaml = File.ReadAllText(filePath);
        var deserializer = new DeserializerBuilder()
            .WithNamingConvention(CamelCaseNamingConvention.Instance)  // see height_in_inches in sample yml 
            .Build();

        var ds = deserializer.Deserialize<TransformationModel>(yaml);
        // System.Console.WriteLine($"{ds.ModelName} in {ds.TargetName}");
        // System.Console.WriteLine($"SQL : {ds.SQL}");
    }

    public static void ReadConnectionAsset(string filePath)
    {
        string yaml = File.ReadAllText(filePath);
        var deserializer = new DeserializerBuilder()
            //.WithNamingConvention(UnderscoredNamingConvention.Instance)
            .WithNamingConvention(CamelCaseNamingConvention.Instance)  // see height_in_inches in sample yml 
            .Build();

        var ds = deserializer.Deserialize<ConnectionAsset>(yaml);
        // System.Console.WriteLine($"{ds.ModelName} in {ds.TargetName}");
        // System.Console.WriteLine($"SQL : {ds.SQL}");
    }
}
