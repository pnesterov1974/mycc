using System.Data;
using System.Text;
//using Newtonsoft.Json;
using Npgsql;
using static Shared.MyLogger;

namespace Datamech.pgsql;

public class EtlWork
{
    public ETLObjectInfo Etlo { get; set; }

    private DataTable sourceStru;

    public void Work()
    {
        //bool sourceConnOk = this.tryMsSqlDbConnection(this.Etlo.SourceConnectionString);
        //bool targetConnOk = this.tryMsSqlDbConnection(this.Etlo.TargetConnectionString);

        //if (targetConnOk)
        //{
        //    bool ex = this.isTargetObjectExists();
        //}

        //if (sourceConnOk)
        {
            getSourceDBStru();
            if (this.sourceStru != null)
            {
                Dictionary<string, string> fl = this.getFieldList();
                foreach (var kv in fl)
                {
                    Log.Information("k: {k}\t v: {v}", kv.Key, kv.Value);
                }
                // string crt = this.getCreateObjectSql(fl);
                // Log.Information("{crt}", crt);
                // this.executeCreateObject(crt);
            }
        }
    }

    private bool tryPgSqlDbConnection(string connectionString)
    {
        Log.Information("Проверка подключения по строке: {@connString}", connectionString);
        try
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                string connInfo = this.getMsSqlConnectionInformation(conn);
                Log.Debug("Информация о соединении:\n {conn}", connInfo);
                using (NpgsqlCommand cmd = new NpgsqlCommand("SELECT GETDATE();", conn))
                {
                    cmd.CommandType = CommandType.Text;
                    var dt = cmd.ExecuteScalar();
                    Log.Information("Подключено успешно...{dt}", dt);
                    return true;
                }
            }
        }
        catch (Exception ex)
        {
            Log.Error("Ошибка проверки подключения с Базе Данных:\n SQL:{message}", ex.Message);
            return false;
        }
    }

    private string getMsSqlConnectionInformation(NpgsqlConnection cnn)
    {
        StringBuilder sb = new StringBuilder(1024);

        sb.AppendLine("Connection String: " + cnn.ConnectionString);
        sb.AppendLine("State: " + cnn.State.ToString());
        sb.AppendLine("Connection Timeout: " + cnn.ConnectionTimeout.ToString());
        sb.AppendLine("Database: " + cnn.Database);
        sb.AppendLine("Data Source: " + cnn.DataSource);
        sb.AppendLine("Server Version: " + cnn.ServerVersion);
        //sb.AppendLine("Workstation ID: " + cnn.WorkstationId);

        return sb.ToString();
    }

    private void getSourceDBStru()
    {
        Log.Information("Загрузка схемы данных источника ...");
        Log.Debug("Загрузка схемы из : \n{connstr}", this.Etlo.SourceConnectionString);
        Log.Debug("SQL : \n{connstr}", this.Etlo.SourceSelectSql);
        this.sourceStru = new DataTable();

        using (NpgsqlConnection conn = new NpgsqlConnection(this.Etlo.SourceConnectionString))
        {
            using (NpgsqlCommand cmd = new NpgsqlCommand(this.Etlo.SourceSelectSql, conn))
            {
                cmd.CommandTimeout = 100000;
                try
                {
                    conn.Open();
                    // using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.KeyInfo))
                    // {
                    //     this.sourceStru = rdr.GetSchemaTable();
                    //     Log.Information("Схема данных успешно загружена");
                    //     string json = JsonConvert.SerializeObject(this.sourceStru, Formatting.Indented);
                    //     Log.Debug("DBStru in json format:\n{json}", json);
                    // }
                }
                catch (Exception ex)
                {
                    Log.Error("Ошибка загрузки схемы данных.");
                    Log.Debug("{errmes}", ex.Message);
                    this.sourceStru = null;
                }
            }
        }
    }

    public Dictionary<string, string> getFieldList()
    {
        int ColumnNameColIdx = this.sourceStru.Columns["BaseColumnName"].Ordinal;
        int DataTypeNameColIdx = this.sourceStru.Columns["DataTypeName"].Ordinal;
        int ColumnSizeColIdx = this.sourceStru.Columns["ColumnSize"].Ordinal;

        Dictionary<string, string> Fields = new Dictionary<string, string>();

        Log.Information("first: {col} second: {type}", ColumnNameColIdx, DataTypeNameColIdx);
        foreach (DataRow dataRow in this.sourceStru.Rows)
        {
            string columnName = dataRow[ColumnNameColIdx].ToString();
            string columnType = dataRow[DataTypeNameColIdx].ToString();
            string columnSize = dataRow[ColumnSizeColIdx].ToString();

            string columnTypeSized = string.Empty;

            if (columnType.Equals("varchar") || columnType.Equals("nvarchar"))
            {
                columnTypeSized = $"{columnType}({columnSize})";
            }
            else
            {
                columnTypeSized = columnType;
            }
            Fields.Add(columnName, columnTypeSized);
            Log.Debug("columnName: {col} columnType: {type}", columnName, columnTypeSized);
        }
        return Fields;
    }

}
