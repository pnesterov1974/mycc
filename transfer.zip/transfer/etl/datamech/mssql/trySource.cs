﻿using static Shared.MyLogger;

namespace Mssql.datamech;

public class Etl 
{
    public ETLObjectInfo etlo { get; set; }

    private DataTable sourceStru;

    public void Work()
    {
        bool sourceConnOk = this.tryMsSqlDbConnection(this.ETLObjectInfo.SourceConnectionString);
        bool targetConnOk = this.tryMsSqlDbConnection(this.ETLObjectInfo.TargetConnectionString);

        if (sourceConnOk)
        {
            this.getSourceDBStru();
        }
    }

    private bool tryMsSqlDbConnection(string connectionString)
    {
        Log.Information("Проверка подключения по строке: {@connString}", connectionString);
        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string connInfo = this.getMsSqlConnectionInformation(conn);
                Log.Debug("Информация о соединении:\n {conn}", connInfo);
                using (SqlCommand cmd = new SqlCommand("SELECT GETDATE();", conn))
                {
                    cmd.CommandType = CommandType.Text;
                    var dt = cmd.ExecuteScalar();
                    Log.Information("Подключено успешно...{dt}", dt);
                    return true;
                }
            }
        }
        catch (Exception ex)
        {
            Log.Error("Ошибка проверки подключения с Базе Данных:\n SQL:{message}", ex.Message);
            return false;
        }
    }

    private string getMsSqlConnectionInformation(SqlConnection cnn)
    {
        StringBuilder sb = new StringBuilder(1024);

        sb.AppendLine("Connection String: " + cnn.ConnectionString);
        sb.AppendLine("State: " + cnn.State.ToString());
        sb.AppendLine("Connection Timeout: " + cnn.ConnectionTimeout.ToString());
        sb.AppendLine("Database: " + cnn.Database);
        sb.AppendLine("Data Source: " + cnn.DataSource);
        sb.AppendLine("Server Version: " + cnn.ServerVersion);
        sb.AppendLine("Workstation ID: " + cnn.WorkstationId);

        return sb.ToString();
    }

    private getSourceDBStru()
    {
        Log.Information("Загрузка схемы данных источника ...");
        Log.Debug("Загрузка схемы из : \n{connstr}", this.ETLObjectInfo.SourceConnectionString);
        Log.Debug("SQL : \n{connstr}", this.ETLObjectInfo.SourceSelectSql);
        this.sourceStru = new DataTable();

        using (SqlConnection conn = new SqlConnection(this.ETLObjectInfo.SourceConnectionString))
        {
            using (SqlCommand cmd = new SqlCommand(this.ETLObjectInfo.SourceSelectSql, conn))
            {
                try
                {
                    conn.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.KeyInfo))
                    {
                        this.sourceStru = rdr.GetSchemaTable();
                        Log.Information("Схема данных успешно загружена");
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Ошибка загрузки схемы данных.");
                    Log.Debug("{errmes}", ex.Message);
                    this.sourceStru = null;
                }
            }
        }
    }

    private bool isTargetObjectExists()  // TODO
    {
        string sql = $"""
            IF OBJECT_ID(N'{this.ETLObjectInfo.TargetTableFullName}', N'U') IS NOT NULL
            BEGIN
                SELECT 1 AS res ELSE SELECT 0 AS res;
            END
        """;
        return true;
    }
}
