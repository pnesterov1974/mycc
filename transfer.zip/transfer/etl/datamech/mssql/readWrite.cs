namespace Mssql.readwrite;

public class First
{
    public First()
    {
        ;
    }
}