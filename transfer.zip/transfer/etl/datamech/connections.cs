using Microsoft.Data.SqlClient;
using Npgsql;
using Shared;

namespace Datamech;

public static class ConnectionString
{
    //string pgConnectionString = "Host=localhost;Username=postgres;Password=my_pass;Database=kladr";
    //string MsSqlconnectionString = "Data Source=192.168.1.79,1433;Initial Catalog=kladr;User ID=sa;Password=Exptsci123;Trust Server Certificate=True;Connection Timeout=500";
    //string MsSqlConnectionString = "Data Source=ETL-SSIS-D-02;Initial Catalog=kladr;Integrated Security=True;Pooling=True;Trust Server Certificate=True;Connection Timeout=500";
    public static string GetConnectionString(TargetDb dbs = TargetDb.mssql)
    {
        switch (dbs)
        {
            case TargetDb.mssql:
            {
                return getMsSqlConnectionString();
            }
            case TargetDb.pgsql:
            {
                 return getPgSqlConnectionString();
            }
            default:
            {
                return getMsSqlConnectionString();
            }
        }
    } 
    private static string getMsSqlConnectionString()
    {
        SqlConnectionStringBuilder sqb = new SqlConnectionStringBuilder
        {
            ApplicationName = "GEO DataPipe Application",
            ConnectTimeout = 500,
            DataSource = "ETL-SSIS-D-02",
            InitialCatalog = "kladr",
            IntegratedSecurity = true,
            Pooling = true,
            TrustServerCertificate = true
        };
        return sqb.ToString();
    }

    private static string getPgSqlConnectionString()
    { 
        NpgsqlConnectionStringBuilder sqb = new NpgsqlConnectionStringBuilder
        {
            ApplicationName = "GEO DataPipe Application",
            Host = "localhost",
            Username = "postgres",
            Password = "my_pass",
            Database = "kladr"
        };
        return sqb.ToString();
    }
}