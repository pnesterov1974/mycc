using System.Text;

namespace Shared;

public struct TransformObjectInfo
{
    public string TargetTableName;
    public string TargetSchemaName;
    public string SelectSql;
    public string ConnectionString;

    public readonly string TargetTableFullName
    {
        get => string.Join('.', this.TargetSchemaName, this.TargetTableName);
    }

    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        sb.Append($"DestinationSchemaName:\t{this.TargetSchemaName}\n");
        sb.Append($"DestinationTableName:\t{this.TargetTableName}\n");
        sb.Append($"SQL:\n{this.SelectSql}\n");
        sb.Append($"ConnectionString:\t{this.ConnectionString}\n");
        return sb.ToString();
    }
}
