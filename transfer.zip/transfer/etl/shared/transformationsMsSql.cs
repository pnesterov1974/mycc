namespace Shared.Transformations.mssql;

public static class SocrBaseMsSql
{
    public static string ModelName = "SocrBase";
    public static string ConnectionName = "KladrConnection";
    public static string TargetTableName = "[socrbase_t]";
    public static string TargetSchemaName = "dbo";
    public static string SQL = """
            SELECT [LEVEL],
                   [SCNAME],
                   [SOCRNAME],
                   [KOD_T_ST]
            FROM dbo.[SOCRBASE]
        """;
}

public static class AltNamesMsSql
{
    public static string ModelName = "AltNames";
    public static string ConnectionName = "KladrConnection";
    public static string TargetTableName = "[altnames_t]";
    public static string TargetSchemaName = "dbo";
    public static string SQL = """
            SELECT [OLDCODE],
                   [NEWCODE],
                   [LEVEL]
            FROM dbo.[ALTNAMES]
        """;
}

public static class KladrMsSql
{
    public static string ModelName = "Kladr";
    public static string ConnectionName = "KladrConnection";
    public static string TargetTableName = "[kladr_t]";
    public static string TargetSchemaName = "dbo";
    public static string SQL = """
            SELECT [CODE],
                   [NAME],
                   [SOCR],
                   [INDEX],
                   [GNINMB],
                   [UNO],
                   [OCATD],
                   [STATUS]
            FROM dbo.[KLADR]
        """;
}

public static class StreetMsSql
{
    public static string ModelName = "Street";
    public static string ConnectionName = "KladrConnection";
    public static string TargetTableName = "[street_t]";
    public static string TargetSchemaName = "dbo";
    public static string SQL = """
            SELECT TOP 1000 [CODE],
                   [NAME],
                   [SOCR],
                   [INDEX],
                   [GNINMB],
                   [UNO],
                   [OCATD]
            FROM dbo.[STREET]
        """;
}

public static class DomaMsSql
{
    public static string ModelName = "Doma";
    public static string ConnectionName = "KladrConnection";
    public static string TargetTableName = "[doma_t]";
    public static string TargetSchemaName = "dbo";
    public static string SQL = """
            SELECT TOP 1000 [CODE],
                   [NAME],
                   [KORP],
                   [SOCR],
                   [INDEX],
                   [GNINMB],
                   [UNO],
                   [OCATD]
            FROM dbo.[DOMA]
        """;
}

