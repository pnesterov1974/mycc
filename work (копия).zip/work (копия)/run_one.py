import os, sys, argparse

from logger_conf import logger
from extract_sql import ExtractSql
from extract_ssas import ExtractSSAS

def main():
    
    logger.debug(f'Реальный вызов: {sys.argv}')
    logger.debug(f'Executable: {sys.executable}')
    try:
        _ose = os.environ['VIRTUAL_ENV']
    except:
        _ose = 'no_env'
    logger.debug(f'os.environ: {_ose}')

    parser = argparse.ArgumentParser(description='MERLION Git Autocommiter')
    parser.add_argument(
        '-s', '--server', dest="server", required=True, type=str
    )
    parser.add_argument(
        '-d', '--dbname', dest="dbname", required=True, type=str
    )
    parser.add_argument(
        '-k', '--kind', dest="kind", required=True, type=str, choices=['SQL', 'SSAS']
    )
    parser.add_argument(
        '-g', '--group', dest="group", required=True, type=str
    )
    parser.add_argument(
        '-r', '--repo', dest="repo", required=True, type=str
    )

    args = parser.parse_args()

    server = args.server
    dbname = args.dbname
    kind = args.kind
    repo = args.repo
    group = args.group

    print('==== Входящие аргументы =')
    print(f'\tserver: {server}')
    print(f'\tdbname: {dbname}')
    print(f'\tkind: {kind}')
    print(f'\trepo: {repo}')
    print(f'\tgroup: {group}')
    print('\n')

    logger.debug('==== Входящие аргументы =')
    logger.debug(f'\tserver: {server}')
    logger.debug(f'\tdbname: {dbname}')
    logger.debug(f'\tkind: {kind}')
    logger.debug(f'\trepo: {repo}')
    logger.debug(f'\tgroup: {group}')
    logger.debug('\n')
    
    try:
        if kind == 'SQL':
            logger.debug("<<< ------ SQL -----------------------------------------\n")
            logger.debug(f"Обработка: {server}:{dbname} репо {repo}\n")
            extract_sql = ExtractSql(
                server_name=server,
                db_name=dbname,
                group=group,
                repo=repo,
                )
            p = extract_sql.process()
        elif kind == 'SSAS':
            logger.debug("<<< -------- SSAS --------------------------------------\n")
            logger.debug(f"Обработка: {server}:{dbname} репо {repo}\n")
            extract_ssas = ExtractSSAS(
                server_name=server,
                db_name=dbname,
                group=group,
                repo=repo,
                )
            extract_ssas.process()

        sys.exit(0)

    except Exception as ex:
        err_str = f'Скрипт для {repo} завершен с ошибкой:\t {ex}'
        print(err_str)
        sys.exit(err_str)

# -----------------------------------------------------------------------------
if __name__ == "__main__": 
    main()
