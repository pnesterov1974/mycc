import sys
from more_itertools import ilen
from db_connection_pg import DBConnection as dbc
#from db_connection import DBConnection as dbc
from db_selectobject import DBSelectObject
from logger_conf import logger

logger.debug(f'Реальный вызов: {sys.argv}')
logger.debug(f'Executable: {sys.executable}')

def run_main():
    logger.debug('Начало работы ...')
    # process_using_list()
    process_using_iter()
    
def process_using_list():
    e = dbc.get_sqla_engine("kladr")
    d = DBSelectObject(e, "stg", "kladr")
    l = list(d)
    print(len(l))
    df = d.get_df()
    print(df.info())

def process_using_iter():
    e = dbc.get_sqla_engine("kladr")
    d = DBSelectObject(e, "stg", "kladr")
    c = sum(1 for a in d)
    print(c)
    cc = ilen(x for x in d)
    print(cc)
    cc = ilen(d)
    print(cc)

# ---------------------------------------------------------------------------------------
if __name__ == '__main__':
    run_main()