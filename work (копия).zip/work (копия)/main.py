import sys
from logger_conf import logger
#import Pifagor2UkDev_tab_FigureRelation as pif2
import home_kladr as kladr

# TODO
# MsSql touch column names with []
# full join on pkl (agg?)
# select by sqla using table object
# pipe data from source to target db
# selectoblect - генерация проверочных sql а не только базового
# named_tuple in iter analysis
# loguru - onscreen and in file

logger.debug(f'Реальный вызов: {sys.argv}')
logger.debug(f'Executable: {sys.executable}')

def run_main():
    logger.debug('Начало работы ...')
    #pif2.process_using_iter_2()
    kladr.process_using_iter()

# ---------------------------------------------------------------------------------------
if __name__ == '__main__':
    run_main()
