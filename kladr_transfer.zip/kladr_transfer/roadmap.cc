//roadmap

//PgGarImport

// Одинаковое для всех импорт-классоа, вытащить в общий предок
// В кладр - выбор между параллельныим запуском или последовательным => асинронный ADO 

public void DoImport(bool clearDestTableInAdvance = true)
    {
        if (clearDestTableInAdvance)
        {
            bool cl = this.ClearDestTable(this.objectsInfo.ConnectionString, this.objectsInfo.TargetTableFullName);
        }

        Log.Information("Начинаю импорт {table} ...", this.objectsInfo.TargetTableName);

        DateTime dtStart = DateTime.Now;
        int totalRecCount = this.ReadSourceData(this.objectsInfo.SourceFilePaths);
        DateTime dtFinish = DateTime.Now;

        TimeSpan duration = dtFinish - dtStart;
        Log.Information(
            "Импорт {table} закончен, всего загружено {records} записей... время обрадоьки: {duration}",
            this.objectsInfo.TargetTableName, totalRecCount, duration
            );
    }

// TODO:

// tpl actions - review logging read dbf info

// review garMsSql masters xmlUyils. => xmlutils to garMsSql.masters & garMsSql.facts
// + review convertation logging

// using cli -> use for kladr
// using cli -> use for gar

// importClasses review try-catch => try catch in tpl actions.

// ----------------------------------------------------------------------------

// next project 



// Deep Backlog

// mvc make simple repository class (SocrBase)
// common objects to shared = folders ??
// rework logging entries
// kladr 2,3 steps after import aka dbt => etl
// kladr jobs => etl
// model pipeline ondisk-stru, deserialize into class => etl
// socrbase, altnames, nmaps into steps raw vs stage vs ods shemas gar vs kladr dbs

// Backlog
// gar - xsd files to stru ->
// gar import - validate xml by schema
//      https://learn.microsoft.com/ru-ru/dotnet/standard/linq/validate-xsd
//      https://www.c-sharpcorner.com/article/how-to-validate-xml-using-xsd-in-c-sharp/