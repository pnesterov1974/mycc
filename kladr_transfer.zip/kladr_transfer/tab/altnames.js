<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- <link href="src/css/tabulator_site.min.css" rel="stylesheet"> -->
    <link href="src/css/tabulator_bootstrap5.min.css" rel="stylesheet">
    <title>Document</title>
</head>
<body>
    <div id="example-table" class="table-sm"></div>
    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <script type="text/javascript" src="src/js/tabulator.min.js"></script>
    <script type="text/javascript" src="./work.js"></script>
</body>
</html>
