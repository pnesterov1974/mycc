namespace Shared.Transformations.pqsql;

public static class SocrBasePgSql
{
    public static string ModelName = "SocrBase";
    public static string ConnectionName = "KladrPgConnection";
    public static string TargetTableName = "socrbase_t";
    public static string TargetSchemaName = "public";
    public static string SQL = """
            SELECT level, scname, socrname, kod_t_st
            FROM public.socrbase
        """;
}

public static class AltNamesPgSql
{
    public static string ModelName = "AltNames";
    public static string ConnectionName = "KladrPgConnection";
    public static string TargetTableName = "altnames_t";
    public static string TargetSchemaName = "public";
    public static string SQL = """
            SELECT oldcode, newcode, level,
            FROM public.altnames
        """;
}

public static class KladrPgSql
{
    public static string ModelName = "Kladr";
    public static string ConnectionName = "KladrPgConnection";
    public static string TargetTableName = "kladr_t";
    public static string TargetSchemaName = "public";
    public static string SQL = """
            SELECT code,
                   name,
                   socr,
                   index,
                   gninmb,
                   uno,
                   ocatd,
                   status
            FROM public.kladr
        """;
}

public static class StreetPgSql
{
    public static string ModelName = "Street";
    public static string ConnectionName = "KladrConnection";
    public static string TargetTableName = "street_t";
    public static string TargetSchemaName = "public";
    public static string SQL = """
            SELECT code,
                   name,
                   socr,
                   index,
                   gninmb,
                   uno,
                   ocatd
            FROM public.street
            LIMIT 100
        """;
}

public static class DomaPgSql
{
    public static string ModelName = "Doma";
    public static string ConnectionName = "KladrConnection";
    public static string TargetTableName = "doma_t";
    public static string TargetSchemaName = "public";
    public static string SQL = """
            SELECT code,
                   name,
                   korp,
                   socr,
                   index,
                   gninmb,
                   uno,
                   ocatd
            FROM public.doma
            LIMIT 100
        """;
}

public static class Kladr1PgSql
{
    public static string ModelName = "Kladr1";
    public static string ConnectionName = "KladrConnection";
    public static string TargetTableName = "kladr_1";
    public static string TargetSchemaName = "public";
    public static string SQL = """
            SELECT
                k.code AS kladr_code,
                LEFT(k.code, 11) AS kladr_sub_code,
                LEFT(k.code, 2) AS area_code,
                SUBSTRING(k.code, 3, 3) AS district_code,
                SUBSTRING(k.code, 6, 3) AS city_code,
                SUBSTRING(k.code, 9, 3) AS town_code,
                CASE
                    WHEN (SUBSTRING(k.code, 9, 3) <> '000') THEN 4
                    ELSE CASE
                            WHEN (SUBSTRING(k.code, 6, 3) <> '000') THEN 3
                            ELSE CASE
                                    WHEN (SUBSTRING(k.code, 3, 3) <> '000') THEN 2
                                    ELSE 1
                                 END
                         END
                END AS Kladr_level,
                RIGHT(k.code, 2) AS actuality_status,
                k.name AS kladr_name,
                k.socr AS kladr_socr,
                k.index AS kladr_index,
                k.gninmb AS kladr_gninmb,
                k.uno AS kladr_uno,
                k.ocatd AS kladr_ocatd,
                k.status AS kladr_status
            FROM
                public.kladr k
            WHERE
                (RIGHT(k.code, 2) = '00')
        """;
}

public static class Street1PgSql
{
    public static string ModelName = "street1";
    public static string ConnectionName = "KladrConnection";
    public static string TargetTableName = "street_1";
    public static string TargetSchemaName = "public";
    public static string SQL = """
        SELECT s.code AS kladr_code,
               LEFT(s.code, 11) AS kladr_sub_code,
               LEFT(s.code, 2) AS area_code,
               SUBSTRING(s.code, 3, 3) AS district_code,
               SUBSTRING(s.code, 6, 3) AS city_code,
               SUBSTRING(s.code, 9, 3) AS town_code,
               SUBSTRING(s.code, 12, 4) AS street_code,
               RIGHT(s.code, 2) AS actuality_status,
               5 AS kladr_level,
               s.name AS kladr_name,
               s.socr AS kladr_socr,
               s.index AS kladr_index,
               s.gninmb AS kladr_gninmd,
               s.uno AS kladr_uno,
               s.ocatd AS kladr_okatd
        FROM public.street s
        WHERE (RIGHT(s.code, 2) = '00')
        """;
}

public static class Doma1PgSql
{
    public static string ModelName = "doma1";
    public static string ConnectionName = "KladrConnection";
    public static string TargetTableName = "doma_1";
    public static string TargetSchemaName = "public";
    public static string SQL =  """
        SELECT d.code AS kladr_code,
               LEFT(d.code, 11) AS kladr_sub_code,
               LEFT(d.code, 2) AS area_codee,
               SUBSTRING(d.code,  3, 3) AS district_code,
               SUBSTRING(d.code,  6, 3) AS citry_code,
               SUBSTRING(d.code,  9, 3) AS town_code,
               SUBSTRING(d.code, 12, 4) AS street_code,
               SUBSTRING(d.code, 16, 4) AS bld_code,
               6 AS kladr_level, 
               d.name AS kladr_name,
               d.socr AS kladr_socr,
               d.index AS kladr_index,
               d.gninmb AS kladr_gninmb,
               d.uno AS kladr_uno,
               d.ocatd AS kladr_ocatd
        FROM public.doma d
        """;
}
