namespace Shared;

public enum GeoType
{
    kladr,
    gar
}

public enum TargetDb
{
    mssql,
    pgsql
}

public enum KladrTargetTable
{
    SocrBase,
    AltNames,
    Kladr,
    Streets,
    Doma,
    NameMap
}


