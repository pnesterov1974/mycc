namespace Shared.readSql.pgsql;

public static class SocrBasePgSql
{
    public static string SQL = """
            SELECT level, scname, socrname, kod_t_st
            FROM kladr.socrbase
        """;
}

public static class AltNamesPgSql
{
    public static string SQL = """
            SELECT oldcode, newcode, level
            FROM kladr.altnames
        """;
}

public static class KladrPgSql
{
    public static string SQL = """
            SELECT code,
                   name,
                   socr,
                   index,
                   gninmb,
                   uno,
                   ocatd,
                   status
            FROM kladr.kladr
        """;
}

public static class StreetPgSql
{
    public static string SQL = """
            SELECT code,
                   name,
                   socr,
                   index,
                   gninmb,
                   uno,
                   ocatd
            FROM kladr.street
            LIMIT 100
        """;
}

public static class DomaPgSql
{
    public static string SQL = """
            SELECT code,
                   name,
                   korp,
                   socr,
                   index,
                   gninmb,
                   uno,
                   ocatd
            FROM kladr.doma
            LIMIT 100
        """;
}