using System.Text;

namespace Shared;

public class ImportObjectsInfo : IObjectInfo
{
    public string TargetTableName { get; set; }
    public string TargetSchemaName { get; set; }
    public int BufferRecs { get; set; }
    public List<GarFileInfo> SourceFilePaths { get; set; }
    public string ConnectionString { get; set; }

    public string TargetTableFullName
    {
        get => string.Join('.', this.TargetSchemaName, this.TargetTableName);
    }

    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        sb.Append($"DestinationSchemaName:\t{this.TargetSchemaName}\n");
        sb.Append($"DestinationTableName:\t{this.TargetTableName}\n");
        sb.Append($"BufferRecs:\t{this.BufferRecs}\n");
        sb.Append("Files:\n");
        int i = 0;
        foreach (var filePath in this.SourceFilePaths)
        {
            i += 1;
            sb.Append($"{i}:\t{filePath.FileFullPath}\n");
        }
        sb.Append($"ConnectionString:\t{this.ConnectionString}\n");
        return sb.ToString();
    }
}