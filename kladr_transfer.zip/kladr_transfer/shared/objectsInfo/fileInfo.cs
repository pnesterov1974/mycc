using System.Text;

namespace Shared;
public class GarFileInfo //: IComparable  // TODO Gar Files vs NonGarFiles (Если нужно достать и сохранить инфу из имени файла)
{
    public string FileFullPath { get; set; } = string.Empty;
    public string FileName
    {
        get => Path.GetFileName(this.FileFullPath);
    }
    //public DateOnly DateStamp { get; set; }
    //public string Guid { get; set; }

    public GarFileInfo(string fullFilePath)
    {
        //Log.Information("Обработка");
        this.FileFullPath = fullFilePath;
        //Log.Information("Обработка файла {file}", this.FullFilePath);
        //Log.Information("Только имя {file}", Path.GetFileNameWithoutExtension(this.FullFilePath));
        //string[] sd = Path.GetFileNameWithoutExtension(this.FileFullPath).Split('_');

        //foreach (string s in sd)
        //    Log.Information(s);

        //Console.WriteLine(sd.Length);
        //if (sd.Length == 5)
        //{
        //this.DateStamp = sd[3];
        //    this.DateStamp = DateOnly.ParseExact(sd[3], "yyyyMMdd");
        //    this.Guid = sd[4];
        //}
        //else
        //{
        // Log Bad File Name
        //}
    }
/*
    public int CompareTo(object? obj)
    {
        GarFileInfo comparedTo = obj as GarFileInfo;
        if ((this.FileFullPath != null) && (comparedTo.FileFullPath != null))
        {   // String comparison...
            if (this.FileFullPath > comparedTo.FileFullPath)
            {
                return 1;
            }
            else if (this.FileFullPath < comparedTo.FileFullPath)
            {
                return -1;
            }
            else if (this.FileFullPath = comparedTo.FileFullPath)
            {
                return 0;
            }
        }
        else
        {
            return -1;
        }
    }
*/
    public string ToSting()
    {
        StringBuilder sb = new StringBuilder();
        sb.Append($"FullFilePath:\t {this.FileFullPath}\n");
        //sb.Append($"DateStamp:\t {this.DateStamp}\n");
        //sb.Append($"Guid:\t {this.Guid}\n");
        return sb.ToString();
    }
}