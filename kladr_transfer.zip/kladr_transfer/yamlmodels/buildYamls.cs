//https://github.com/aaubry/YamlDotNet
//https://github.com/dezhidki/Tommy
using YamlOps;
using YamlModels;

string TransformationModelsFilePath = Path.Join(Directory.GetCurrentDirectory(), "_models");
string AssetsFilePath = Path.Join(Directory.GetCurrentDirectory(), "_assets");

// TODO: Build _directories

TransformationModel transformationModel = new TransformationModel
{
    ModelName = "First Model Name",
    ConnectionName = "kladr_connection",
    TargetName = "Destination Object Name",
    SQL = """
        SELECT TOP (1000) [DateToLoad]
                         ,[NeedLoadToTrd]
                         ,[NeedLoadToAnalytics]
                         ,[NeedLoadToCsd]
                         ,[IsLoadedToTrd]
                         ,[IsLoadedToAnalytics]
                         ,[IsLoadedToCsd]
                         ,[DeferredDateTrd]
                         ,[DeferredDateAnalytics]
                        ,[DeferredDateCsd]
        FROM [_trdHR_buf].[dbo].[PifagorAMPositionsLoadManager]
        ORDER BY DateToLoad DESC;
    """
};

var firstModelFilePath = Path.Combine(TransformationModelsFilePath, "first.yaml");
YamlOperations.SaveTransformationModel(transformationModel, firstModelFilePath);

ConnectionAsset connectionsAsset = new ConnectionAsset
{
    ConnectionName = "kladr_connection",
    ConnectionString = "Data Source=;Initial Catalog=kladr;Integrated Security=True;Pooling=True;Trust Server Certificate=True;Connection Timeout=500"
};

var connectionAssetFilePath = Path.Combine(AssetsFilePath, "connections.yaml");
YamlOperations.SaveConnectionAsset(connectionsAsset, connectionAssetFilePath);
