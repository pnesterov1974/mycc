namespace YamlModels;
class TransformationModel
{
    public string ModelName = string.Empty;
    public string ConnectionName = string.Empty;
    public string TargetName = string.Empty;
    public string SQL = string.Empty;
}

class ConnectionAsset
{
    public string ConnectionName = string.Empty;
    public string ConnectionString = string.Empty;
}
