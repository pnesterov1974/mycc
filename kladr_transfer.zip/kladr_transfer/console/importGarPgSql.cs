using GarImport;
using Shared;

namespace ImportGar;

public class ImportGarToPgSql: GarSource
{
    public ImportGarToPgSql(string sourceDirPath): base(sourceDirPath) { ; }

    public void DoImport(string connectionString)
    {
        ObjectInfo NormativeDocsKinds = new ObjectInfo
        {
            DestinationTableName = "normative_docs_kinds",
            DestinationSchemaName = "gar",
            SourceFileName = this.Masters["AS_NORMATIVE_DOCS_KINDS"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportNormativeDocsKinds ndk = new ImportNormativeDocsKinds(NormativeDocsKinds);
        ndk.DoImport();

        ObjectInfo AddHouseTypes = new ObjectInfo
        {
            DestinationTableName = "add_house_types",
            DestinationSchemaName = "gar",
            SourceFileName = this.Masters["AS_ADDHOUSE_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportAddHouseTypes aht = new ImportAddHouseTypes(AddHouseTypes);
        aht.DoImport();

        ObjectInfo AddrObjTypes = new ObjectInfo
        {
            DestinationTableName = "addr_obj_types",
            DestinationSchemaName = "gar",
            SourceFileName = this.Masters["AS_ADDR_OBJ_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportAddrObjTypes aot = new ImportAddrObjTypes(AddrObjTypes);
        aot.DoImport();

        ObjectInfo AppartmentTypes = new ObjectInfo
        {
            DestinationTableName = "appartment_types",
            DestinationSchemaName = "gar",
            SourceFileName = this.Masters["AS_APARTMENT_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportAppartmentTypes apt = new ImportAppartmentTypes(AppartmentTypes);
        apt.DoImport();

        ObjectInfo HouseTypes = new ObjectInfo
        {
            DestinationTableName = "house_types",
            DestinationSchemaName = "gar",
            SourceFileName = this.Masters["AS_HOUSE_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportHouseTypes ht = new ImportHouseTypes(HouseTypes);
        ht.DoImport();

        ObjectInfo NormativeDocsTypes = new ObjectInfo
        {
            DestinationTableName = "normative_docs_types",
            DestinationSchemaName = "gar",
            SourceFileName = this.Masters["AS_NORMATIVE_DOCS_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportNormativeDocTypes ndt = new ImportNormativeDocTypes(NormativeDocsTypes);
        ndt.DoImport();

        ObjectInfo ObjectLevels = new ObjectInfo
        {
            DestinationTableName = "object_levels",
            DestinationSchemaName = "gar",
            SourceFileName = this.Masters["AS_OBJECT_LEVELS"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportObjectLevels ol = new ImportObjectLevels(ObjectLevels);
        ol.DoImport();

        ObjectInfo OparationTypes = new ObjectInfo
        {
            DestinationTableName = "operation_types",
            DestinationSchemaName = "gar",
            SourceFileName = this.Masters["AS_OPERATION_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportOperationTypes opt = new ImportOperationTypes(OparationTypes);
        opt.DoImport();

        ObjectInfo ParamTypes = new ObjectInfo
        {
            DestinationTableName = "param_types",
            DestinationSchemaName = "gar",
            SourceFileName = this.Masters["AS_PARAM_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportParamTypes prt = new ImportParamTypes(ParamTypes);
        prt.DoImport();

        ObjectInfo RoomTypes = new ObjectInfo
        {
            DestinationTableName = "room_types",
            DestinationSchemaName = "gar",
            SourceFileName = this.Masters["AS_ROOM_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportRoomTypes rmt = new ImportRoomTypes(RoomTypes);
        rmt.DoImport();
    }
}