using Import.gar.pgsql;
using Shared;

namespace ImportGar.pgsql;

public class ImportGarToPgSql: GarSource
{
    public ImportGarToPgSql(string sourceDirPath): base(sourceDirPath) { ; }

    public void DoImport(string connectionString)
    {
        ImportObjectInfo NormativeDocsKinds = new ImportObjectInfo
        {
            TargetTableName = "normative_docs_kinds",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_NORMATIVE_DOCS_KINDS"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportNormativeDocsKinds ndk = new ImportNormativeDocsKinds(NormativeDocsKinds);
        ndk.DoImport();

        ImportObjectInfo AddHouseTypes = new ImportObjectInfo
        {
            TargetTableName = "add_house_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_ADDHOUSE_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportAddHouseTypes aht = new ImportAddHouseTypes(AddHouseTypes);
        aht.DoImport();

        ImportObjectInfo AddrObjTypes = new ImportObjectInfo
        {
            TargetTableName = "addr_obj_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_ADDR_OBJ_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportAddrObjTypes aot = new ImportAddrObjTypes(AddrObjTypes);
        aot.DoImport();

        ImportObjectInfo AppartmentTypes = new ImportObjectInfo
        {
            TargetTableName = "appartment_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_APARTMENT_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportAppartmentTypes apt = new ImportAppartmentTypes(AppartmentTypes);
        apt.DoImport();

        ImportObjectInfo HouseTypes = new ImportObjectInfo
        {
            TargetTableName = "house_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_HOUSE_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportHouseTypes ht = new ImportHouseTypes(HouseTypes);
        ht.DoImport();

        ImportObjectInfo NormativeDocsTypes = new ImportObjectInfo
        {
            TargetTableName = "normative_docs_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_NORMATIVE_DOCS_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportNormativeDocTypes ndt = new ImportNormativeDocTypes(NormativeDocsTypes);
        ndt.DoImport();

        ImportObjectInfo ObjectLevels = new ImportObjectInfo
        {
            TargetTableName = "object_levels",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_OBJECT_LEVELS"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportObjectLevels ol = new ImportObjectLevels(ObjectLevels);
        ol.DoImport();

        ImportObjectInfo OparationTypes = new ImportObjectInfo
        {
            TargetTableName = "operation_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_OPERATION_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportOperationTypes opt = new ImportOperationTypes(OparationTypes);
        opt.DoImport();

        ImportObjectInfo ParamTypes = new ImportObjectInfo
        {
            TargetTableName = "param_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_PARAM_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportParamTypes prt = new ImportParamTypes(ParamTypes);
        prt.DoImport();

        ImportObjectInfo RoomTypes = new ImportObjectInfo
        {
            TargetTableName = "room_types",
            TargetSchemaName = "gar",
            SourceFileName = this.Masters["AS_ROOM_TYPES"].FileName,
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportRoomTypes rmt = new ImportRoomTypes(RoomTypes);
        rmt.DoImport();
    }

    public void DoImportFacts(string connectionString)
    {
        // ImportObjectsInfo AddrObj = new ImportObjectsInfo
        // {
        //     TargetTableName = "addr_obj",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_ADDR_OBJ"],
        //     ConnectionString = connectionString
        // };
        // ImportAddrObj aobj = new ImportAddrObj(AddrObj);
        // aobj.DoImportData();

        // ImportObjectsInfo AddrObjDivision = new ImportObjectsInfo
        // {
        //     TargetTableName = "addr_obj_division",
        //     TargetSchemaName = "gar",
        //     SourceFilePaths = this.Facts["AS_ADDR_OBJ_DIVISION"],
        //     ConnectionString = connectionString
        // };
        // ImportAddrObjDivision aobjd = new ImportAddrObjDivision(AddrObjDivision);
        // aobjd.DoImportData();

        ImportObjectsInfo AddrObjParams = new ImportObjectsInfo
        {
            TargetTableName = "addr_obj_params",
            TargetSchemaName = "gar",
            SourceFilePaths = this.Facts["AS_ADDR_OBJ_PARAMS"],
            ConnectionString = connectionString
        };
        ImportAddrObjParams aobjp = new ImportAddrObjParams(AddrObjParams);
        aobjp.DoImportData();
    }
}