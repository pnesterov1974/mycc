using GarImport;
using Shared;

namespace ImportGar;

public class ImportGarToPgSql: GarSource
{
    public ImportGarToPgSql(string sourceDirPath): base(sourceDirPath) { ; }

    public void DoImport(string connectionString)
    {
        ObjectInfo NormativeDocsKinds = new ObjectInfo
        {
            DestinationTableName = "normative_docs_kinds",
            DestinationSchemaName = "gar",
            SourceFileName = this.Masters["AS_NORMATIVE_DOCS_KINDS"].FullFilePath,
            //SourceFileName = "AS_NORMATIVE_DOCS_KINDS_20240815_a1dc61a2-9b9a-4de6-bbac-350a7a04cddf.XML",
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportNormativeDocsKinds ndk = new ImportNormativeDocsKinds(NormativeDocsKinds);
        ndk.DoImport();
/*
        ObjectInfo AddHouseTypes = new ObjectInfo
        {
            DestinationTableName = "add_house_types",
            DestinationSchemaName = "gar",
            SourceFileName = "AS_ADDHOUSE_TYPES_20240815_656d52c9-09af-4b12-8d3c-5732f358506b.XML",
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportAddHouseTypes aht = new ImportAddHouseTypes(AddHouseTypes);
        aht.DoImport();

        ObjectInfo AddrObjTypes = new ObjectInfo
        {
            DestinationTableName = "addr_obj_types",
            DestinationSchemaName = "gar",
            SourceFileName = "AS_ADDR_OBJ_TYPES_20240815_170beb1d-c177-402e-ab2b-175bc16962af.XML",
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportAddHouseTypes aot = new ImportAddHouseTypes(AddrObjTypes);
        aot.DoImport();

        ObjectInfo AppartmentTypes = new ObjectInfo
        {
            DestinationTableName = "appartment_types",
            DestinationSchemaName = "gar",
            SourceFileName = "AS_APARTMENT_TYPES_20240815_6d8bafd4-c0b1-4185-a786-300406fc8bc1.XML",
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportAppartmentTypes apt = new ImportAppartmentTypes(AppartmentTypes);
        apt.DoImport();

        ObjectInfo HouseTypes = new ObjectInfo
        {
            DestinationTableName = "house_types",
            DestinationSchemaName = "gar",
            SourceFileName = "AS_HOUSE_TYPES_20240815_5d97947a-230c-4bc8-ad24-6077a0be2d21.XML",
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportHouseTypes ht = new ImportHouseTypes(HouseTypes);
        ht.DoImport();

        ObjectInfo NormativeDocsTypes = new ObjectInfo
        {
            DestinationTableName = "normative_docs_types",
            DestinationSchemaName = "gar",
            SourceFileName = "AS_NORMATIVE_DOCS_TYPES_20240815_a1706595-44dc-4344-92d4-bea8f42dada7.XML",
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportNormativeDocTypes ndt = new ImportNormativeDocTypes(NormativeDocsTypes);
        ndt.DoImport();

        ObjectInfo ObjectLevels = new ObjectInfo
        {
            DestinationTableName = "object_levels",
            DestinationSchemaName = "gar",
            SourceFileName = "AS_OBJECT_LEVELS_20240815_96bdaec8-a1db-4644-9fad-8c7cc709efbe.XML",
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportObjectLevels ol = new ImportObjectLevels(ObjectLevels);
        ol.DoImport();

        ObjectInfo OparationTypes = new ObjectInfo
        {
            DestinationTableName = "operation_types",
            DestinationSchemaName = "gar",
            SourceFileName = "AS_OPERATION_TYPES_20240815_421f2147-ffda-45c1-af83-bf6d2c5bc002.XML",
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportOperationTypes opt = new ImportOperationTypes(OparationTypes);
        opt.DoImport();

        ObjectInfo ParamTypes = new ObjectInfo
        {
            DestinationTableName = "param_types",
            DestinationSchemaName = "gar",
            SourceFileName = "AS_PARAM_TYPES_20240815_ce1f3b3b-d513-47df-b3f9-fa2eec8e583b.XML",
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportParamTypes prt = new ImportParamTypes(ParamTypes);
        prt.DoImport();

        ObjectInfo RoomTypes = new ObjectInfo
        {
            DestinationTableName = "room_types",
            DestinationSchemaName = "gar",
            SourceFileName = "AS_ROOM_TYPES_20240815_8d41ca3d-f16b-4975-ba66-c3cb41c2ba51.XML",
            SourceDirPath = this.SourceDirPath,
            ConnectionString = connectionString
        };
        ImportRoomTypes rmt = new ImportRoomTypes(RoomTypes);
        rmt.DoImport();
        */
    }
}