using System.Threading.Tasks;

namespace Import.kladr.pgsql;

public static class DoImportPgSql
{
    public static string SourceDirPath = string.Empty;
    public static string ConnectionString = string.Empty;
    public static List<string> NowInvoking = new List<string>();

    public static void DoImportParallel()
    {
        Parallel.Invoke(
            () =>
                {
                    if (!NowInvoking.Contains("socrbase"))
                    {
                        NowInvoking.Add("socrbase");
                        PgSocrBaseImport sb = new PgSocrBaseImport(SourceDirPath, ConnectionString);
                        sb.DoImport();
                    }
                },
            () =>
                {
                    if (!NowInvoking.Contains("altnames"))
                    {
                        NowInvoking.Add("altnames");
                        PgAltNamesImport an = new PgAltNamesImport(SourceDirPath, ConnectionString);
                        an.DoImport();
                    }
                },
            () =>
                {
                    if (!NowInvoking.Contains("kladr"))
                    {
                        NowInvoking.Add("kladr");
                        PgKladrImport kl = new PgKladrImport(SourceDirPath, ConnectionString);
                        kl.DoImport();
                    }
                },
            () =>
                {
                    if (!NowInvoking.Contains("street"))
                    {
                        NowInvoking.Add("street");
                        PgStreetImport st = new PgStreetImport(SourceDirPath, ConnectionString);
                        st.DoImport();
                    }
                },
            () =>
                {
                    if (!NowInvoking.Contains("doma"))
                    {
                        NowInvoking.Add("doma");
                        PgDomaImport dm = new PgDomaImport(SourceDirPath, ConnectionString);
                        dm.DoImport();
                    }
                }
        );
        NowInvoking.Clear();
    }

    public static void DoImportSynch()
    {
        PgSocrBaseImport sb = new PgSocrBaseImport(SourceDirPath, ConnectionString);
        sb.DoImport();

        PgAltNamesImport an = new PgAltNamesImport(SourceDirPath, ConnectionString);
        an.DoImport();

        PgKladrImport kl = new PgKladrImport(SourceDirPath, ConnectionString);
        kl.DoImport();

        PgStreetImport st = new PgStreetImport(SourceDirPath, ConnectionString);
        st.DoImport();

        PgDomaImport dm = new PgDomaImport(SourceDirPath, ConnectionString);
        dm.DoImport();
    }
}