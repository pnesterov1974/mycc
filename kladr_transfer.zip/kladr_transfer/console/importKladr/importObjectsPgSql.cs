using Data.Import.kladr.pgsql;
using Shared;

namespace Import.kladr.pgsql;

// Вызываются из Worker-а последовательно или параллельно
public class PgSocrBaseImport : IKladrImport
{
    public ImportObjectInfo Ioi { get; set; } = new ImportObjectInfo
    {
        TargetTableName = "socrbase",
        TargetSchemaName = "kladr",
        SourceFileName = "SOCRBASE.DBF",
        SourceDirPath = string.Empty,
        ConnectionString = string.Empty
    };

    public PgSocrBaseImport(string sourceDirPath, string connectionString)
    {
        this.Ioi.SourceDirPath = sourceDirPath;
        this.Ioi.ConnectionString = connectionString;
    }

    public void DoImport()
    {
        PgImportSocrBase sb = new PgImportSocrBase(this.Ioi);
        sb.ReadDbfInfo(this.Ioi.SourceFilePath);
        sb.DoImport();
    }
}

public class PgAltNamesImport : IKladrImport
{
    public ImportObjectInfo Ioi { get; set; } = new ImportObjectInfo
    {
        TargetTableName = "altnames",
        TargetSchemaName = "kladr",
        SourceFileName = "ALTNAMES.DBF",
        SourceDirPath = string.Empty,
        ConnectionString = string.Empty
    };

    public PgAltNamesImport(string sourceDirPath, string connectionString)
    {
        this.Ioi.SourceDirPath = sourceDirPath;
        this.Ioi.ConnectionString = connectionString;
    }

    public void DoImport()
    {
        PgImportAltNames an = new PgImportAltNames(this.Ioi);
        an.ReadDbfInfo(this.Ioi.SourceFilePath);
        an.DoImport();
    }
}

public class PgKladrImport : IKladrImport
{
    public ImportObjectInfo Ioi { get; set; } = new ImportObjectInfo
    {
        TargetTableName = "kladr",
        TargetSchemaName = "kladr",
        SourceFileName = "KLADR.DBF",
        SourceDirPath = string.Empty,
        ConnectionString = string.Empty
    };

    public PgKladrImport(string sourceDirPath, string connectionString)
    {
        this.Ioi.SourceDirPath = sourceDirPath;
        this.Ioi.ConnectionString = connectionString;
    }

    public void DoImport()
    {
        PgImportKladr an = new PgImportKladr(this.Ioi);
        an.ReadDbfInfo(this.Ioi.SourceFilePath);
        an.DoImport();
    }
}

public class PgStreetImport : IKladrImport
{
    public ImportObjectInfo Ioi { get; set; } = new ImportObjectInfo
    {
        TargetTableName = "street",
        TargetSchemaName = "kladr",
        SourceFileName = "STREET.DBF",
        SourceDirPath = string.Empty,
        ConnectionString = string.Empty
    };

    public PgStreetImport(string sourceDirPath, string connectionString)
    {
        this.Ioi.SourceDirPath = sourceDirPath;
        this.Ioi.ConnectionString = connectionString;
    }

    public void DoImport()
    {
        PgImportStreet an = new PgImportStreet(this.Ioi);
        an.ReadDbfInfo(this.Ioi.SourceFilePath);
        an.DoImport();
    }
}

public class PgDomaImport : IKladrImport
{
    public ImportObjectInfo Ioi { get; set; } = new ImportObjectInfo
    {
        TargetTableName = "doma",
        TargetSchemaName = "kladr",
        SourceFileName = "DOMA.DBF",
        SourceDirPath = string.Empty,
        ConnectionString = string.Empty
    };

    public PgDomaImport(string sourceDirPath, string connectionString)
    {
        this.Ioi.SourceDirPath = sourceDirPath;
        this.Ioi.ConnectionString = connectionString;
    }

    public void DoImport()
    {
        PgImportDoma an = new PgImportDoma(this.Ioi);
        an.ReadDbfInfo(this.Ioi.SourceFilePath);
        an.DoImport();
    }
}

