using CommandLine;
using Options;
using ImportKladr;
using ImportGar;
using Shared;

//--------------

// TODO:
// pg import kladr from dbf -> thruncate table sql {} + reccount from executenonquery
// query with parameters -> not fast parameters
// gar import - validate xml by schema
//      https://learn.microsoft.com/ru-ru/dotnet/standard/linq/validate-xsd
//      https://www.c-sharpcorner.com/article/how-to-validate-xml-using-xsd-in-c-sharp/
// using cli
// gar facts source file procesing...
// mvc make simple repository class (SocrBase)
// common objects to shared = folders

bool importKladr = false;
string targetDB = string.Empty;
List<string> objectList = new List<string>();
string[] allObjects = new string[]{ "SocrBase", "AltNames", "Kladr", "Street", "Doma", "NameMap" };
List<string> allObjects2 = new List<string>{ "SocrBase", "AltNames", "Kladr", "Street", "Doma", "NameMap" };

Parser.Default.ParseArguments<CliOptions>(args)
    .WithParsed<CliOptions>(o =>
        {
            importKladr = o.ImportKladr;

            if (o.DestinationMsSql) targetDB = "mssql";
            else if (o.DestinationPgSql) targetDB = "pgsql";
            else targetDB = string.Empty;
            
            objectList = o.Objects.ToList();
        }
    );

Console.WriteLine($"importKladr = {importKladr}");
Console.WriteLine($"targetDB = {targetDB}");

if (objectList.Count > 0) foreach (string o in objectList) Console.WriteLine(o);
else Console.WriteLine("All objects");

foreach(var s in allObjects2)
{
   Console.WriteLine(s); 
}


string destDirPath = Path.Join(Directory.GetCurrentDirectory(), "_dest");
if (!Path.Exists(destDirPath))
{
    Directory.CreateDirectory(destDirPath);
}

//string sourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "my_dev", "files", "kladr");
string kladrSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "my_dev", "files", "kladr");
//string kladrSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "dotNetProjects", "files", "kladr");
//string garSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "dotNetProjects", "files", "gar");
string garSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "my_dev", "files", "gar");

string MsSqlConnectionString = ConnectionString.GetConnectionString(DBSource.mssql);
string PgSqlConnectionString = ConnectionString.GetConnectionString(DBSource.pgsql);

MyLogger.InitLogger();

ImportKladr(DBSource.pgsql);
//ImportGar(DBSource.pgsql);

//ReadProc();

// void ReadProc()
// {
//     MsSqlSchema scs = new MsSqlSchema(MsSqlConnectionString, SocrBase.SQL)
//     {
//         Log = log
//     };
//     scs.Read();
//     //string jsfp1 = Path.Combine(destDirPath, "socrbase_schema.json");
//     //File.WriteAllText(jsfp1, scs.AsJson());
//     var r = scs.GetFieldList();

//     MsSqlData scd = new MsSqlData(MsSqlConnectionString, SocrBase.SQL)
//     {
//         Log = log
//     };
//     scd.Read();
//     //string jsfp2 = Path.Combine(destDirPath, "socrbase.json");
//     //File.WriteAllText(jsfp2, scd.AsJson());

//     // InsertIntoMsSql isb = new InsertIntoMsSql(MsSqlconnectionString, SocrBase.SQL, "dbo", "[t_socrbase]")
//     // {
//     //     Log = log
//     // };
//     // isb.InsertInto();
// }

void ImportKladr(DBSource dbs = DBSource.mssql)
{
    DateTime StartDt = DateTime.Now;
    MyLogger.Log.Debug("StartDt: {dt}", StartDt);

    switch (dbs)
    {
        case DBSource.mssql:
            MyLogger.Log.Information("Импорт DBF => Ms SQL");
            ImportKladrToMsSql.DoImport(MsSqlConnectionString, kladrSourceDirPath);
            break;
        case DBSource.pgsql:
            MyLogger.Log.Information("Импорт DBF => PG DB");
            ImportKladrToPgSql.DoImport(PgSqlConnectionString, kladrSourceDirPath);
            break;
    }

    DateTime FinishDt = DateTime.Now;
    TimeSpan Duration = FinishDt - StartDt;
    MyLogger.Log.Information("Обработка завершена в {finishDt}, продолжительность {Duration}", FinishDt, Duration);
}

void ImportGar(DBSource dbs = DBSource.mssql)
{
    DateTime StartDt = DateTime.Now;
    MyLogger.Log.Debug("StartDt: {dt}", StartDt);

    switch (dbs)
    {
        case DBSource.mssql:
            MyLogger.Log.Information("Импорт XML => MS SQL");
            ImportGarToMsSql.DoImport(MsSqlConnectionString, garSourceDirPath);
            break;
        case DBSource.pgsql:
            MyLogger.Log.Information("Импорт XML => PG DB");
            ImportGarToPgSql imp = new ImportGarToPgSql(garSourceDirPath);
            imp.DoImport(PgSqlConnectionString);
            break;
    }

    DateTime FinishDt = DateTime.Now;
    TimeSpan Duration = FinishDt - StartDt;
    MyLogger.Log.Information("Обработка завершена в {finishDt}, продолжительность {Duration}", FinishDt, Duration);
}