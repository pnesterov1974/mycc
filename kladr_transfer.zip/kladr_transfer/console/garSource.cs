using Shared;
using static Shared.MyLogger;

namespace ImportGar;
public class GarSource
{
    public Dictionary<string, GarFileInfo?> Masters = new Dictionary<string, GarFileInfo?>()
    {
        {"AS_ADDHOUSE_TYPES", null},
        {"AS_ADDR_OBJ_TYPES", null},
        {"AS_APARTMENT_TYPES", null},
        {"AS_HOUSE_TYPES", null},
        {"AS_NORMATIVE_DOCS_KINDS", null},
        {"AS_NORMATIVE_DOCS_TYPES", null},
        {"AS_OBJECT_LEVELS", null},
        {"AS_OPERATION_TYPES", null},
        {"AS_PARAM_TYPES", null},
        {"AS_ROOM_TYPES", null}
    };

    public Dictionary<string, List<GarFileInfo>?> Facts = new Dictionary<string, List<GarFileInfo>?>()
    {
        {"AS_ADDR_OBJ", null},
        {"AS_ADDR_OBJ_DIVISION", null},
        {"AS_ADDR_OBJ_PARAMS", null},
        {"AS_ADM_HIERARCHY", null},
        {"AS_APARTMENTS", null},
        {"AS_APARTMENTS_PARAMS", null},
        {"AS_CARPLACES", null},
        {"AS_CARPLACES_PARAMS", null},
        {"AS_CHANGE_HISTORY", null},
        {"AS_HOUSES", null},
        {"AS_HOUSES_PARAMS", null},
        {"AS_MUN_HIERARCHY", null},
        {"AS_NORMATIVE_DOCS", null},
        {"AS_REESTR_OBJECTS", null},
        {"AS_ROOMS", null},
        {"AS_ROOMS_PARAMS", null},
        {"AS_STEADS", null},
        {"AS_STEADS_PARAMS", null}
    };

    protected string SourceDirPath = string.Empty;

    public GarSource(string sourceDirPath)
    {
        Log.Information("Поиск файлов-источников в папке {sourceDirPath}", sourceDirPath);
        if (Path.Exists(sourceDirPath))
        {
            Log.Information("Папка существует");
            this.SourceDirPath = sourceDirPath;
            this.locateMasters();
            this.locateFacts();
        }
        else
        {
            Log.Information($"Папка не существует");
        }
    }

    private void locateMasters()
    {
        Log.Information("Поиск справочников...", this.SourceDirPath);
        foreach (var item in this.Masters)
        {
            string fileMask = string.Concat(item.Key, "*.XML");
            string[] fileEntries = Directory.GetFiles(this.SourceDirPath, fileMask, SearchOption.AllDirectories);
            Log.Information("Маска файла: {filemask} найдено {cnt} файлов", fileMask, fileEntries.Length);
            if (fileEntries.Length > 0)
            {

                GarFileInfo gf = new GarFileInfo(fileEntries[0]);
                this.Masters[item.Key] = gf;
            }
        }
    }

    private void locateFacts()
    {
        Log.Information("Поиск фактов...", this.SourceDirPath);
        foreach (var item in this.Facts)
        {
            string fileMask = string.Concat(item.Key, "_20*.XML");
            string[] fileEntries = Directory.GetFiles(this.SourceDirPath, fileMask, SearchOption.AllDirectories);
            Log.Information("Маска файла: {filemask} найдено {cnt} файлов", fileMask, fileEntries.Length);
            if (fileEntries.Length > 0)
            {
                List<GarFileInfo> gfl = new List<GarFileInfo>();
                foreach (string file in fileEntries)
                {
                    GarFileInfo gf = new GarFileInfo(file);
                    gfl.Add(gf);
                }
                gfl.Sort();
                this.Facts[item.Key] = gfl;
            }
        }
    }
}