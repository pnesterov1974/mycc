using KladrImport;
using KladrData;
using Shared;

namespace ImportKladr;

static class ImportKladrToPgSql
{
    public static void DoImport(string connectionString, string sourceDirPath)
    {
        if (DBUtils.TryPgDbConnection(connectionString))
        {
            ObjectInfo SocrBaseObjectInfo = new ObjectInfo
            {
                DestinationTableName = "socrbase",
                DestinationSchemaName = "public",
                SourceFileName = "SOCRBASE.DBF",
                SourceDirPath = sourceDirPath,
                ConnectionString = connectionString
            };
            PgImportSocrBase sb = new PgImportSocrBase(SocrBaseObjectInfo);
            DBUtils.ReadDbfInfo(SocrBaseObjectInfo);
            sb.DoImport();

            ObjectInfo AltNamesObjectInfo = new ObjectInfo
            {
                DestinationTableName = "altnames",
                DestinationSchemaName = "public",
                SourceFileName = "ALTNAMES.DBF",
                SourceDirPath = sourceDirPath,
                ConnectionString = connectionString
            };
            PgImportAltNames an = new PgImportAltNames(AltNamesObjectInfo);
            DBUtils.ReadDbfInfo(AltNamesObjectInfo);
            an.DoImport();

            ObjectInfo KladrObjectInfo = new ObjectInfo
            {
                DestinationTableName = "kladr",
                DestinationSchemaName = "public",
                SourceFileName = "KLADR.DBF",
                SourceDirPath = sourceDirPath,
                ConnectionString = connectionString
            };
            PgImportKladr kl = new PgImportKladr(KladrObjectInfo);
            DBUtils.ReadDbfInfo(KladrObjectInfo);
            kl.DoImport();

            ObjectInfo StreetObjectInfo = new ObjectInfo
            {
                DestinationTableName = "street",
                DestinationSchemaName = "public",
                SourceFileName = "STREET.DBF",
                BufferRecs = 200000,
                SourceDirPath = sourceDirPath,
                ConnectionString = connectionString
            };
            PgImportStreet st = new PgImportStreet(StreetObjectInfo);
            DBUtils.ReadDbfInfo(StreetObjectInfo);
            st.DoImport();

            ObjectInfo DomaObjectInfo = new ObjectInfo
            {
                DestinationTableName = "doma",
                DestinationSchemaName = "public",
                SourceFileName = "DOMA.DBF",
                BufferRecs = 1000000,
                SourceDirPath = sourceDirPath,
                ConnectionString = connectionString
            };
            PgImportDoma dm = new PgImportDoma(DomaObjectInfo);
            DBUtils.ReadDbfInfo(DomaObjectInfo);
            dm.DoImport();
        }
    }
}