using Shared;

namespace ImportGar;

public class GarFileInfo
{
    public string FullFilePath { get; set; }
    public DateOnly DateStamp { get; set; }
    public string Guid { get; set; }

    public GarFileInfo(string fullFilePath)
    {
        MyLogger.Log.Information("Обработка");
        this.FullFilePath = fullFilePath;
        MyLogger.Log.Information(" ========================");
        MyLogger.Log.Information("Обработка файла {file}", this.FullFilePath);
        MyLogger.Log.Information("Только имя {file}", Path.GetFileNameWithoutExtension(this.FullFilePath));
        string[] sd = Path.GetFileNameWithoutExtension(this.FullFilePath).Split('_');

        foreach (string s in sd)
        {
            MyLogger.Log.Information(s);
        }

        //Console.WriteLine(sd.Length);
        if (sd.Length == 5)
        {
            //this.DateStamp = sd[3];
            this.DateStamp = DateOnly.ParseExact(sd[3], "yyyyMMdd");
            this.Guid = sd[4];
        }
        else
        {
            // Log Bad File Name
        }
    }

    // public string ToSting()
    // {
    //     StringBuilder sb = new StringBuilder();
    //     sb.Append($"FullFilePath:\t {this.FullFilePath}\n");
    //     sb.Append($"DateStamp:\t {this.DateStamp}\n");
    //     sb.Append($"Guid:\t {this.Guid}\n");
    //     return sb.ToString();
    // }
}