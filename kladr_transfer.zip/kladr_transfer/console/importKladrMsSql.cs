using KladrImport;
using KladrData;
using Shared;

namespace ImportKladr;

static class ImportKladrToMsSql
{
    public static void DoImport(string connectionString, string sourceDirPath)
    {
        if (DBUtils.TryMsSqlDbConnection(connectionString))
        {
            ObjectInfo SocrBaseObjectInfo = new ObjectInfo
            {
                DestinationTableName = "[SOCRBASE]",
                DestinationSchemaName = "dbo",
                SourceFileName = "SOCRBASE.DBF",
                SourceDirPath = sourceDirPath,
                ConnectionString = connectionString
            };
            MsSqlImport sb = new MsSqlImport(SocrBaseObjectInfo);
            DBUtils.ReadDbfInfo(SocrBaseObjectInfo);
            sb.BulkImport();

            ObjectInfo NamesMapObjectInfo = new ObjectInfo
            {
                DestinationTableName = "[NameMap]",
                DestinationSchemaName = "dbo",
                SourceFileName = "NAMEMAP.DBF",
                SourceDirPath = sourceDirPath,
                ConnectionString = connectionString
            };
            MsSqlImport nm = new MsSqlImport(NamesMapObjectInfo);
            DBUtils.ReadDbfInfo(NamesMapObjectInfo);
            nm.BulkImport();

            ObjectInfo AltNamesObjectInfo = new ObjectInfo
            {
                DestinationTableName = "[ALTNAMES]",
                DestinationSchemaName = "dbo",
                SourceFileName = "ALTNAMES.DBF",
                SourceDirPath = sourceDirPath,
                ConnectionString = connectionString
            };
            MsSqlImport an = new MsSqlImport(AltNamesObjectInfo);
            DBUtils.ReadDbfInfo(AltNamesObjectInfo);
            an.BulkImport();

            ObjectInfo KladrObjectInfo = new ObjectInfo
            {
                DestinationTableName = "[KLADR]",
                DestinationSchemaName = "dbo",
                SourceFileName = "KLADR.DBF",
                SourceDirPath = sourceDirPath,
                ConnectionString = connectionString
            };
            MsSqlImport kl = new MsSqlImport(KladrObjectInfo);
            DBUtils.ReadDbfInfo(KladrObjectInfo);
            kl.BulkImport();

            ObjectInfo StreetObjectInfo = new ObjectInfo
            {
                DestinationTableName = "[STREET]",
                DestinationSchemaName = "dbo",
                SourceFileName = "STREET.DBF",
                SourceDirPath = sourceDirPath,
                ConnectionString = connectionString
            };
            MsSqlImport st = new MsSqlImport(StreetObjectInfo);
            DBUtils.ReadDbfInfo(StreetObjectInfo);
            st.BulkImport();

            ObjectInfo DomaObjectInfo = new ObjectInfo
            {
                DestinationTableName = "[DOMA]",
                DestinationSchemaName = "dbo",
                SourceFileName = "DOMA.DBF",
                SourceDirPath = sourceDirPath,
                ConnectionString = connectionString
            };
            MsSqlImport dm = new MsSqlImport(DomaObjectInfo);
            DBUtils.ReadDbfInfo(DomaObjectInfo);
            dm.BulkImport();
        }
    }
}