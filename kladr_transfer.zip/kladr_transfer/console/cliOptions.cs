using CommandLine;

namespace Options;
public class CliOptions
{
    [Option('k', "ImportKladr", Required = false, HelpText = "Do import KLADR from dbf files")]
    public bool ImportKladr { get; set; }

    [Option('m', "mssql", Required = false, HelpText = "Destination MSSQL")]
    public bool DestinationMsSql { get; set; }

    [Option('p', "pgsql", Required = false, HelpText = "Destination PgSql")]
    public bool DestinationPgSql { get; set; }

    // Список SocrBase, AltNames, Kladr, Street, Doma, NameMap
    [Option('o', "objects", HelpText = "List of objects")]
    public IEnumerable<string> Objects { get; set; } // Enum
}