using GarImport;
using Shared;

namespace ImportGar;

static class ImportGarToMsSql
{
    public static void DoImport(string connectionString, string sourceDirPath)
    {
        ObjectInfo NormativeDocsKinds = new ObjectInfo
        {
            DestinationTableName = "[NormativeDocsKinds]",
            DestinationSchemaName = "gar",
            SourceFileName = "AS_NORMATIVE_DOCS_KINDS_20240815_a1dc61a2-9b9a-4de6-bbac-350a7a04cddf.XML",
            SourceDirPath = sourceDirPath,
            ConnectionString = connectionString
        };
        ImportOneXmlToMsSql ndk = new ImportOneXmlToMsSql(NormativeDocsKinds);
        ndk.DoImportNormativeDocsKinds();

        ObjectInfo AddHouseTypes = new ObjectInfo
        {
            DestinationTableName = "[AddHouseTypes]",
            DestinationSchemaName = "gar",
            SourceFileName = "AS_ADDHOUSE_TYPES_20240815_656d52c9-09af-4b12-8d3c-5732f358506b.XML",
            SourceDirPath = sourceDirPath,
            ConnectionString = connectionString
        };
        //ImportOneXmlToMsSql aht = new ImportOneXmlToMsSql(AddHouseTypes);
        //aht.DoImportAddHouseTypes();

        ObjectInfo AppartmentTypes = new ObjectInfo
        {
            DestinationTableName = "[AppartmentTypes]",
            DestinationSchemaName = "gar",
            SourceFileName = "AS_APARTMENT_TYPES_20240815_6d8bafd4-c0b1-4185-a786-300406fc8bc1.XML",
            SourceDirPath = sourceDirPath,
            ConnectionString = connectionString
        };
        //ImportOneXmlToMsSql apt = new ImportOneXmlToMsSql(AppartmentTypes);
        //apt.DoImportTypes1();

        ObjectInfo HouseTypes = new ObjectInfo
        {
            DestinationTableName = "[HouseTypes]",
            DestinationSchemaName = "gar",
            SourceFileName = "AS_HOUSE_TYPES_20240815_5d97947a-230c-4bc8-ad24-6077a0be2d21.XML",
            SourceDirPath = sourceDirPath,
            ConnectionString = connectionString
        };
        //ImportOneXmlToMsSql ht = new ImportOneXmlToMsSql(HouseTypes);
        //ht.DoImportTypes1();

        ObjectInfo NormativeDocsTypes = new ObjectInfo
        {
            DestinationTableName = "[NormativeDocsTypes]",
            DestinationSchemaName = "gar",
            SourceFileName = "AS_NORMATIVE_DOCS_TYPES_20240815_a1706595-44dc-4344-92d4-bea8f42dada7.XML",
            SourceDirPath = sourceDirPath,
            ConnectionString = connectionString
        };
        //ImportOneXmlToMsSql ndt = new ImportOneXmlToMsSql(NormativeDocsTypes);
        //ndt.DoImportTypes2();
    }
}