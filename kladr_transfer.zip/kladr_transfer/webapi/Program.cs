using DatameshMsSql;
using DatameshPgSql;
using Shared;
using Shared.Transformations.mssql;
using Shared.Transformations.pqsql;

const TargetDb tdb = TargetDb.pgsql;
string connString = ConnectionString.GetConnectionString(TargetDb.pgsql);
MyLogger.InitLogger();

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseDeveloperExceptionPage();
app.UseSwagger();
app.UseSwaggerUI();

app.MapGet("/", () => "Hello World!");

app.MapGet("/socrbase", () =>
{
    string selectSql;
    switch (tdb)
    {
        case TargetDb.mssql:
            selectSql = SocrBaseMsSql.SQL;
            MsSqlData msd = new MsSqlData(connString, SocrBaseMsSql.SQL);
            return msd.AsJson;
        case TargetDb.pgsql:
            selectSql = SocrBasePgSql.SQL;
            PgSqlData psd = new PgSqlData(connString, selectSql);
            return psd.AsJson;
    }
});

app.MapGet("/altnames", () =>
{
    string selectSql;
    switch (tdb)
    {
        case TargetDb.mssql:
            selectSql = AltNamesMsSql.SQL;
            MsSqlData msd = new MsSqlData(connString, selectSql);
            return msd.AsJson;
        case TargetDb.pgsql:
            selectSql = AltNamesPgSql.SQL;
            PgSqlData psd = new PgSqlData(connString, selectSql);
            return psd.AsJson;
    }
});

app.MapGet("/kladr", () =>
{
    string selectSql;
    switch (tdb)
    {
        case TargetDb.mssql:
            selectSql = KladrMsSql.SQL;
            MsSqlData msd = new MsSqlData(connString, selectSql);
            return msd.AsJson;
        case TargetDb.pgsql:
            selectSql = KladrPgSql.SQL;
            PgSqlData psd = new PgSqlData(connString, selectSql);
            return psd.AsJson;
    }
});

app.MapGet("/street", () =>
{
    string selectSql;
    switch (tdb)
    {
        case TargetDb.mssql:
            selectSql = StreetMsSql.SQL;
            MsSqlData msd = new MsSqlData(connString, selectSql);
            return msd.AsJson;
        case TargetDb.pgsql:
            selectSql = StreetPgSql.SQL;
            PgSqlData psd = new PgSqlData(connString, selectSql);
            return psd.AsJson;
    }
});

app.MapGet("/doma", () =>
{
    string selectSql;
    switch (tdb)
    {
        case TargetDb.mssql:
            selectSql = DomaMsSql.SQL;
            MsSqlData msd = new MsSqlData(connString, selectSql);
            return msd.AsJson;
        case TargetDb.pgsql:
            selectSql = DomaPgSql.SQL;
            PgSqlData psd = new PgSqlData(connString, selectSql);
            return psd.AsJson;
    }
});

app.Run();
