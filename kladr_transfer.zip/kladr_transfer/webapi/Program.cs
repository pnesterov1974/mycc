using DatameshPgSql;
using Shared;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseDeveloperExceptionPage();
app.UseSwagger();
app.UseSwaggerUI();

string connString = ConnectionString.GetConnectionString(DBSource.pgsql);
MyLogger.InitLogger();

app.MapGet("/", () => "Hello World!");

app.MapGet("/socrbase", () =>
{
    string selectSql = """
             SELECT level,
                    scname,
                    socrname,
                    kod_t_st
             FROM public.socrbase;
             """;
    PgSqlData psd = new PgSqlData(connString, selectSql);
    return psd.AsJson;
});

app.MapGet("/altnames", () =>
{
    string selectSql = """
             SELECT level,
                    oldcode,
                    newcode
             FROM public.altnames;
             """;
    PgSqlData psd = new PgSqlData(connString, selectSql);
    return psd.AsJson;
});

app.MapGet("/kladr", () =>
{
    string selectSql = """
             SELECT code,
                    name,
                    socr,
                    index,
                    gninmb,
                    uno,
                    ocatd,
                    status
             FROM public.kladr;
             """;
    PgSqlData psd = new PgSqlData(connString, selectSql);
    return psd.AsJson;
});

app.MapGet("/street", () =>
{
    string selectSql = """
             SELECT code,
                    name,
                    socr,
                    index,
                    gninmb,
                    uno,
                    ocatd
             FROM public.street;
             """;
    PgSqlData psd = new PgSqlData(connString, selectSql);
    return psd.AsJson;
});

app.MapGet("/doma", () =>
{
    string selectSql = """
             SELECT code,
                    name,
                    korp,
                    socr,
                    index,
                    gninmb,
                    uno,
                    ocatd
             FROM public.doma;
             """;
    PgSqlData psd = new PgSqlData(connString, selectSql);
    return psd.AsJson;
});

app.Run();
