using DatameshPgSql;
using Microsoft.AspNetCore.Mvc;
using Shared;
//using Serilog;

namespace mvc.Controllers;

[ApiController]
[Route("api/[controller]")]
public class KladrController : ControllerBase
{
    //public static string connString = "Data Source=192.168.1.79,1433;Initial Catalog=kladr;User ID=sa;Password=Exptsci123;Trust Server Certificate=True;Connection Timeout=500";
    public static string connString = ConnectionString.GetConnectionString(DBSource.pgsql);

    [HttpGet]
    [Route("/socrbase")]
    public string GetSocrBase()
    {
        string selectSql = """
             SELECT level,
                    scname,
                    socrname,
                    kod_t_st
             FROM public.socrbase;
             """;
        PgSqlData psd = new PgSqlData(connString, selectSql);
        return psd.AsJson;
    }

    [HttpGet]
    [Route("/altnames")]
    public string GetAltNames()
    {
        string selectSql = """
             SELECT level,
                    oldcode,
                    newcode
             FROM public.altnames;
             """;
        PgSqlData psd = new PgSqlData(connString, selectSql);
        return psd.AsJson;
    }

    [HttpGet]
    [Route("/kladr")]
    public string GetKladr()
    {
        string selectSql = """
             SELECT code,
                    name,
                    socr,
                    index,
                    gninmb,
                    uno,
                    ocatd,
                    status
             FROM public.kladr;
             """;
        PgSqlData psd = new PgSqlData(connString, selectSql);
        return psd.AsJson;
    }

    [HttpGet]
    [Route("/street")]
    public string GetStreet()
    {
        string selectSql = """
             SELECT code,
                    name,
                    socr,
                    index,
                    gninmb,
                    uno,
                    ocatd
             FROM public.street;
             """;
        PgSqlData psd = new PgSqlData(connString, selectSql);
        return psd.AsJson;
    }

    [HttpGet]
    [Route("/doma")]
    public string GetDoma()
    {
        string selectSql = """
             SELECT code,
                    name,
                    korp,
                    socr,
                    index,
                    gninmb,
                    uno,
                    ocatd
             FROM public.doma;
             """;
        PgSqlData psd = new PgSqlData(connString, selectSql);
        return psd.AsJson;
    }
}