using Data.mesh.mssql;
using Data.mesh.pgsql;
using Microsoft.AspNetCore.Mvc;
using Shared;
using Shared.readSql.mssql;
using Shared.readSql.pgsql;

namespace mvc.Controllers;

[ApiController]
[Route("api/[controller]")]
public class KladrController : ControllerBase
{
    //public static string connString = "Data Source=192.168.1.79,1433;Initial Catalog=kladr;User ID=sa;Password=Exptsci123;Trust Server Certificate=True;Connection Timeout=500";
    public const TargetDb tdb = TargetDb.pgsql;
    public string connString = ConnectionString.GetConnectionString(TargetDb.pgsql);

    [HttpGet]
    [Route("/socrbase")]
    public string GetSocrBase()
    {
        switch (tdb)
        {
            case TargetDb.mssql:
            {
                MsSqlData msd = new MsSqlData(connString, SocrBaseMsSql.SQL);
                return msd.AsJson;
            }
            case TargetDb.pgsql:
            {
                PgSqlData psd = new PgSqlData(connString, SocrBasePgSql.SQL);
                return psd.AsJson;
            }
        }
    }

    [HttpGet]
    [Route("/altnames")]
    public string GetAltNames()
    {
        switch (tdb)
        {
            case TargetDb.mssql:
            {
                MsSqlData msd = new MsSqlData(connString, AltNamesMsSql.SQL);
                return msd.AsJson;
            }
            case TargetDb.pgsql:
            {
                PgSqlData psd = new PgSqlData(connString, AltNamesPgSql.SQL);
                return psd.AsJson;
            }
        }
    }

    [HttpGet]
    [Route("/kladr")]
    public string GetKladr()
    {
        switch (tdb)
        {
            case TargetDb.mssql:
            {
                MsSqlData msd = new MsSqlData(connString, KladrMsSql.SQL);
                return msd.AsJson;
            }
            case TargetDb.pgsql:
            {
                PgSqlData psd = new PgSqlData(connString, KladrPgSql.SQL);
                return psd.AsJson;
            }
        }
    }

    [HttpGet]
    [Route("/street")]
    public string GetStreet()
    {
        switch (tdb)
        {
            case TargetDb.mssql:
            {
                MsSqlData msd = new MsSqlData(connString, StreetMsSql.SQL);
                return msd.AsJson;
            }
            case TargetDb.pgsql:
            {
                PgSqlData psd = new PgSqlData(connString, StreetPgSql.SQL);
                return psd.AsJson;
            }
        }
    }

    [HttpGet]
    [Route("/doma")]
    public string GetDoma()
    {
        switch (tdb)
        {
            case TargetDb.mssql:
            {
                MsSqlData msd = new MsSqlData(connString, DomaMsSql.SQL);
                return msd.AsJson;
            }
            case TargetDb.pgsql:
            {
                PgSqlData psd = new PgSqlData(connString, DomaPgSql.SQL);
                return psd.AsJson;
            }
        }
    }
}