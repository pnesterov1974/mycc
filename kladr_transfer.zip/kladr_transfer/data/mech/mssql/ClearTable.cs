using Microsoft.Data.SqlClient;
using Shared;

namespace DatameshMsSql;
public class ClearTable
{
    private string connectionString;
    private string schemaName;
    private string tableName;
    private string fullName
    {
        get => string.Join('.', schemaName, tableName);
    } 
    private string truncateSql
    {
        get => $"TRUNCATE TABLE {this.fullName}";
    }  
    public ClearTable(string connectionString, string schemaName, string tableName)
    {
        this.connectionString = connectionString;
        this.schemaName = schemaName;
        this.tableName = tableName;
    }

    public bool ClearDestTable()
    {
        MyLogger.Log.Information("Очистка таблицы {fullname}", this.fullName);
        MyLogger.Log.Debug("SQL : \n{connstr}", this.truncateSql);
        
        using (SqlConnection conn = new SqlConnection(this.connectionString))
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(this.truncateSql, conn);
                cmd.ExecuteNonQuery();
                MyLogger.Log.Information("Таблица {table} очищена...", this.fullName);
                return true;
            }
            catch (Exception ex)
            {
                MyLogger.Log.Error("Ошибка при очистке таблицы {table}: \n {ErrMessage}", this.fullName, ex.Message);
                return false;
            }
        }
    }
}
