using System.Data;

namespace DatameshMsSql;

public interface IDataForJson
{
    public DataTable Data { get; }
    public void Read();
}
