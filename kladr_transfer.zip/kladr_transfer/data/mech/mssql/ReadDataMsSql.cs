using System.Data;
using Microsoft.Data.SqlClient;
using Shared;

namespace DatameshMsSql;

public class MsSqlData: IDataForJson
{
    public DataTable Data { get; set; }
    protected string connectionString{ get; set; } = string.Empty;
    protected string selectSql{ get; set; } = string.Empty;

    public MsSqlData(string connectionString, string selectSql)
    {
        this.connectionString = connectionString;
        this.selectSql = selectSql;
    }

    public MsSqlData(string connectionString, string selectSql, bool readAtStart)
        : this(connectionString, selectSql)
    {
        if (readAtStart)
        {
            this.Read();
        }
    }
    
    public void Read()
    {
        MyLogger.Log.Information("Загрузка данных...");
        MyLogger.Log.Debug("Загрузка данных из : \n{connstr}", this.connectionString);
        MyLogger.Log.Debug("SQL : \n{connstr}", this.selectSql);
        this.Data = new DataTable();
        int RecordCount = 0;
        using (SqlConnection conn = new SqlConnection(this.connectionString))
        {
            SqlDataAdapter adapter = new SqlDataAdapter(this.selectSql, conn);
            try
            {
                RecordCount = adapter.Fill(this.Data);
                MyLogger.Log.Information("Загружено {recorcount} записей", RecordCount);
            }
            catch (Exception ex)
            {
                MyLogger.Log.Debug("Ошибка чтения даннтых \n {errmes}", ex.Message);
            }
        }
    }
}
