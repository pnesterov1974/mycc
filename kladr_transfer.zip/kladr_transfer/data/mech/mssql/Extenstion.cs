using Newtonsoft.Json;

namespace DatameshMsSql;

public static class GetJsonExtension
{
    public static string AsJson(this IDataForJson schema) => JsonConvert.SerializeObject(schema.Data, Formatting.Indented);
}
