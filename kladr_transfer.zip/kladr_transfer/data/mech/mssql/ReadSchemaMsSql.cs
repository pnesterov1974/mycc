using System.Data;
using Microsoft.Data.SqlClient;
using Shared;
using static Shared.MyLogger;

namespace DatameshMsSql;

public class MsSqlSchema : IDataForJson
{
    private DataTable data;
    public DataTable Data
    {
        get => this.data;
    }

    protected string connectionString { get; set; } = string.Empty;
    protected string selectSql { get; set; } = string.Empty;

    public MsSqlSchema(string connectionString, string selectSql)
    {
        this.connectionString = connectionString;
        this.selectSql = selectSql;
    }
    public MsSqlSchema(string connectionString, string selectSql, bool readAtStart)
         : this(connectionString, selectSql)
    {
        if (readAtStart)
        {
            this.Read();
        }
    }

    public void Read()
    {
        Log.Information("Загрузка схемы...");
        Log.Debug("Загрузка схемы из : \n{connstr}", this.connectionString);
        Log.Debug("SQL : \n{connstr}", this.selectSql);
        this.data = new DataTable();

        using (SqlConnection conn = new SqlConnection(this.connectionString))
        {
            using (SqlCommand cmd = new SqlCommand(this.selectSql, conn))
            {
                try
                {
                    conn.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.KeyInfo))
                    {
                        this.data = rdr.GetSchemaTable();
                        MyLogger.Log.Information("Схема загружена");
                    }
                }
                catch (Exception ex)
                {
                    MyLogger.Log.Debug("Ошибка чтения даннтых \n {errmes}", ex.Message);
                }
            }
        }
    }

    public Dictionary<string, string> GetFieldList()
    {
        int ColumnNameColIdx = this.data.Columns["BaseColumnName"].Ordinal;
        int DataTypeNameColIdx = this.data.Columns["DataTypeName"].Ordinal;
        int ColumnSizeColIdx = this.data.Columns["ColumnSize"].Ordinal;

        Dictionary<string, string> Fields = new Dictionary<string, string>();

        Log.Information("first: {col} second: {type}", ColumnNameColIdx, DataTypeNameColIdx);
        foreach (DataRow dataRow in this.Data.Rows)
        {
            string columnName = dataRow[ColumnNameColIdx].ToString();
            string columnType = dataRow[DataTypeNameColIdx].ToString();
            string columnSize = dataRow[ColumnSizeColIdx].ToString();

            string columnTypeSized = string.Empty;

            if (columnType.Equals("nvarchar"))
            {
                columnTypeSized = $"{columnType}({columnSize})";
            }
            else
            {
                columnTypeSized = columnType;
            }
            Fields.Add(columnName, columnTypeSized);
            Log.Debug("columnName: {col} columnType: {type}", columnName, columnTypeSized);
        }
        //Log.Debug(Fields.ToString());
        return Fields;
    }
}
