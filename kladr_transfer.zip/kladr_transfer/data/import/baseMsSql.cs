using Microsoft.Data.SqlClient;
using Serilog;
using Shared;

namespace CommonImport;

public class ImportBaseMsSql
{
    public ImportBaseMsSql(ObjectInfo oi)
    {
        this.objectInfo = oi;
    }

    public ILogger Log { get; set; }
    protected ObjectInfo objectInfo { get; set; }
    protected string truncateTableSql
    {
        get => $"TRUNCATE TABLE {this.objectInfo.DestinationTableFullName};";
    }

    protected bool clearDestTable()
    {
        using (SqlConnection conn = new SqlConnection(this.objectInfo.ConnectionString))
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand($"TRUNCATE TABLE {this.objectInfo.DestinationTableFullName}", conn);
                cmd.ExecuteNonQuery();
                Log.Debug("Очистка таблицы {table} \nSQL:{sql}", this.objectInfo.DestinationTableName, cmd.CommandText);
                Log.Information("Таблица {table} очищена...", this.objectInfo.DestinationTableName);
                return true;
            }
            catch (Exception ex)
            {
                Log.Error("Ошибка при очистке таблицы {table}: \n {ErrMessage}", this.objectInfo.DestinationTableName, ex.Message);
                return false;
            }
        }
    }
}