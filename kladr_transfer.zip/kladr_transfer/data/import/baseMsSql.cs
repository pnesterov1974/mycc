using Microsoft.Data.SqlClient;
using Shared;
using static Shared.MyLogger;

namespace CommonImport;

public class ImportBaseMsSql
{
    public ImportBaseMsSql(ObjectInfo oi)
    {
        this.objectInfo = oi;
    }

    protected ObjectInfo objectInfo { get; set; }

    protected bool clearDestTable()
    {
        using (SqlConnection conn = new SqlConnection(this.objectInfo.ConnectionString))
        {
            try
            {
                conn.Open();
                string truncateTableSql = $"TRUNCATE TABLE {this.objectInfo.DestinationTableFullName};";
                SqlCommand cmd = new SqlCommand(truncateTableSql, conn);
                cmd.ExecuteNonQuery();
                Log.Debug("Очистка таблицы {table} \nSQL:{sql}", this.objectInfo.DestinationTableName, cmd.CommandText);
                Log.Information("Таблица {table} очищена...", this.objectInfo.DestinationTableName);
                return true;
            }
            catch (Exception ex)
            {
                Log.Error("Ошибка при очистке таблицы {table}: \n {ErrMessage}", this.objectInfo.DestinationTableName, ex.Message);
                return false;
            }
        }
    }
}