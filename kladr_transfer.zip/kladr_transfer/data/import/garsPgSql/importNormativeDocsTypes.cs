using System.Xml;
using CommonImport;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace GarImport;
public class ImportNormativeDocTypes: ImportBasePgSql
{
    public ImportNormativeDocTypes(ObjectInfo oi) : base(oi) { }

    private List<NormativeDocsTypes> GetSourceData()
    {
        List<NormativeDocsTypes> res = new List<NormativeDocsTypes>();
        Log.Information("Импорт из файла ...{file}", this.objectInfo.SourceFileName);
        XmlDocument xDoc = new XmlDocument();
        xDoc.Load(this.objectInfo.SourceFilePath);
        XmlElement? xRoot = xDoc.DocumentElement;
        if (xRoot != null)
        {
            foreach (XmlElement xnode in xRoot)
            {
                XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                int id = int.Parse(idAttr.Value);
                XmlNode NameAttr = xnode.Attributes.GetNamedItem("NAME");
                string name = NameAttr.Value;
                XmlNode? StartDateAttr = xnode.Attributes.GetNamedItem("STARTDATE");
                DateOnly startDate = DateOnly.Parse(StartDateAttr.Value);
                XmlNode? EndDateAttr = xnode.Attributes.GetNamedItem("ENDDATE");
                DateOnly endDate = DateOnly.Parse(EndDateAttr.Value);
                res.Add(new NormativeDocsTypes
                    {
                        Id = id,
                        Name = name,
                        StartDate = startDate,
                        EndDate = endDate
                    }
                );
                Log.Information("ID:{id} == NAME:{name} == STARTDATE:{startdate} == ENDDATE:{enddate}", id, name, startDate, endDate);
            }
        }
        else
        {
            Log.Information("Элементы не найдены");
        }
        return res;
    }

    public void DoImport(bool clearDestinationTableInAdvance = true)
    {
        Log.Information("Импорт из файла {file}", this.objectInfo.SourceFilePath);

        if (File.Exists(this.objectInfo.SourceFilePath))
        {
            Log.Information("Файл {file} существует...", this.objectInfo.SourceFileName);
            if (clearDestinationTableInAdvance && this.clearDestTable())
            {
                var data = this.GetSourceData();

                using var conn = new NpgsqlConnection(this.objectInfo.ConnectionString);
                conn.Open();

                var batch = new NpgsqlBatch(conn);

                foreach (var d in data)
                {
                    var bcmd = new NpgsqlBatchCommand(
                        $"INSERT INTO {this.objectInfo.DestinationTableFullName}(id, name, startdate, enddate) VALUES (@id, @name, @startdate, @enddate);"
                        );

                    bcmd.Parameters.AddWithValue("@id", d.Id);
                    bcmd.Parameters.AddWithValue("@name", d.Name);
                    bcmd.Parameters.AddWithValue("@startdate", d.StartDate);
                    bcmd.Parameters.AddWithValue("@enddate", d.EndDate);

                    Log.Debug(bcmd.CommandText);

                    batch.BatchCommands.Add(bcmd);
                }

                int recs = batch.ExecuteNonQuery();
                Log.Information("Загружено записей {recs} из {file}", recs, this.objectInfo.SourceFileName);
            }
        }
        else
        {
            Log.Information("Файл {file} не найден", this.objectInfo.SourceFilePath);
        }
    }
}
