using System.Xml;
using CommonImport;
using Npgsql;
using Shared;

namespace GarImport;
public class ImportAppartmentTypes: ImportBasePgSql
{
    public ImportAppartmentTypes(ObjectInfo oi) : base(oi) { }

    private List<AppartmentTypes> GetSourceData()
    {
        List<AppartmentTypes> res = new List<AppartmentTypes>();
        MyLogger.Log.Information("Импорт из файла ...{file}", this.objectInfo.SourceFileName);
        XmlDocument xDoc = new XmlDocument();
        xDoc.Load(this.objectInfo.SourceFilePath);
        XmlElement? xRoot = xDoc.DocumentElement;
        if (xRoot != null)
        {
            foreach (XmlElement xnode in xRoot)
            {
                XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                int id = int.Parse(idAttr.Value);
                XmlNode NameAttr = xnode.Attributes.GetNamedItem("NAME");
                string name = NameAttr.Value;
                XmlNode? ShortNameAttr = xnode.Attributes.GetNamedItem("SHORTNAME");
                string? shortname = ShortNameAttr.Value;
                XmlNode? DescAttr = xnode.Attributes.GetNamedItem("DESC");
                string? desc = DescAttr.Value;
                XmlNode IsActiveAttr = xnode.Attributes.GetNamedItem("ISACTIVE");
                string _isActive = IsActiveAttr.Value;
                bool isActive = false;
                if (_isActive.ToLower().Equals("true"))
                {
                    isActive = true;
                }
                else if (_isActive.ToLower().Equals("false"))
                {
                    isActive = false;
                }
                XmlNode? UpdateDateAttr = xnode.Attributes.GetNamedItem("UPDATEDATE");
                DateOnly updateDate = DateOnly.Parse(UpdateDateAttr.Value);
                XmlNode? StartDateAttr = xnode.Attributes.GetNamedItem("STARTDATE");
                DateOnly startDate = DateOnly.Parse(StartDateAttr.Value);
                XmlNode? EndDateAttr = xnode.Attributes.GetNamedItem("ENDDATE");
                DateOnly endDate = DateOnly.Parse(EndDateAttr.Value);
                res.Add(new AppartmentTypes
                    {
                        Id = id,
                        Name = name,
                        ShortName = shortname,
                        Desc = desc,
                        IsActive = isActive,
                        UpdateDate = updateDate,
                        StartDate = startDate,
                        EndDate = endDate
                    }
                );
                MyLogger.Log.Information("ID:{id} == NAME:{name} == SHORTNAME:{shortname} == DESC:{desc} == ISACTIVE:{isactive} == UPDATEDATE:{updatedate} == STARTDATE:{startdate} == ENDDATE:{enddate}", id, name, shortname, desc, isActive, updateDate, startDate, endDate);
            }
        }
        else
        {
            MyLogger.Log.Information("Элементы не найдены");
        }
        return res;
    }


    public void DoImport(bool clearDestinationTableInAdvance = true)
    {
        MyLogger.Log.Information("Импорт из файла {file}", this.objectInfo.SourceFilePath);

        if (File.Exists(this.objectInfo.SourceFilePath))
        {
            MyLogger.Log.Information("Файл {file} существует...", this.objectInfo.SourceFileName);
            if (clearDestinationTableInAdvance && this.clearDestTable())
            {
                var data = this.GetSourceData();

                using var conn = new NpgsqlConnection(this.objectInfo.ConnectionString);
                conn.Open();

                var batch = new NpgsqlBatch(conn);

                foreach (var d in data)
                {
                    var bcmd = new NpgsqlBatchCommand(
                        $"INSERT INTO {this.objectInfo.DestinationTableFullName}(id, name, shortname, descr, isactive, updatedate, startdate, enddate) VALUES (@id, @name, @shortname, @desc, @isactive, @updatedate, @startdate, @enddate);"
                        );

                    bcmd.Parameters.AddWithValue("@id", d.Id);
                    bcmd.Parameters.AddWithValue("@name", d.Name);
                    bcmd.Parameters.AddWithValue("@shortname", d.ShortName);
                    bcmd.Parameters.AddWithValue("@desc", d.Desc);
                    bcmd.Parameters.AddWithValue("@isactive", d.IsActive);
                    bcmd.Parameters.AddWithValue("@updatedate", d.UpdateDate);
                    bcmd.Parameters.AddWithValue("@startdate", d.StartDate);
                    bcmd.Parameters.AddWithValue("@enddate", d.EndDate);

                    MyLogger.Log.Debug(bcmd.CommandText);

                    batch.BatchCommands.Add(bcmd);
                }

                int recs = batch.ExecuteNonQuery();
                MyLogger.Log.Information("Загружено записей {recs} из {file}", recs, this.objectInfo.SourceFileName);
            }
        }
        else
        {
            MyLogger.Log.Information("Файл {file} не найден", this.objectInfo.SourceFilePath);
        }
    }

}
