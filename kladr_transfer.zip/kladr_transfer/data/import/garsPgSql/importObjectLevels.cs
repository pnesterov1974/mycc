using System.Xml;
using CommonImport;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace GarImport;
public class ImportObjectLevels: ImportBasePgSql
{
    public ImportObjectLevels(ObjectInfo oi) : base(oi) { ; }

    private List<ObjectLevels> GetSourceData()
    {
        List<ObjectLevels> res = new List<ObjectLevels>();
        Log.Information("Импорт из файла ...{file}", this.objectInfo.SourceFileName);
        XmlDocument xDoc = new XmlDocument();
        xDoc.Load(this.objectInfo.SourceFilePath);
        XmlElement? xRoot = xDoc.DocumentElement;
        if (xRoot != null)
        {
            foreach (XmlElement xnode in xRoot)
            {
                XmlNode levelAttr = xnode.Attributes.GetNamedItem("LEVEL");
                int level = int.Parse(levelAttr?.Value);
                XmlNode NameAttr = xnode.Attributes.GetNamedItem("NAME");
                string name = NameAttr.Value;
                XmlNode IsActiveAttr = xnode.Attributes.GetNamedItem("ISACTIVE");
                string _isActive = IsActiveAttr.Value;
                bool isActive = false;
                if (_isActive.ToLower().Equals("true"))
                {
                    isActive = true;
                }
                else if (_isActive.ToLower().Equals("false"))
                {
                    isActive = false;
                }
                XmlNode UpdateDateAttr = xnode.Attributes.GetNamedItem("UPDATEDATE");
                DateOnly updateDate = DateOnly.Parse(UpdateDateAttr.Value);
                XmlNode StartDateAttr = xnode.Attributes.GetNamedItem("STARTDATE");
                DateOnly startDate = DateOnly.Parse(StartDateAttr.Value);
                XmlNode EndDateAttr = xnode.Attributes.GetNamedItem("ENDDATE");
                DateOnly endDate = DateOnly.Parse(EndDateAttr.Value);
                res.Add(new ObjectLevels
                    {
                        Level = level,
                        Name = name,
                        IsActive = isActive,
                        UpdateDate = updateDate,
                        StartDate = startDate,
                        EndDate = endDate
                    }
                );
                Log.Information("LEVEL:{level} == NAME:{name} == ISACTIVE:{isactive} == UPDATEDATE:{updatedate} == STARTDATE:{startdate} == ENDDATE:{enddate}", level, name, isActive, updateDate, startDate, endDate);
            }
        }
        else
        {
            Log.Information("Элементы не найдены");
        }
        return res;
    }

    public void DoImport(bool clearDestinationTableInAdvance = true)
    {
        Log.Information("Импорт из файла {file}", this.objectInfo.SourceFilePath);

        if (File.Exists(this.objectInfo.SourceFilePath))
        {
            Log.Information("Файл {file} существует...", this.objectInfo.SourceFileName);
            if (clearDestinationTableInAdvance && this.clearDestTable())
            {
                var data = this.GetSourceData();

                using var conn = new NpgsqlConnection(this.objectInfo.ConnectionString);
                conn.Open();

                var batch = new NpgsqlBatch(conn);

                foreach (var d in data)
                {
                    var bcmd = new NpgsqlBatchCommand(
                        "INSERT INTO gar.object_levels(level, name, isactive, updatedate, startdate, enddate) VALUES (@level, @name, @isactive, @updatedate, @startdate, @enddate);"
                        );

                    bcmd.Parameters.AddWithValue("@level", d.Level);
                    bcmd.Parameters.AddWithValue("@name", d.Name);
                    bcmd.Parameters.AddWithValue("@isactive", d.IsActive);
                    bcmd.Parameters.AddWithValue("@updatedate", d.UpdateDate);
                    bcmd.Parameters.AddWithValue("@startdate", d.StartDate);
                    bcmd.Parameters.AddWithValue("@enddate", d.EndDate);

                    Log.Debug(bcmd.CommandText);

                    batch.BatchCommands.Add(bcmd);
                }

                int recs = batch.ExecuteNonQuery();
                Log.Information("Загружено записей {recs} из {file}", recs, this.objectInfo.SourceFileName);
            }
        }
        else
        {
            Log.Information("Файл {file} не найден", this.objectInfo.SourceFilePath);
        }
    }
}
