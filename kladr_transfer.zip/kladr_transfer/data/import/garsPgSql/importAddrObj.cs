using System.Xml;
using Data;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Import.gar.pgsql;
public class ImportAddrObj : BasePgSql
{
    protected ImportObjectsInfo objectsInfo { get; set; }
    public ImportAddrObj(ImportObjectsInfo objectsInfo) => this.objectsInfo = objectsInfo;

    // TODO: FineTune: clearInAdvance, try-catch, log_events backward_rename ??
    public int DoImportData(bool clearDestTableInAdvance = true)
    {
        if (clearDestTableInAdvance)
        {
            bool cl = this.ClearDestTable(this.objectsInfo.ConnectionString, this.objectsInfo.TargetTableFullName);
        }

        int TotalRecords = 0;
        foreach (var s in this.objectsInfo.SourceFilePaths)
        {
            Log.Information("Импорт из файла {file}", s.FileFullPath);

            if (File.Exists(s.FileFullPath))
            {
                Log.Information("Файл {file} существует", s.FileFullPath);
                List<AddrObj> data = this.ReadSourceDataOneFile(s.FileFullPath);
                TotalRecords += this.WriteDataOneFile(data, s.FileName);
            }
            else
            {
                Log.Warning("Файл {file} НЕ существует, обработка пропускается", s.FileFullPath);
            }
        }
        return TotalRecords;
    }

    private List<AddrObj> ReadSourceDataOneFile(string fileFullPath)
    {
        List<AddrObj> res = new List<AddrObj>();
        Log.Information("Обработка файла ...{file}", fileFullPath);
        XmlDocument xDoc = new XmlDocument();
        xDoc.Load(fileFullPath);
        XmlElement? xRoot = xDoc.DocumentElement;
        if (xRoot != null)
        {
            int i = 0;
            foreach (XmlElement xnode in xRoot)
            {
                XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                string id = idAttr.Value;

                XmlNode ObjectIdAttr = xnode.Attributes.GetNamedItem("OBJECTID");
                string objectId = ObjectIdAttr.Value;

                XmlNode ObjectGUIDAttr = xnode.Attributes.GetNamedItem("OBJECTGUID");
                string objectGUID = ObjectGUIDAttr.Value;

                XmlNode NameAttr = xnode.Attributes.GetNamedItem("NAME");
                string name = NameAttr.Value;

                XmlNode TypeNameAttr = xnode.Attributes.GetNamedItem("TYPENAME");
                string typeName = TypeNameAttr.Value;

                XmlNode LevelAttr = xnode.Attributes.GetNamedItem("LEVEL");
                string level = LevelAttr.Value;

                XmlNode OperTypeIdAttr = xnode.Attributes.GetNamedItem("OPERTYPEID");
                string operTypeId = OperTypeIdAttr.Value;

                XmlNode PrevIdAttr = xnode.Attributes.GetNamedItem("PREVID");
                string prevId = PrevIdAttr.Value;

                string nextId = string.Empty;
                try
                {
                    XmlNode NextIdAttr = xnode.Attributes.GetNamedItem("NEXTID");
                    nextId = NextIdAttr.Value;
                }
                catch
                {
                    Log.Warning("для ID {id} проблема с атрибутом NEXTID", id);
                    //nextId = string.Empty;
                }

                XmlNode UpdateDateAttr = xnode.Attributes.GetNamedItem("UPDATEDATE");
                string updateDate = UpdateDateAttr.Value;

                XmlNode StartDateAttr = xnode.Attributes.GetNamedItem("STARTDATE");
                string startDate = StartDateAttr.Value;

                XmlNode EndDateAttr = xnode.Attributes.GetNamedItem("ENDDATE");
                string endDate = EndDateAttr.Value;

                XmlNode IsActualAttr = xnode.Attributes.GetNamedItem("ISACTUAL");
                string isActual = IsActualAttr.Value;

                XmlNode IsActiveAttr = xnode.Attributes.GetNamedItem("ISACTIVE");
                string isActive = IsActiveAttr.Value;
                i += 1;
                res.Add(new AddrObj
                    {
                        Id = id,
                        ObjectId = objectId,
                        ObjectGUID = objectGUID,
                        Name = name,
                        TypeName = typeName,
                        Level = level,
                        OperTypeID = operTypeId,
                        PrevId = prevId,
                        NextId = nextId,
                        //NextId = "xx",
                        UpdateDate = updateDate,
                        StartDate = startDate,
                        EndDate = endDate,
                        IsActive = isActive,
                        IsActual = isActual
                    }
                );
            }
        }
        else
        {
            Log.Information("Элементы не найдены");
        }
        return res;
    }

    private int WriteDataOneFile(List<AddrObj> data, string fileName)
    {
        using var conn = new NpgsqlConnection(this.objectsInfo.ConnectionString);
        conn.Open();

        var batch = new NpgsqlBatch(conn);

        foreach (var d in data)
        {
            var bcmd = new NpgsqlBatchCommand($"""
                INSERT INTO {this.objectsInfo.TargetTableFullName} (
                    id, objectid, objectguid, name, typename, level, opertypeid, previd, nextid, updatedate, startdate, enddate, isactual, isactive
                )
                VALUES (
                    @id, @objectid, @objectguid, @name, @typename, @level, @opertypeid, @previd, @nextid, @updatedate, @startdate, @enddate, @isactual, @isactive
                );
                """
            );

            bcmd.Parameters.AddWithValue("@id", d.Id);
            bcmd.Parameters.AddWithValue("@objectid", d.ObjectId);
            bcmd.Parameters.AddWithValue("@objectguid", d.ObjectGUID);
            bcmd.Parameters.AddWithValue("@name", d.Name);
            bcmd.Parameters.AddWithValue("@typename", d.TypeName);
            bcmd.Parameters.AddWithValue("@level", d.Level);
            bcmd.Parameters.AddWithValue("@opertypeid", d.OperTypeID);
            bcmd.Parameters.AddWithValue("@previd", d.PrevId);
            bcmd.Parameters.AddWithValue("@nextid", d.NextId);
            bcmd.Parameters.AddWithValue("@updatedate", d.UpdateDate);
            bcmd.Parameters.AddWithValue("@startdate", d.StartDate);
            bcmd.Parameters.AddWithValue("@enddate", d.EndDate);
            bcmd.Parameters.AddWithValue("@isactive", d.IsActive);
            bcmd.Parameters.AddWithValue("@isactual", d.IsActual);

            batch.BatchCommands.Add(bcmd);
        }

        int recs = batch.ExecuteNonQuery();
        Log.Information("Загружено записей {recs} из {file}", recs, fileName);
        return recs;
    }
}