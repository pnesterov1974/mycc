using System.Xml;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Data.Import.gar.pgsql;
public class ImportNormativeDocsKinds: BasePgSql
{
    protected ImportObjectInfo objectInfo { get; set; }
    public ImportNormativeDocsKinds(ImportObjectInfo objectInfo) => this.objectInfo = objectInfo;

    private List<NormativeDocsKinds> GetSourceData()
    {
        List<NormativeDocsKinds> res = new List<NormativeDocsKinds>();
        Log.Information("Импорт из файла ...{file}", this.objectInfo.SourceFileName);
        XmlDocument xDoc = new XmlDocument();
        xDoc.Load(this.objectInfo.SourceFilePath);
        XmlElement? xRoot = xDoc.DocumentElement;
        if (xRoot != null)
        {
            foreach (XmlElement xnode in xRoot)
            {
                XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                int id = int.Parse(idAttr.Value);
                XmlNode NameAttr = xnode.Attributes.GetNamedItem("NAME");
                string name = NameAttr.Value;
                res.Add(new NormativeDocsKinds
                {
                    Id = id,
                    Name = name
                }
                );
            }
        }
        else
        {
            Log.Information("Элементы не найдены");
        }
        return res;
    }

    public void DoImport(bool clearDestTableInAdvance = true)
    {
        Log.Information("Импорт из файла {file}", this.objectInfo.SourceFilePath);

        if (File.Exists(this.objectInfo.SourceFilePath))
        {
            Log.Information("Файл {file} существует...", this.objectInfo.SourceFileName);
            if (!clearDestTableInAdvance ||
                (clearDestTableInAdvance &&
                    this.ClearDestTable(
                        this.objectInfo.ConnectionString,
                        this.objectInfo.TargetTableFullName
                    )
                )
           )
            {
                var data = this.GetSourceData();

                using var conn = new NpgsqlConnection(this.objectInfo.ConnectionString);
                conn.Open();

                var batch = new NpgsqlBatch(conn);

                foreach (var d in data)
                {
                    var bcmd = new NpgsqlBatchCommand($"INSERT INTO {this.objectInfo.TargetTableFullName}(id, name) VALUES (@id, @name);");
                    bcmd.Parameters.AddWithValue("@id", d.Id);
                    bcmd.Parameters.AddWithValue("@name", d.Name);
                    
                    batch.BatchCommands.Add(bcmd);
                }

                int recs = batch.ExecuteNonQuery();
                Log.Information("Загружено записей {recs} из {file}", recs, this.objectInfo.SourceFileName);
            }
        }
        else
        {
            Log.Information("Файл {file} не найден", this.objectInfo.SourceFilePath);
        }
    }
}
