namespace GarImport;
public class NormativeDocsKinds
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
}

class AddHouseTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? ShortName { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class AddrObjTypes
{
    public int Id { get; set; }
    public int Level { get; set; }
    public string Name { get; set; } = string.Empty;
    public string ShortName { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class AppartmentTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? ShortName { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class HouseTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? ShortName { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class NormativeDocsTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class ObjectLevels
{
    public int Level { get; set; }
    public string Name { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class OperationTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class ParamTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}

class RoomTypes
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Desc { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}
