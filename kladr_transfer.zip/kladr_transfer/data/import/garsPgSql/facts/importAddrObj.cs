using System.Xml;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Data.Import.gar.pgsql;
public class ImportAddrObj : BasePgSql
{
    protected ImportObjectsInfo objectsInfo { get; set; }
    public ImportAddrObj(ImportObjectsInfo objectsInfo) => this.objectsInfo = objectsInfo;

    public void DoImport(bool clearDestTableInAdvance = true)
    {
        if (clearDestTableInAdvance)
        {
            bool cl = this.ClearDestTable(this.objectsInfo.ConnectionString, this.objectsInfo.TargetTableFullName);
        }

        Log.Information("Начинаю импорт {table} ...", this.objectsInfo.TargetTableName);

        DateTime dtStart = DateTime.Now;
        int totalRecCount = this.ReadSourceData(this.objectsInfo.SourceFilePaths);
        DateTime dtFinish = DateTime.Now;

        TimeSpan duration = dtFinish - dtStart;
        Log.Information(
            "Импорт {table} закончен, всего загружено {records} записей... время обрадоьки: {duration}",
            this.objectsInfo.TargetTableName, totalRecCount, duration
            );
    }

    private int ReadSourceData(List<GarFileInfo> filePaths, int sourceBatchSize = 100000)
    {
        List<AddrObj> currentBatch = new List<AddrObj>(sourceBatchSize + 1);
        int currentBatchCount = 0;
        int recordCount = 0;
        Log.Information("Размер буфера на считывание {recbatchsize} ...", sourceBatchSize);
        foreach (var gfi in filePaths)
        {
            string filePath = gfi.FileFullPath;
            Log.Information("Обработка файла ...{file}", filePath);
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(filePath);
            XmlElement? xRoot = xDoc.DocumentElement;
            if (xRoot != null)
            {
                foreach (XmlElement xnode in xRoot)
                {
                    XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                    string id = idAttr.Value;

                    XmlNode ObjectIdAttr = xnode.Attributes.GetNamedItem("OBJECTID");
                    string objectId = ObjectIdAttr.Value;

                    XmlNode ObjectGUIDAttr = xnode.Attributes.GetNamedItem("OBJECTGUID");
                    string objectGUID = ObjectGUIDAttr.Value;

                    XmlNode NameAttr = xnode.Attributes.GetNamedItem("NAME");
                    string name = NameAttr.Value;

                    XmlNode TypeNameAttr = xnode.Attributes.GetNamedItem("TYPENAME");
                    string typeName = TypeNameAttr.Value;

                    XmlNode LevelAttr = xnode.Attributes.GetNamedItem("LEVEL");
                    string level = LevelAttr.Value;

                    XmlNode OperTypeIdAttr = xnode.Attributes.GetNamedItem("OPERTYPEID");
                    string operTypeId = OperTypeIdAttr.Value;

                    XmlNode PrevIdAttr = xnode.Attributes.GetNamedItem("PREVID");
                    string prevId = PrevIdAttr.Value;

                    string nextId = string.Empty;
                    try
                    {
                        XmlNode NextIdAttr = xnode.Attributes.GetNamedItem("NEXTID");
                        nextId = NextIdAttr.Value;
                    }
                    catch
                    {
                        ;//Log.Warning("для ID {id} проблема с атрибутом NEXTID", id);
                    }

                    XmlNode UpdateDateAttr = xnode.Attributes.GetNamedItem("UPDATEDATE");
                    string updateDate = UpdateDateAttr.Value;

                    XmlNode StartDateAttr = xnode.Attributes.GetNamedItem("STARTDATE");
                    string startDate = StartDateAttr.Value;

                    XmlNode EndDateAttr = xnode.Attributes.GetNamedItem("ENDDATE");
                    string endDate = EndDateAttr.Value;

                    XmlNode IsActualAttr = xnode.Attributes.GetNamedItem("ISACTUAL");
                    string isActual = IsActualAttr.Value;

                    XmlNode IsActiveAttr = xnode.Attributes.GetNamedItem("ISACTIVE");
                    string isActive = IsActiveAttr.Value;
                    
                    currentBatchCount += 1;

                    currentBatch.Add(new AddrObj
                    {
                        Id = id,
                        ObjectId = objectId,
                        ObjectGUID = objectGUID,
                        Name = name,
                        TypeName = typeName,
                        Level = level,
                        OperTypeID = operTypeId,
                        PrevId = prevId,
                        NextId = nextId,
                        UpdateDate = updateDate,
                        StartDate = startDate,
                        EndDate = endDate,
                        IsActive = isActive,
                        IsActual = isActual
                    });
                }
            }
            else
            {
                Log.Information("Элементы для файла {filepath} не найдены", filePath);
            }
        }
        if (currentBatchCount > 0)
        {
            recordCount += this.WriteDataOneBatch(currentBatch);
        }
        Log.Information("Всего обработано {recordCount} записей", recordCount);
        return recordCount;
    }

    private int WriteDataOneBatch(List<AddrObj> data, int bufferRecs = 20000)
    {
        int RecordCount = 0;
        int CurBufferRecs = 0;
        using var conn = new NpgsqlConnection(this.objectsInfo.ConnectionString);
        conn.Open();

        var batch = new NpgsqlBatch(conn);

        foreach (var d in data)
        {
            var bcmd = new NpgsqlBatchCommand($"""
                INSERT INTO {this.objectsInfo.TargetTableFullName} (
                    id, objectid, objectguid, name, typename, level, opertypeid, previd, nextid, updatedate, startdate, enddate, isactual, isactive
                )
                VALUES (
                    @id, @objectid, @objectguid, @name, @typename, @level, @opertypeid, @previd, @nextid, @updatedate, @startdate, @enddate, @isactual, @isactive
                );
                """
            );

            bcmd.Parameters.AddWithValue("@id", d.Id);
            bcmd.Parameters.AddWithValue("@objectid", d.ObjectId);
            bcmd.Parameters.AddWithValue("@objectguid", d.ObjectGUID);
            bcmd.Parameters.AddWithValue("@name", d.Name);
            bcmd.Parameters.AddWithValue("@typename", d.TypeName);
            bcmd.Parameters.AddWithValue("@level", d.Level);
            bcmd.Parameters.AddWithValue("@opertypeid", d.OperTypeID);
            bcmd.Parameters.AddWithValue("@previd", d.PrevId);
            bcmd.Parameters.AddWithValue("@nextid", d.NextId);
            bcmd.Parameters.AddWithValue("@updatedate", d.UpdateDate);
            bcmd.Parameters.AddWithValue("@startdate", d.StartDate);
            bcmd.Parameters.AddWithValue("@enddate", d.EndDate);
            bcmd.Parameters.AddWithValue("@isactive", d.IsActive);
            bcmd.Parameters.AddWithValue("@isactual", d.IsActual);

            batch.BatchCommands.Add(bcmd);
            CurBufferRecs += 1;
            if (CurBufferRecs >= bufferRecs)
            {
                RecordCount += batch.ExecuteNonQuery();
                Log.Information("{table} import: imported {recs}", this.objectsInfo.TargetTableFullName, RecordCount);
                CurBufferRecs = 0;
                batch.BatchCommands.Clear();
            }
        }
        if (CurBufferRecs > 0)
        {
            RecordCount += batch.ExecuteNonQuery();
            Log.Information("{table} import: imported {recs}", this.objectsInfo.TargetTableName, RecordCount);
            batch.BatchCommands.Clear();
        }
        return RecordCount;
    }
}