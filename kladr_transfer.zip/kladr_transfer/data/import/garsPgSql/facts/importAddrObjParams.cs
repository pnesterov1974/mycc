using System.Xml;
using Data;
using Data.Import.gar;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Import.gar.pgsql;
public class ImportAddrObjParams : BasePgSql
{
    protected ImportObjectsInfo objectsInfo { get; set; }
    public ImportAddrObjParams(ImportObjectsInfo objectsInfo) => this.objectsInfo = objectsInfo;

    public void DoImport(bool clearDestTableInAdvance = true)
    {
        if (clearDestTableInAdvance)
        {
            bool cl = this.ClearDestTable(this.objectsInfo.ConnectionString, this.objectsInfo.TargetTableFullName);
        }

        Log.Information("Начинаю импорт {table} ...", this.objectsInfo.TargetTableName);

        DateTime dtStart = DateTime.Now;
        int totalRecCount = this.ReadSourceData(this.objectsInfo.SourceFilePaths);
        DateTime dtFinish = DateTime.Now;

        TimeSpan duration = dtFinish - dtStart;
        Log.Information(
            "Импорт {table} закончен, всего загружено {records} записей... время обрадоьки: {duration}",
            this.objectsInfo.TargetTableName, totalRecCount, duration
            );
    }

    private int ReadSourceData(List<GarFileInfo> filePaths, int sourceBatchSize = 100000)
    {
        List<AddrObjParams> currentBatch = new List<AddrObjParams>(sourceBatchSize + 1);
        int currentBatchCount = 0;
        int recordCount = 0;
        Log.Information("Размер буфера на считывание {recbatchsize} ...", sourceBatchSize);
        foreach (var gfi in filePaths)
        {
            string filePath = gfi.FileFullPath;
            Log.Information("Обработка файла ...{file}", filePath);
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(filePath);
            XmlElement? xRoot = xDoc.DocumentElement;
            if (xRoot != null)
            {
                foreach (XmlElement xnode in xRoot)
                {
                    XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                    string id = idAttr.Value;

                    XmlNode ObjectIdAttr = xnode.Attributes.GetNamedItem("OBJECTID");
                    string objectId = ObjectIdAttr.Value;

                    XmlNode ChangeIdAttr = xnode.Attributes.GetNamedItem("CHANGEID");
                    string changeId = ChangeIdAttr.Value;

                    XmlNode ChangeIdendAttr = xnode.Attributes.GetNamedItem("CHANGEIDEND");
                    string changeIdend = ChangeIdendAttr.Value;

                    XmlNode TypeIdAttr = xnode.Attributes.GetNamedItem("TYPEID");
                    string typeId = TypeIdAttr.Value;

                    XmlNode ValueAttr = xnode.Attributes.GetNamedItem("VALUE");
                    string value = ValueAttr.Value;

                    XmlNode UpdateDateAttr = xnode.Attributes.GetNamedItem("UPDATEDATE");
                    string updateDate = UpdateDateAttr.Value;

                    XmlNode StartDateAttr = xnode.Attributes.GetNamedItem("STARTDATE");
                    string startDate = StartDateAttr.Value;

                    XmlNode EndDateAttr = xnode.Attributes.GetNamedItem("ENDDATE");
                    string endDate = EndDateAttr.Value;

                    currentBatchCount += 1;

                    currentBatch.Add(new AddrObjParams
                    {
                        Id = id,
                        ObjectId = objectId,
                        ChangeId = changeId,
                        ChangeIdend = changeIdend,
                        TypeId = typeId,
                        Value = value,
                        UpdateDate = updateDate,
                        StartDate = startDate,
                        EndDate = endDate
                    });
                }
            }
            else
            {
                Log.Information("Элементы не найдены");
            }
        }
        if (currentBatchCount > 0)
        {
            recordCount += this.WriteDataOneBatch(currentBatch);
        }
        Log.Information("Всего обработано {recordCount} записей", recordCount);
        return recordCount;
    }

    private int WriteDataOneBatch(List<AddrObjParams> data, int bufferRecs = 20000)
    {
        int RecordCount = 0;
        int CurBufferRecs = 0;
        Log.Information("Необходимо записать в таблицу {cnt} строк", data.Count);
        using var conn = new NpgsqlConnection(this.objectsInfo.ConnectionString);
        conn.Open();

        var batch = new NpgsqlBatch(conn);

        foreach (var d in data)
        {
            var bcmd = new NpgsqlBatchCommand($"""
                INSERT INTO {this.objectsInfo.TargetTableFullName} (
                    id, objectid, changeid, changeidend, typeid, value, startdate, updatedate, enddate 
                )
                VALUES (
                   @id, @objectid, @changeid, @changeidend, @typeid, @value, @startdate, @updatedate, @enddate
                );
                """
            );

            bcmd.Parameters.AddWithValue("@id", d.Id);
            bcmd.Parameters.AddWithValue("@objectid", d.ObjectId);
            bcmd.Parameters.AddWithValue("@changeid", d.ChangeId);
            bcmd.Parameters.AddWithValue("@changeidend", d.ChangeIdend);
            bcmd.Parameters.AddWithValue("@typeid", d.TypeId);
            bcmd.Parameters.AddWithValue("@value", d.Value);
            bcmd.Parameters.AddWithValue("@startdate", d.StartDate);
            bcmd.Parameters.AddWithValue("@updatedate", d.UpdateDate);
            bcmd.Parameters.AddWithValue("@enddate", d.EndDate);

            batch.BatchCommands.Add(bcmd);
            CurBufferRecs += 1;
            if (CurBufferRecs >= bufferRecs)
            {
                RecordCount += batch.ExecuteNonQuery();
                Log.Information("{table} import: imported {recs}", this.objectsInfo.TargetTableFullName, RecordCount);
                CurBufferRecs = 0;
                batch.BatchCommands.Clear();
            }
        }
        if (CurBufferRecs > 0)
        {
            RecordCount += batch.ExecuteNonQuery();
            Log.Information("{table} import: imported {recs}", this.objectsInfo.TargetTableName, RecordCount);
            batch.BatchCommands.Clear();
        }
        return RecordCount;
    }
}