using System.Xml;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Data.Import.gar.pgsql;
public class ImportAdmHierarchy : BasePgSql
{
    protected ImportObjectsInfo objectsInfo { get; set; }
    public ImportAdmHierarchy(ImportObjectsInfo objectsInfo) => this.objectsInfo = objectsInfo;

    public void DoImport(bool clearDestTableInAdvance = true)
    {
        if (clearDestTableInAdvance)
        {
            bool cl = this.ClearDestTable(this.objectsInfo.ConnectionString, this.objectsInfo.TargetTableFullName);
        }

        Log.Information("Начинаю импорт {table} ...", this.objectsInfo.TargetTableName);

        DateTime dtStart = DateTime.Now;
        int totalRecCount = this.ReadSourceData(this.objectsInfo.SourceFilePaths);
        DateTime dtFinish = DateTime.Now;

        TimeSpan duration = dtFinish - dtStart;
        Log.Information(
            "Импорт {table} закончен, всего загружено {records} записей... время обрадоьки: {duration}", 
            this.objectsInfo.TargetTableName, totalRecCount, duration
            );
    }

    private int ReadSourceData(List<GarFileInfo> filePaths, int sourceBatchSize = 100000)
    {
        List<AdmHierarchy> currentBatch = new List<AdmHierarchy>(sourceBatchSize + 1);
        int currentBatchCount = 0;
        int recordCount = 0;
        Log.Information("Размер буфера на считывание {recbatchsize} ...", sourceBatchSize);
        foreach (var gfi in filePaths)
        {
            string filePath = gfi.FileFullPath;
            Log.Information("Обработка файла ...{file}", filePath);
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(filePath);
            XmlElement? xRoot = xDoc.DocumentElement;
            if (xRoot != null)
            {
                foreach (XmlElement xnode in xRoot)
                {
                    XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                    string id = idAttr.Value;

                    XmlNode ObjectIdAttr = xnode.Attributes.GetNamedItem("OBJECTID");
                    string objectId = ObjectIdAttr.Value;

                    XmlNode ParentObjIdAttr = xnode.Attributes.GetNamedItem("PARENTOBJID");
                    string parentObjId = ParentObjIdAttr.Value;

                    XmlNode ChangeIdAttr = xnode.Attributes.GetNamedItem("CHANGEID");
                    string changeId = ChangeIdAttr.Value;

                    XmlNode RegionCodeAttr = xnode.Attributes.GetNamedItem("REGIONCODE");
                    string RegionCode = RegionCodeAttr.Value;

                    XmlNode PrevIDAttr = xnode.Attributes.GetNamedItem("PREVID");
                    string prevId = PrevIDAttr.Value;

                    XmlNode NextIDAttr = xnode.Attributes.GetNamedItem("NEXTID");
                    string nextId = NextIDAttr.Value;

                    XmlNode UpdateDateAttr = xnode.Attributes.GetNamedItem("UPDATEDATE");
                    string updateDate = UpdateDateAttr.Value;

                    XmlNode StartDateAttr = xnode.Attributes.GetNamedItem("STARTDATE");
                    string startDate = StartDateAttr.Value;

                    XmlNode EndDateAttr = xnode.Attributes.GetNamedItem("ENDDATE");
                    string endDate = EndDateAttr.Value;

                    XmlNode IsActiveAttr = xnode.Attributes.GetNamedItem("ISACTIVE");
                    string isActive = IsActiveAttr.Value;

                    XmlNode PathAttr = xnode.Attributes.GetNamedItem("PATH");
                    string path = PathAttr.Value;

                    currentBatchCount += 1;

                    currentBatch.Add(new AdmHierarchy
                        {
                            Id = id,
                            ObjectId = objectId,
                            ParentObjId = parentObjId,
                            ChangeId = changeId,
                            RegionCode = RegionCode,
                            PrevId = prevId,
                            NextId = nextId,
                            UpdateDate = updateDate,
                            StartDate = startDate,
                            EndDate = endDate,
                            IsActive = isActive,
                            Path = path
                        }
                    );
                    if (currentBatchCount >= sourceBatchSize)
                    {
                        Log.Information("Считано из источника {currentBatch} (текущая пачка) -> загрузка в БД", currentBatchCount);
                        recordCount += this.WriteDataOneBatch(currentBatch);
                        Log.Information("Всего обработано {recordCount} записей", recordCount);
                        currentBatchCount = 0;
                        currentBatch = new List<AdmHierarchy>(sourceBatchSize + 1);
                    }
                }
            }
            else
            {
                Log.Information("Элементы для файла {filepath} не найдены", filePath);
            }
        }
        if (currentBatchCount > 0)
        {
            recordCount += this.WriteDataOneBatch(currentBatch);
        }
        Log.Information("Всего обработано {recordCount} записей", recordCount);
        return recordCount;
    }

    private int WriteDataOneBatch(List<AdmHierarchy> data, int targetBatchSize = 20000)
    {
        int recordCount = 0;
        int curBufferRecs = 0;
        using var conn = new NpgsqlConnection(this.objectsInfo.ConnectionString);
        conn.Open();

        var batch = new NpgsqlBatch(conn);

        foreach (var d in data)
        {
            var bcmd = new NpgsqlBatchCommand($"""
                INSERT INTO {this.objectsInfo.TargetTableFullName} (
                    id, objectid, parentobjid, changeid, regioncode, previd, nextid, updatedate, startdate, enddate, isactive, path
                )
                VALUES (
                    @id, @objectid, @parentobjid, @changeid, @regioncode, @previd, @nextid, @updatedate, @startdate, @enddate, @isactive, @path
                );
                """
            );

            bcmd.Parameters.AddWithValue("@id", d.Id);
            bcmd.Parameters.AddWithValue("@objectid", d.ObjectId);
            bcmd.Parameters.AddWithValue("@parentobjid", d.ParentObjId);
            bcmd.Parameters.AddWithValue("@changeid", d.ChangeId);
            bcmd.Parameters.AddWithValue("@regioncode", d.RegionCode);
            bcmd.Parameters.AddWithValue("@previd", d.PrevId);
            bcmd.Parameters.AddWithValue("@nextid", d.NextId);
            bcmd.Parameters.AddWithValue("@updatedate", d.UpdateDate);
            bcmd.Parameters.AddWithValue("@startdate", d.StartDate);
            bcmd.Parameters.AddWithValue("@enddate", d.EndDate);
            bcmd.Parameters.AddWithValue("@isactive", d.IsActive);
            bcmd.Parameters.AddWithValue("@path", d.Path);

            batch.BatchCommands.Add(bcmd);
            curBufferRecs += 1;
            if (curBufferRecs >= targetBatchSize)
            {
                recordCount += batch.ExecuteNonQuery();
                Log.Information("Записано в БД {recordCount} из {recordsInSourceBatch}", recordCount, data.Count);
                curBufferRecs = 0;
                batch.BatchCommands.Clear();
            }
        }
        if (curBufferRecs > 0)
        {
            recordCount += batch.ExecuteNonQuery();
            Log.Information("Записано в БД {recordCount} из {recordsInSourceBatch}", recordCount, data.Count);
            batch.BatchCommands.Clear();
        }
        return recordCount;
    }
}