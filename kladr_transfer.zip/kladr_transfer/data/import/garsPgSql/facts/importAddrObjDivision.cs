using System.Xml;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Data.Import.gar.pgsql;
public class ImportAddrObjDivision : BasePgSql
{
    protected ImportObjectsInfo objectsInfo { get; set; }
    public ImportAddrObjDivision(ImportObjectsInfo objectsInfo) => this.objectsInfo = objectsInfo;

    private int ReadSourceData(List<GarFileInfo> filePaths, int sourceBatchSize = 100000)
    {
        List<AddrObjDivision> currentBatch = new List<AddrObjDivision>(sourceBatchSize + 1);
        int currentBatchCount = 0;
        int recordCount = 0;
        Log.Information("Размер буфера на считывание {recbatchsize} ...", sourceBatchSize);
        foreach (var gfi in filePaths)
        {
            string filePath = gfi.FileFullPath;
            Log.Information("Обработка файла ...{file}", filePath);
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(filePath);
            XmlElement? xRoot = xDoc.DocumentElement;
            if (xRoot != null)
            {
                foreach (XmlElement xnode in xRoot)
                {
                    XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                    string id = idAttr.Value;

                    XmlNode ParentIdAttr = xnode.Attributes.GetNamedItem("PARENTID");
                    string parentId = ParentIdAttr.Value;

                    XmlNode ChildIdAttr = xnode.Attributes.GetNamedItem("CHILDID");
                    string childId = ChildIdAttr.Value;

                    XmlNode ChangeIdAttr = xnode.Attributes.GetNamedItem("CHANGEID");
                    string changeId = ChangeIdAttr.Value;

                    currentBatchCount += 1;

                    currentBatch.Add(new AddrObjDivision
                    {
                        Id = id,
                        ParentId = parentId,
                        ChildId = childId,
                        ChangeId = changeId
                    });
                }
            }
            else
            {
                Log.Information("Элементы не найдены");
            }
        }
        if (currentBatchCount > 0)
        {
            recordCount += this.WriteDataOneBatch(currentBatch);
        }
        Log.Information("Всего обработано {recordCount} записей", recordCount);
        return recordCount;
    }

    public void DoImport(bool clearDestTableInAdvance = true)
    {
        if (clearDestTableInAdvance)
        {
            bool cl = this.ClearDestTable(this.objectsInfo.ConnectionString, this.objectsInfo.TargetTableFullName);
        }

        Log.Information("Начинаю импорт {table} ...", this.objectsInfo.TargetTableName);

        DateTime dtStart = DateTime.Now;
        int totalRecCount = this.ReadSourceData(this.objectsInfo.SourceFilePaths);
        DateTime dtFinish = DateTime.Now;

        TimeSpan duration = dtFinish - dtStart;
        Log.Information(
            "Импорт {table} закончен, всего загружено {records} записей... время обрадоьки: {duration}",
            this.objectsInfo.TargetTableName, totalRecCount, duration
            );
    }

    private int WriteDataOneBatch(List<AddrObjDivision> data, int bufferRecs = 20000)
    {
        int RecordCount = 0;
        int CurBufferRecs = 0;
        Log.Information("Необходимо записать в таблицу {cnt} строк", data.Count);
        using var conn = new NpgsqlConnection(this.objectsInfo.ConnectionString);
        conn.Open();

        var batch = new NpgsqlBatch(conn);
        foreach (var d in data)
        {
            var bcmd = new NpgsqlBatchCommand($"""
                INSERT INTO {this.objectsInfo.TargetTableFullName} (
                    id, parentid, childid, changeid
                )
                VALUES (
                   @id, @parentid, @childid, @changeid
                );
                """
            );

            bcmd.Parameters.AddWithValue("@id", d.Id);
            bcmd.Parameters.AddWithValue("@parentid", d.ParentId);
            bcmd.Parameters.AddWithValue("@childid", d.ChildId);
            bcmd.Parameters.AddWithValue("@changeid", d.ChangeId);

            batch.BatchCommands.Add(bcmd);
            CurBufferRecs += 1;
            if (CurBufferRecs >= bufferRecs)
            {
                RecordCount += batch.ExecuteNonQuery();
                Log.Information("{table} import: imported {recs}", this.objectsInfo.TargetTableFullName, RecordCount);
                CurBufferRecs = 0;
                batch.BatchCommands.Clear();
            }
        }
        if (CurBufferRecs > 0)
        {
            RecordCount += batch.ExecuteNonQuery();
            Log.Information("{table} import: imported {recs}", this.objectsInfo.TargetTableName, RecordCount);
            batch.BatchCommands.Clear();
        }
        return RecordCount;
    }
}