using System.Xml;
using CommonImport;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace GarImport;
public class ImportNormativeDocsKinds : ImportBasePgSql
{
    public ImportNormativeDocsKinds(ObjectInfo oi) : base(oi) { }

    private List<NormativeDocsKinds> GetSourceData()
    {
        List<NormativeDocsKinds> res = new List<NormativeDocsKinds>();
        Log.Information("Импорт из файла ...{file}", this.objectInfo.SourceFileName);
        XmlDocument xDoc = new XmlDocument();
        xDoc.Load(this.objectInfo.SourceFilePath);
        XmlElement? xRoot = xDoc.DocumentElement;
        if (xRoot != null)
        {
            Log.Information("Найдены элементы");
            foreach (XmlElement xnode in xRoot)
            {
                XmlNode idAttr = xnode.Attributes.GetNamedItem("ID");
                int id = int.Parse(idAttr.Value);
                XmlNode NameAttr = xnode.Attributes.GetNamedItem("NAME");
                string name = NameAttr.Value;
                res.Add(new NormativeDocsKinds
                    {
                        Id = id,
                        Name = name
                    }
                );
                Log.Information("ID: {id} ==== NAME: {name}", id, name);
            }
        }
        {
            Log.Information("Элементы не найдены");
        }
        return res;
    }

    public void DoImport(bool clearDestinationTableInAdvance = true)
    {
        Log.Information("Импорт из файла {file}", this.objectInfo.SourceFilePath);

        if (File.Exists(this.objectInfo.SourceFilePath))
        {
            Log.Information("Файл {file} существует...", this.objectInfo.SourceFileName);
            if (clearDestinationTableInAdvance && this.clearDestTable())
            {
                var data = this.GetSourceData();

                using var conn = new NpgsqlConnection(this.objectInfo.ConnectionString);
                conn.Open();

                var batch = new NpgsqlBatch(conn);

                foreach (var d in data)
                {
                    var bcmd = new NpgsqlBatchCommand($"INSERT INTO {this.objectInfo.DestinationTableFullName}(id, name) VALUES (@id, @name);");
                    bcmd.Parameters.AddWithValue("@id", d.Id);
                    bcmd.Parameters.AddWithValue("@name", d.Name);
                    batch.BatchCommands.Add(bcmd);
                }

                int recs = batch.ExecuteNonQuery();
                Log.Information("Загружено записей {recs} из {file}", recs, this.objectInfo.SourceFileName);
            }
        }
        else
        {
            Log.Information("Файл {file} не найден", this.objectInfo.SourceFilePath);
        }
    }
}
