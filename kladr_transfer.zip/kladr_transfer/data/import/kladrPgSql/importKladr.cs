using System.Data;
using DbfDataReader;
using Npgsql;
using NpgsqlTypes;
using Shared;
using static Shared.MyLogger;

namespace Data.Import.kladr.pgsql;

public class PgImportKladr: BasePgSql
{
    protected ImportObjectInfo ObjectInfo { get; set; }
    public PgImportKladr(ImportObjectInfo objectInfo) => this.ObjectInfo = objectInfo;

    public void DoImport(bool clearDestTableInAdvance = true, int BufferRecs = 100000)
    {
        int bufferRecs;
        if (this.ObjectInfo.BufferRecs > 0)
        {
            bufferRecs = this.ObjectInfo.BufferRecs;
        }
        else
        {
            bufferRecs = BufferRecs;
        }

        if (!clearDestTableInAdvance || 
                (clearDestTableInAdvance && 
                    this.ClearDestTable(
                        this.ObjectInfo.ConnectionString,
                        this.ObjectInfo.TargetTableFullName
                    )
                )
           )
        {
            Log.Information("Начинаю импорт данных в {table}", this.ObjectInfo.TargetTableName);
            DbfDataReaderOptions dbfOptions = new DbfDataReaderOptions { SkipDeletedRecords = true };
            using (var dbfDataReader = new DbfDataReader.DbfDataReader(this.ObjectInfo.SourceFilePath, dbfOptions))
            {
                int RecordCount = 0;
                int CurBufferRecs = 0;
                using var conn = new NpgsqlConnection(this.ObjectInfo.ConnectionString);
                conn.Open();

                var batch = new NpgsqlBatch(conn);
                DateTime dtStart = DateTime.Now;

                while (dbfDataReader.Read())
                {
                    var name = dbfDataReader.GetString(0);
                    var socr = dbfDataReader.GetString(1);
                    var code = dbfDataReader.GetString(2);
                    var index = dbfDataReader.GetString(3);
                    var gninmb = dbfDataReader.GetString(4);
                    var uno = dbfDataReader.GetString(5);
                    var ocatd = dbfDataReader.GetString(6);
                    var status = dbfDataReader.GetString(7);

                    var bcmd = new NpgsqlBatchCommand(
                        $"INSERT INTO {this.ObjectInfo.TargetTableFullName}(name, socr, code, index, gninmb, uno, ocatd, status) VALUES (@name, @socr, @code, @index, @gninmb, @uno, @ocatd, @status);"
                        );

                    NpgsqlParameter pName = new NpgsqlParameter
                    {
                        ParameterName = "@name",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = name,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pSocr = new NpgsqlParameter
                    {
                        ParameterName = "@socr",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = socr,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pCode = new NpgsqlParameter
                    {
                        ParameterName = "@code",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = code,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pIndex = new NpgsqlParameter
                    {
                        ParameterName = "@index",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = index,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pGninmb = new NpgsqlParameter
                    {
                        ParameterName = "@gninmb",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = gninmb,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pUno = new NpgsqlParameter
                    {
                        ParameterName = "@uno",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = uno,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pOcatd = new NpgsqlParameter
                    {
                        ParameterName = "@ocatd",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = ocatd,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pStatus = new NpgsqlParameter
                    {
                        ParameterName = "@status",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = status,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    bcmd.Parameters.Add(pName);
                    bcmd.Parameters.Add(pSocr);
                    bcmd.Parameters.Add(pCode);
                    bcmd.Parameters.Add(pIndex);
                    bcmd.Parameters.Add(pGninmb);
                    bcmd.Parameters.Add(pUno);
                    bcmd.Parameters.Add(pOcatd);
                    bcmd.Parameters.Add(pStatus);

                    batch.BatchCommands.Add(bcmd);
                    CurBufferRecs += 1;
                    if (CurBufferRecs >= bufferRecs)
                    {
                        RecordCount += batch.ExecuteNonQuery();
                        Log.Information("{table} загружено {recs} записей", this.ObjectInfo.TargetTableName, RecordCount);
                        CurBufferRecs = 0;
                        batch.BatchCommands.Clear();
                    }
                }
                if (CurBufferRecs > 0)
                {
                    RecordCount += batch.ExecuteNonQuery();
                    Log.Information("{table} загружено {recs} записей", this.ObjectInfo.TargetTableName, RecordCount);
                    batch.BatchCommands.Clear();
                }
                DateTime dtFinish = DateTime.Now;
                TimeSpan duration = dtFinish - dtStart;
                Log.Information("{table} Всего загружено: {recs} записей за {duration}", this.ObjectInfo.TargetTableName, RecordCount, duration);
            }
        }
    }
}
