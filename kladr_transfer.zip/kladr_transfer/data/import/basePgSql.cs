using Npgsql;
//using Serilog;
using Shared;

namespace CommonImport;

public class ImportBasePgSql
{
    public ImportBasePgSql(ObjectInfo oi)
    {
        this.objectInfo = oi;
    }

    //public ILogger Log { get; set; }
    protected ObjectInfo objectInfo { get; set; }
    protected string truncateTableSql
    {
        get => $"TRUNCATE TABLE {this.objectInfo.DestinationTableFullName};";
    }

    protected bool clearDestTable()
    {
        var dataSourceBuilder = new NpgsqlDataSourceBuilder(this.objectInfo.ConnectionString);
        var dataSource = dataSourceBuilder.Build();

        try
        {
            using NpgsqlConnection conn = dataSource.OpenConnection();
            NpgsqlCommand cmd = new NpgsqlCommand(this.truncateTableSql, conn);
            MyLogger.Log.Information("Очистка таблицы {table}", this.objectInfo.DestinationTableFullName);
            MyLogger.Log.Debug("SQL:{sql}\n", this.truncateTableSql);
            cmd.ExecuteNonQuery();
            MyLogger.Log.Information("Таблица {table} очищена...", this.objectInfo.DestinationTableFullName);
            return true;
        }
        catch (Exception ex)
        {
            MyLogger.Log.Error("Ошибка при очистке таблицы: \n {ErrMessage}", ex.Message);
            return false;
        }
    }
}