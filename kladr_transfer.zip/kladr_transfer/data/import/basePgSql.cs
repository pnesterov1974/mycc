using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace CommonImport;

public class ImportBasePgSql
{
    public ImportBasePgSql(ObjectInfo oi)
    {
        this.objectInfo = oi;
    }

    protected ObjectInfo objectInfo { get; set; }

    protected bool clearDestTable()
    {
        var dataSourceBuilder = new NpgsqlDataSourceBuilder(this.objectInfo.ConnectionString);
        var dataSource = dataSourceBuilder.Build();
        string truncateTableSql = $"TRUNCATE TABLE {this.objectInfo.DestinationTableFullName};";
        try
        {
            using NpgsqlConnection conn = dataSource.OpenConnection();
            NpgsqlCommand cmd = new NpgsqlCommand(truncateTableSql, conn);
            Log.Information("Очистка таблицы {table}", this.objectInfo.DestinationTableFullName);
            Log.Debug("SQL:{sql}", cmd.CommandText);
            cmd.ExecuteNonQuery();
            Log.Information("Таблица {table} очищена...", this.objectInfo.DestinationTableFullName);
            return true;
        }
        catch (Exception ex)
        {
            Log.Error("Ошибка при очистке таблицы: \n {ErrMessage}", ex.Message);
            return false;
        }
    }
}