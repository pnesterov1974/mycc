using static Shared.MyLogger;

namespace Shared.GarImportModels.garfiles;

public class GarFiles
{
    public Dictionary<string, GarFile?> GarMasters = new Dictionary<string, GarFile?>()
    {
        {"AS_ADDHOUSE_TYPES", null},
        {"AS_ADDR_OBJ_TYPES", null},
        {"AS_APARTMENT_TYPES", null},
        {"AS_HOUSE_TYPES", null},
        {"AS_NORMATIVE_DOCS_KINDS", null},
        {"AS_NORMATIVE_DOCS_TYPES", null},
        {"AS_OBJECT_LEVELS", null},
        {"AS_OPERATION_TYPES", null},
        {"AS_PARAM_TYPES", null},
        {"AS_ROOM_TYPES", null}
    };

    public Dictionary<string, List<GarFile>?> GarFacts = new Dictionary<string, List<GarFile>?>()
    {
        {"AS_ADDR_OBJ", null},
        {"AS_ADDR_OBJ_DIVISION", null},
        {"AS_ADDR_OBJ_PARAMS", null},
        {"AS_ADM_HIERARCHY", null},
        {"AS_APARTMENTS", null},
        {"AS_APARTMENTS_PARAMS", null},
        {"AS_CARPLACES", null},
        {"AS_CARPLACES_PARAMS", null},
        {"AS_CHANGE_HISTORY", null},
        {"AS_HOUSES", null},
        {"AS_HOUSES_PARAMS", null},
        {"AS_MUN_HIERARCHY", null},
        {"AS_NORMATIVE_DOCS", null},
        {"AS_REESTR_OBJECTS", null},
        {"AS_ROOMS", null},
        {"AS_ROOMS_PARAMS", null},
        {"AS_STEADS", null},
        {"AS_STEADS_PARAMS", null}
    };

    public string GarPath { get; set; } = string.Empty;

    public GarFiles(string garPath)
    {
        if (Path.Exists(garPath))
        {
            this.GarPath = garPath;
            this.fillGarMastersWithFiles();
            this.fillGarFactsWithFiles();
        }
        else
        {
            Log.Information("Путь {garPath} не существует", garPath);
            //throw
        }
    }

    private void fillGarMastersWithFiles()
    {
        Log.Information("Поиск справочников...", this.GarPath);
        foreach (var item in this.GarMasters)
        {
            string fileMask = string.Concat(item.Key, "*.XML");
            string[] fileEntries = Directory.GetFiles(this.GarPath, fileMask, SearchOption.AllDirectories);
            Log.Information("Маска файла: {filemask} найдено {cnt} файлов", fileMask, fileEntries.Length);
            if (fileEntries.Length > 0)
            {
                var gf = new GarFile { FileFullPath = fileEntries[0] };
                gf.AnalizeGarFile();
                this.GarMasters[item.Key] = gf;
            }
        }
    }

    private void fillGarFactsWithFiles()
    {
        Log.Information("Поиск фактов...", this.GarFacts);
        foreach (var item in this.GarFacts)
        {
            string fileMask = string.Concat(item.Key, "_20*.XML");
            string[] fileEntries = Directory.GetFiles(this.GarPath, fileMask, SearchOption.AllDirectories);
            Log.Information("Маска файла: {filemask} найдено {cnt} файлов", fileMask, fileEntries.Length);
            if (fileEntries.Length > 0)
            {
                List<GarFile> gfl = new List<GarFile>();
                foreach (string file in fileEntries)
                {
                    GarFile gf = new GarFile { FileFullPath = file };
                    gf.AnalizeGarFile();
                    gfl.Add(gf);
                }
                gfl.Sort();
                this.GarFacts[item.Key] = gfl;
            }
        }
    }


    public void PrintMasters()
    {
        foreach (KeyValuePair<string, GarFile?> kvp in this.GarMasters)
        {
            Log.Information("{Key} : {Value}", kvp.Key, kvp.Value);
        }
    }

    public void PrintFacts()
    {
        foreach (KeyValuePair<string, List<GarFile>?> kvp in this.GarFacts)
        {
            Log.Information("{Key} : {Value}", kvp.Key, kvp.Value?.Count);
        }
    }
}
