namespace Shared.importModels;

//string kladrSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "my_dev", "files", "kladr");
//string kladrSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "dotNetProjects", "files", "kladr");                                                           

public interface IGarImportModel
{
    public string SourceFileName { get; set; } // имя файла
    public string SourceDirFullPath { get; }   // полное имя папки источника {1-я и 2-я части}
    public string SourceFullPathName { get; }  // полный путь + имя файла 
    public string DtFileFullPath { get; }      // fullPath для dt-файла
    public DateOnly Dt { get; }
    public int BufferRecs { get; set; }
}

public class GarImportModelBase
{
    //public string SourceDirPath { get; set; } = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "dotNetProjects", "files", "kladr");
    public virtual string SourceFileName { get; set; } = string.Empty;
    public string SourceFolderName { get; set; } = "29_11";
    public string SourceDirFullPath
    {
        get => Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "my_dev", "files", "kladr", this.SourceFolderName);
    }

    public string DtFileFullPath
    {
        get
        {
            string[] files = Directory.GetFiles(this.SourceDirFullPath, "*.dt", SearchOption.TopDirectoryOnly)
                .Select(file => Path.GetFileNameWithoutExtension(file)).ToArray();
            // TODO: Warning if files.count != 1;
            return files[0];
        }
    }

    public DateOnly Dt
    {
        get
        {
            DateOnly dt;
            if (DateOnly.TryParse(this.DtFileFullPath, out dt))
            {
                return dt;
            }
            else
            {
                return DateOnly.MinValue;
            }
        }
    }

    public string SourceFullPathName
    {
        get => Path.Combine(SourceDirFullPath, this.SourceFileName);
    }
}

public class AddHouseTypesGarImportModel : ImportModelBase, IImportModel
{
    public override string SourceFileName { get; set; } = "SOCRBASE.DBF";
    public int BufferRecs { get; set; } = 10_000;
}


public class AddObjDivisionGarImportModel : ImportModelBase, IImportModel
{
    public override string SourceFileName { get; set; } = "ALTNAMES.DBF";
    public int BufferRecs { get; set; } = 100_000;
}