namespace Shared.KladrImportModels;

public interface IImportModel
{
    public string SourceFileName { get; set; } // имя файла
    public string SourceDirFullPath { get; }   // полное имя папки источника {1-я и 2-я части}
    public string SourceFullPathName { get; }  // полный путь + имя файла 
    public string DtFileFullPath { get; }      // fullPath для dt-файла
    public DateOnly Dt { get; }
    public int BufferRecs { get; set; }
}

public class ImportModelBase
{
    public virtual string SourceFileName { get; set; } = string.Empty;
    public string SourceFolderName { get; set; } = "27_12";
    public string SourceDirFullPath
    {
        //get => Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "dotNetProjects", "files", "kladr");
        get => Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "my_dev", "files", "kladr", this.SourceFolderName);
    }

    public string DtFileFullPath
    {
        get
        {
            string[] files = Directory.GetFiles(this.SourceDirFullPath, "*.dt", SearchOption.TopDirectoryOnly)
                .Select(file => Path.GetFileNameWithoutExtension(file)).ToArray();
            // TODO: Warning if files.count != 1;
            return files[0];
        }
    }

    public DateOnly Dt
    {
        get
        {
            DateOnly dt;
            if (DateOnly.TryParse(this.DtFileFullPath, out dt))
            {
                return dt;
            }
            else
            {
                return DateOnly.MinValue;
            }
        }
    }

    public string SourceFullPathName => Path.Combine(SourceDirFullPath, this.SourceFileName);
}