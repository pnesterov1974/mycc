namespace Shared.importModels;

//string kladrSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "my_dev", "files", "kladr");
//string kladrSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "dotNetProjects", "files", "kladr");                                                           

public interface IImportModel
{
    public string SourceFileName { get; set; }
    public string SourceDirFullPath { get; }
    public string SourceFullName { get; }
    public string DtFileFullPath { get; }
    public DateOnly Dt { get; }
    public int BufferRecs { get; set; }
}

public class ImportModelBase
{
    //public string SourceDirPath { get; set; } = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "dotNetProjects", "files", "kladr");
    public virtual string SourceFileName { get; set; } = string.Empty;
    public string SourceFolderName { get; set; } = "29_11";
    public string SourceDirFullPath
    {
        get
        {
            return Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "my_dev", "files", "kladr", this.SourceFolderName);
        }
    }

    public string DtFileFullPath
    {
        get
        {
            string[] files = Directory.GetFiles(this.SourceDirFullPath, "*.dt", SearchOption.TopDirectoryOnly)
                .Select(file => Path.GetFileNameWithoutExtension(file)).ToArray();
            // TODO: Warning if files.count != 1;
            return files[0];
        }
    }

    public DateOnly Dt
    {
        get
        {
            DateOnly dt;
            if (DateOnly.TryParse(this.DtFileFullPath, out dt))
            {
                return dt;
            }
            else
            {
                return DateOnly.MinValue;
            }
        }
    }

    public string SourceFullName
    {
        get
        {
            return Path.Combine(SourceDirFullPath, this.SourceFileName);
        }
    }
}

public class SocrBaseImportModel : ImportModelBase, IImportModel
{
    public override string SourceFileName { get; set; } = "SOCRBASE.DBF";
    public int BufferRecs { get; set; } = 10_000;
}


public class AltNamesImportModel : ImportModelBase, IImportModel
{
    public override string SourceFileName { get; set; } = "ALTNAMES.DBF";
    public int BufferRecs { get; set; } = 100_000;
}

public class KladrImportModel : ImportModelBase, IImportModel
{
    public override string SourceFileName { get; set; } = "KLADR.DBF";
    public int BufferRecs { get; set; } = 200_000;
}

public class StreetImportModel : ImportModelBase, IImportModel
{
    public override string SourceFileName { get; set; } = "STREET.DBF";
    public int BufferRecs { get; set; } = 200_000;
}

public class DomaImportModel : ImportModelBase, IImportModel
{
    public override string SourceFileName { get; set; } = "DOMA.DBF";
    public int BufferRecs { get; set; } = 1_000_000;
}