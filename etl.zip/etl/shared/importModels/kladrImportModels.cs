namespace Shared.KladrImportModels;

//string kladrSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "my_dev", "files", "kladr");
//string kladrSourceDirPath = Path.Join(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "dotNetProjects", "files", "kladr");                                                           

public class SocrBaseImportModel : ImportModelBase, IImportModel
{
    public override string SourceFileName { get; set; } = "SOCRBASE.DBF";
    public int BufferRecs { get; set; } = 10_000;
}


public class AltNamesImportModel : ImportModelBase, IImportModel
{
    public override string SourceFileName { get; set; } = "ALTNAMES.DBF";
    public int BufferRecs { get; set; } = 100_000;
}

public class KladrImportModel : ImportModelBase, IImportModel
{
    public override string SourceFileName { get; set; } = "KLADR.DBF";
    public int BufferRecs { get; set; } = 200_000;
}

public class StreetImportModel : ImportModelBase, IImportModel
{
    public override string SourceFileName { get; set; } = "STREET.DBF";
    public int BufferRecs { get; set; } = 200_000;
}

public class DomaImportModel : ImportModelBase, IImportModel
{
    public override string SourceFileName { get; set; } = "DOMA.DBF";
    public int BufferRecs { get; set; } = 1_000_000;
}