namespace Shared;

public enum TargetDb
{
    mssql,
    pgsql
}
