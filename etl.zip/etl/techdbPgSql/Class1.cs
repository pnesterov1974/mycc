﻿namespace techdbPgSql;

public class Class1
{

}
