using Microsoft.EntityFrameworkCore;
using Shared;
using static Shared.MyLogger;
using ImportGeoEfc.SourceEnumerators.gar.masters;

namespace ImportGeoEfc.Workers.gar.masters;

public class HouseTypesImportWorker
{
    public TargetDb tdb;

    public void DoImport(bool clearTargetTableInAdvance = true)
    {
        DateTime startDt = DateTime.Now;
        Log.Information("Начало импорта HOUSE_TYPES: {sdt}", startDt);
        using (GarContext ctx = new GarContext(this.tdb))
        {
            var tableFullName = ctx.HouseTypes.GetTableFullName();
            Log.Information("Имя целевлй таблицы: {tableName}", tableFullName);
            bool isAvailaible = ctx.Database.CanConnect();
            if (isAvailaible)
            {
                if (clearTargetTableInAdvance)
                {
                    Log.Information("Предварительная очистка целевой таблицы {tableName}", tableFullName);
                    ctx.Database.ExecuteSqlRaw($"TRUNCATE TABLE {tableFullName};");
                    Log.Information("Предварительная очистка успешна...");
                }

                var houseTypes = new HouseTypesEnumerator();
                int batchRecordCount = 10_000;
                int currentBatchRecs = 0;
                int totalRecs = 0;
                var iter = houseTypes.IterHouseTypes();
                foreach (var houseTypesRec in iter)
                {
                    currentBatchRecs += 1;
                    ctx.HouseTypes.Add(houseTypesRec);
                    if (currentBatchRecs - batchRecordCount == 0)
                    {
                        ctx.SaveChanges();
                        totalRecs += currentBatchRecs;
                        currentBatchRecs = 0;
                        Log.Information("Импортировано {currentRec}", totalRecs);
                    }
                }
                if (currentBatchRecs > 0)
                {
                    ctx.SaveChanges();
                    totalRecs += currentBatchRecs;
                    currentBatchRecs = 0;
                }
                Log.Information("Всего Импортировано {recs} записей", totalRecs);
            }
            else
            {
                Log.Information("Подключение не возможно");
            }
        }
        DateTime finishDt = DateTime.Now;
        Log.Information("Завершение импорта HOUSE_TYPES: {sdt}", finishDt);
        TimeSpan tsp = finishDt - startDt;
        Log.Information("Длительность импорта HOUSE_TYPES: {tsp}", tsp);
    }
}