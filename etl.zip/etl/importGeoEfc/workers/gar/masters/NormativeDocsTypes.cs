using Microsoft.EntityFrameworkCore;
using Shared;
using static Shared.MyLogger;
using ImportGeoEfc.SourceEnumerators.gar.masters;

namespace ImportGeoEfc.Workers.gar.masters;

public class NormativeDocsTypesImportWorker
{
    public TargetDb tdb;

    public void DoImport(bool clearTargetTableInAdvance = true)
    {
        DateTime startDt = DateTime.Now;
        Log.Information("Начало импорта NORMATIVE_DOCS_TYPES: {sdt}", startDt);
        using (GarContext ctx = new GarContext(this.tdb))
        {
            var tableFullName = ctx.NormativeDocsTypes.GetTableFullName();
            Log.Information("Имя целевлй таблицы: {tableName}", tableFullName);
            bool isAvailaible = ctx.Database.CanConnect();
            if (isAvailaible)
            {
                if (clearTargetTableInAdvance)
                {
                    Log.Information("Предварительная очистка целевой таблицы {tableName}", tableFullName);
                    ctx.Database.ExecuteSqlRaw($"TRUNCATE TABLE {tableFullName};");
                    Log.Information("Предварительная очистка успешна...");
                }

                var normativeDocTypes = new NormativeDocsTypesEnumerator();
                int batchRecordCount = 10_000;
                int currentBatchRecs = 0;
                int totalRecs = 0;
                var iter = normativeDocTypes.IterNormativeDocsTypes();
                foreach (var rec in iter)
                {
                    currentBatchRecs += 1;
                    ctx.NormativeDocsTypes.Add(rec);
                    if (currentBatchRecs - batchRecordCount == 0)
                    {
                        ctx.SaveChanges();
                        totalRecs += currentBatchRecs;
                        currentBatchRecs = 0;
                        Log.Information("Импортировано {currentRec}", totalRecs);
                    }
                }
                if (currentBatchRecs > 0)
                {
                    ctx.SaveChanges();
                    totalRecs += currentBatchRecs;
                    currentBatchRecs = 0;
                }
                Log.Information("Всего Импортировано {recs} записей", totalRecs);
            }
            else
            {
                Log.Information("Подключение не возможно");
            }
        }
        DateTime finishDt = DateTime.Now;
        Log.Information("Завершение импорта NORMATIVE_DOCS_TYPES: {sdt}", finishDt);
        TimeSpan tsp = finishDt - startDt;
        Log.Information("Длительность импорта NORMATIVE_DOCS_TYPES: {tsp}", tsp);
    }
}