using System.Xml.Linq;
using importGeoEfc.models.garmodels;
using Shared.garfiles;
using static Shared.MyLogger;

namespace importGeoEfc;

static class InitialGarSource  // Singleton !!!
{
    public static GarFiles GarFiles { get; set; }
    public static void InitGarSource()
    {
        //string basePath = @"C:\Users\PaNesterov\Documents\dotNetProjects\files\gar\";
        string basePath = @"/home/pnesterov/my_dev/files/gar/";
        InitialGarSource.GarFiles = new GarFiles(basePath);
    }

    public static string GetMasterFullFilePathByStringKey(string sourceStringKey)
    {
        return GarFiles.GarMasters[sourceStringKey].FileFullPath;
    }
}

class HouseTypesEnumerator
{
    public string SourceKey = "AS_HOUSE_TYPES";
    public string SourceFileFullPath = string.Empty;

    public HouseTypesEnumerator()
    {
        this.SourceFileFullPath = InitialGarSource.GetMasterFullFilePathByStringKey(this.SourceKey);
    }

    public IEnumerable<HouseType> GetEnumerator()
    {
        Log.Information("Импорт из файла {filePath}", this.SourceFileFullPath);
        XDocument xDoc = XDocument.Load(this.SourceFileFullPath);
        foreach (XElement el in xDoc.Root.Elements())
        {
            HouseType ht = new HouseType
            {
                Id = int.Parse(el.Attribute("ID").Value),
                Name = el.Attribute("NAME").Value,
                ShortName = el.Attribute("SHORTNAME").Value,
                Desc = el.Attribute("DESC").Value,
                UpdateDate = DateOnly.Parse(el.Attribute("UPDATEDATE").Value),
                StartDate = DateOnly.Parse(el.Attribute("STARTDATE").Value),
                EndDate = DateOnly.Parse(el.Attribute("ENDDATE").Value),
                IsActive = bool.Parse(el.Attribute("ISACTIVE").Value),
            };
            yield return ht;
        }
    }
}

class AddrObjTypeEnumerator
{
    public string SourceKey = "AS_ADDR_OBJ_TYPES";
    public string SourceFileFullPath = string.Empty;

    public AddrObjTypeEnumerator()
    {
        this.SourceFileFullPath = InitialGarSource.GetMasterFullFilePathByStringKey(this.SourceKey);
    }

    public IEnumerable<AddrObjType> GetEnumerator()
    {
        Log.Information("Импорт из файла {filePath}", this.SourceFileFullPath);
        XDocument xDoc = XDocument.Load(this.SourceFileFullPath);
        foreach (XElement el in xDoc.Root.Elements())
        {
            AddrObjType adt = new AddrObjType
            {
                Id = int.Parse(el.Attribute("ID").Value),
                Level = int.Parse(el.Attribute("LEVEL").Value),
                ShortName = el.Attribute("SHORTNAME").Value,
                Name = el.Attribute("NAME").Value,
                Desc = el.Attribute("DESC").Value,
                UpdateDate = DateOnly.Parse(el.Attribute("UPDATEDATE").Value),
                StartDate = DateOnly.Parse(el.Attribute("STARTDATE").Value),
                EndDate = DateOnly.Parse(el.Attribute("ENDDATE").Value),
                IsActive = bool.Parse(el.Attribute("ISACTIVE").Value),
            };
            yield return adt;
        }
    }
}

class AppartmentTypeEnumerator
{
    public string SourceKey = "AS_APARTMENT_TYPES";
    public string SourceFileFullPath = string.Empty;

    public AppartmentTypeEnumerator()
    {
        this.SourceFileFullPath = InitialGarSource.GetMasterFullFilePathByStringKey(this.SourceKey);
    }

    public IEnumerable<AppartmentType> GetEnumerator()
    {
        Log.Information("Импорт из файла {filePath}", this.SourceFileFullPath);
        XDocument xDoc = XDocument.Load(this.SourceFileFullPath);
        foreach (XElement el in xDoc.Root.Elements())
        {
            AppartmentType apt = new AppartmentType
            {
                Id = int.Parse(el.Attribute("ID").Value),
                Name = el.Attribute("NAME").Value,
                ShortName = el.Attribute("SHORTNAME").Value,
                Desc = el.Attribute("DESC").Value,
                UpdateDate = DateOnly.Parse(el.Attribute("UPDATEDATE").Value),
                StartDate = DateOnly.Parse(el.Attribute("STARTDATE").Value),
                EndDate = DateOnly.Parse(el.Attribute("ENDDATE").Value),
                IsActive = bool.Parse(el.Attribute("ISACTIVE").Value),
            };
            yield return apt;
        }
    }
}

class NormativeDocsKindEnumerator
{
    public string SourceKey = "AS_NORMATIVE_DOCS_KINDS";
    public string SourceFileFullPath = string.Empty;

    public NormativeDocsKindEnumerator()
    {
        this.SourceFileFullPath = InitialGarSource.GetMasterFullFilePathByStringKey(this.SourceKey);
    }

    public IEnumerable<NormativeDocsKind> GetEnumerator()
    {
        Log.Information("Импорт из файла {filePath}", this.SourceFileFullPath);
        XDocument xDoc = XDocument.Load(this.SourceFileFullPath);
        foreach (XElement el in xDoc.Root.Elements())
        {
            NormativeDocsKind ndk = new NormativeDocsKind
            {
                Id = int.Parse(el.Attribute("ID").Value),
                Name = el.Attribute("NAME").Value,
            };
            //Console.WriteLine($"Id:{ndk.Id}  Name:{ndk.Name}");
            yield return ndk;
        }
    }
}

class NormativeDocsTypeEnumerator
{
    public string SourceKey = "AS_NORMATIVE_DOCS_TYPES";
    public string SourceFileFullPath = string.Empty;

    public NormativeDocsTypeEnumerator()
    {
        this.SourceFileFullPath = InitialGarSource.GetMasterFullFilePathByStringKey(this.SourceKey);
    }

    public IEnumerable<NormativeDocsType> GetEnumerator()
    {
        Log.Information("Импорт из файла {filePath}", this.SourceFileFullPath);
        XDocument xDoc = XDocument.Load(this.SourceFileFullPath);
        foreach (XElement el in xDoc.Root.Elements())
        {
            yield return new NormativeDocsType 
            {
                Id = int.Parse(el.Attribute("ID").Value),
                Name = el.Attribute("NAME").Value,
                StartDate = DateOnly.Parse(el.Attribute("STARTDATE").Value),
                EndDate = DateOnly.Parse(el.Attribute("ENDDATE").Value),
            };
            // NormativeDocsType ndt = new NormativeDocsType
            // {
            //     Id = int.Parse(el.Attribute("ID").Value),
            //     Name = el.Attribute("NAME").Value,
            //     StartDate = DateOnly.Parse(el.Attribute("STARTDATE").Value),
            //     EndDate = DateOnly.Parse(el.Attribute("ENDDATE").Value),
            // };
            //Console.WriteLine($"Id:{ndt.Id}  Name:{ndt.Name}");
            //yield return ndt;
        }
    }
}