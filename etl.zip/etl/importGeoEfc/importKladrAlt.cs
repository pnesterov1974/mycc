using importGeoEfc.models;
using Microsoft.EntityFrameworkCore;
using Shared;
using static Shared.MyLogger;

namespace importGeoEfc;

// TODO
// try-except review
// touch mssql names
// objects names in logging from importModel
// date of data in txt file
// ctx.Database.ExecuteSqlRaw($"TRUNCATE TABLE {tableFullName};"); vs ExecuteSql ?? Intrusion ??

public class KladrEfcImportWorkerAlt
{
    public TargetDb tdb;

    public void SaveKladrUsingEnumerator2(bool clearTargetTableInAdvance = true)
    {
        DateTime startDt = DateTime.Now;
        Log.Information("Начало импорта KLADR: {sdt}", startDt);
        var kladrSource = new KladrSourceEnumerator();
        int batchRecordCount = kladrSource.ImportModel.BufferRecs;
        int currentBatchRecs = 0;
        int totalRecs = 0;
        List<Kladr> kl = new List<Kladr>();
        foreach (var kladrRec in kladrSource)
        {
            currentBatchRecs += 1;
            //ctx.Kladrs.Add(kladrRec);
            kl.Add(kladrRec);
            if (currentBatchRecs - batchRecordCount == 0)
            {
                //ctx.SaveChanges();
                using (KladrContext ctx = new KladrContext(this.tdb))
                {
                    ctx.Kladrs.AddRange(kl);
                    kl.Clear();
                    int cbr = ctx.SaveChanges();
                    totalRecs += cbr;
                    currentBatchRecs = 0;
                    Log.Information("Импортировано {currentRec}", totalRecs);
                }
            }
        }
        if (currentBatchRecs > 0)
        {
            using (KladrContext ctx = new KladrContext(this.tdb))
            {
                ctx.Kladrs.AddRange(kl);
                int cbr = ctx.SaveChanges();
                totalRecs += cbr;
                currentBatchRecs = 0;
                Log.Information("Импортировано {currentRec}", totalRecs);
            }
        }
        DateTime finishDt = DateTime.Now;
        Log.Information("Завершение импорта KLADR: {sdt}", finishDt);
        TimeSpan tsp = finishDt - startDt;
        Log.Information("Длительность импорта KLADR: {tsp}", tsp);
    }

    public void SaveKladrUsingEnumerator(bool clearTargetTableInAdvance = true)
    {
        DateTime startDt = DateTime.Now;
        Log.Information("Начало импорта KLADR: {sdt}", startDt);
        using (KladrContext ctx = new KladrContext(this.tdb))
        {
            //var tableFullName = Extensions.GetTableFullName(ctx.Kladrs);
            var tableFullName = ctx.Kladrs.GetTableFullName();
            Log.Information("Имя целевлй таблицы: {tableName}", tableFullName);
            bool isAvailaible = ctx.Database.CanConnect();
            if (isAvailaible)
            {
                if (clearTargetTableInAdvance)
                {
                    Log.Information("Предварительная очистка целевой таблицы {tableName}", tableFullName);
                    ctx.Database.ExecuteSqlRaw($"TRUNCATE TABLE {tableFullName};");
                    Log.Information("Предварительная очистка успешна...");
                }

                var kladrSource = new KladrSourceEnumerator();
                int batchRecordCount = kladrSource.ImportModel.BufferRecs;
                int currentBatchRecs = 0;
                int totalRecs = 0;
                foreach (var kladrRec in kladrSource)
                {
                    currentBatchRecs += 1;
                    ctx.Kladrs.Add(kladrRec);
                    if (currentBatchRecs - batchRecordCount == 0)
                    {
                        ctx.SaveChanges();
                        totalRecs += currentBatchRecs;
                        currentBatchRecs = 0;
                        Log.Information("Импортировано {currentRec}", totalRecs);
                    }
                }
                if (currentBatchRecs > 0)
                {
                    ctx.SaveChanges();
                    totalRecs += currentBatchRecs;
                    currentBatchRecs = 0;
                }
                Log.Information("Всего Импортировано {recs} записей", totalRecs);
            }
            else
            {
                Log.Information("Подключение не возможно");
            }
        }
        DateTime finishDt = DateTime.Now;
        Log.Information("Завершение импорта KLADR: {sdt}", finishDt);
        TimeSpan tsp = finishDt - startDt;
        Log.Information("Длительность импорта KLADR: {tsp}", tsp);
    }
}