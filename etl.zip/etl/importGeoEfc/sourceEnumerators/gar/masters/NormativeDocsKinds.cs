using System.Xml.Linq;
using ImportGeoEfc.models.garmodels;
using static Shared.MyLogger;

namespace ImportGeoEfc.SourceEnumerators.gar.masters;

public class NormativeDocsKindsEnumerator
{
    public string SourceKey = "AS_NORMATIVE_DOCS_KINDS";
    public string SourceFileFullPath = string.Empty;

    public NormativeDocsKindsEnumerator()
    {
        var ht = InitialGarSourceSingleton.getInstance();
        this.SourceFileFullPath = ht.GetMasterFullFilePathByStringKey(this.SourceKey);
    }

    public IEnumerable<NormativeDocsKind> IterNormativeDocsKinds()
    {
        Log.Information("Импорт из файла {filePath}", this.SourceFileFullPath);
        XDocument xDoc = XDocument.Load(this.SourceFileFullPath);
        foreach (XElement el in xDoc.Root.Elements())
        {
            yield return new NormativeDocsKind
            {
                Id = int.Parse(el.Attribute("ID").Value),
                Name = el.Attribute("NAME").Value,
            };
        }
    }
}
