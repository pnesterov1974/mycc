using System.Xml.Linq;
using ImportGeoEfc.models.garmodels;
using static Shared.MyLogger;

namespace ImportGeoEfc.SourceEnumerators.gar.masters;

public class NormativeDocsTypesEnumerator
{
    public string SourceKey = "AS_NORMATIVE_DOCS_TYPES";
    public string SourceFileFullPath = string.Empty;

    public NormativeDocsTypesEnumerator()
    {
        var ht = InitialGarSourceSingleton.getInstance();
        this.SourceFileFullPath = ht.GetMasterFullFilePathByStringKey(this.SourceKey);
    }

    public IEnumerable<NormativeDocsType> IterNormativeDocsTypes()
    {
        Log.Information("Импорт из файла {filePath}", this.SourceFileFullPath);
        XDocument xDoc = XDocument.Load(this.SourceFileFullPath);
        foreach (XElement el in xDoc.Root.Elements())
        {
            yield return new NormativeDocsType
            {
                Id = int.Parse(el.Attribute("ID").Value),
                Name = el.Attribute("NAME").Value,
                StartDate = DateOnly.Parse(el.Attribute("STARTDATE").Value),
                EndDate = DateOnly.Parse(el.Attribute("ENDDATE").Value),
            };
        }
    }
}