using System.Xml.Linq;
using ImportGeoEfc.models.garmodels;
using static Shared.MyLogger;

namespace ImportGeoEfc.SourceEnumerators.gar.masters;

public class RoomTypesEnumerator
{
    public string SourceKey = "AS_ROOM_TYPES";
    public string SourceFileFullPath = string.Empty;

    public RoomTypesEnumerator()
    {
        var ht = InitialGarSourceSingleton.getInstance();
        this.SourceFileFullPath = ht.GetMasterFullFilePathByStringKey(this.SourceKey);
    }

    public IEnumerable<RoomType> IterRoomTypes()
    {
        Log.Information("Импорт из файла {filePath}", this.SourceFileFullPath);
        XDocument xDoc = XDocument.Load(this.SourceFileFullPath);
        foreach (XElement el in xDoc.Root.Elements())
        {
            yield return new RoomType()
            {
                Id = int.Parse(el.Attribute("ID").Value),
                Name = el.Attribute("NAME").Value,
                Desc = el.Attribute("DESC").Value,
                IsActive = bool.Parse(el.Attribute("ISACTIVE").Value),
            };
        }
    }
}