using System.Xml.Linq;
using ImportGeoEfc.models.garmodels;
using static Shared.MyLogger;

namespace ImportGeoEfc.SourceEnumerators.gar.masters;

public class OperationTypesEnumerator
{
    public string SourceKey = "AS_OPERATION_TYPES";
    public string SourceFileFullPath = string.Empty;

    public OperationTypesEnumerator()
    {
        var ht = InitialGarSourceSingleton.getInstance();
        this.SourceFileFullPath = ht.GetMasterFullFilePathByStringKey(this.SourceKey);
    }

    public IEnumerable<OperationType> IterOperationTypes()
    {
        Log.Information("Импорт из файла {filePath}", this.SourceFileFullPath);
        XDocument xDoc = XDocument.Load(this.SourceFileFullPath);
        foreach (XElement el in xDoc.Root.Elements())
        {
            yield return new OperationType()
            {
                Id = int.Parse(el.Attribute("ID").Value),
                Name = el.Attribute("NAME").Value,
                UpdateDate = DateOnly.Parse(el.Attribute("UPDATEDATE").Value),
                StartDate = DateOnly.Parse(el.Attribute("STARTDATE").Value),
                EndDate = DateOnly.Parse(el.Attribute("ENDDATE").Value),
                IsActive = bool.Parse(el.Attribute("ISACTIVE").Value),
            };
        }
    }
}