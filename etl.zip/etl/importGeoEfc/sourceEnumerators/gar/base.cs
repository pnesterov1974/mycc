using Shared.GarImportModels.garfiles;

namespace ImportGeoEfc.SourceEnumerators.gar;

public class InitialGarSourceSingleton
{
    private static InitialGarSourceSingleton instance;

    public GarFiles GarFiles { get; set; }

    public static InitialGarSourceSingleton getInstance()
    {
        if (instance == null)
            instance = new InitialGarSourceSingleton();
        return instance;
    }

    private InitialGarSourceSingleton()
    {
        string basePath = @"/home/pnesterov/my_dev/files/gar/";
        this.GarFiles = new GarFiles(basePath);
    }

    public string GetMasterFullFilePathByStringKey(string sourceStringKey)
    {
        return this.GarFiles.GarMasters[sourceStringKey].FileFullPath;
    }

    public List<GarFile> GetFactFullFilePathsByStringKey(string sourceStringKey)
    {
        return this.GarFiles.GarFacts[sourceStringKey];
    }
}
