using System.Xml.Linq;
using ImportGeoEfc.models.garmodels;
using Shared.GarImportModels.garfiles;
using static Shared.MyLogger;

namespace ImportGeoEfc.SourceEnumerators.gar.facts;

public class AdmHierarchiesEnumerator
{
    public string SourceKey = "AS_ADM_HIERARCHY";
    public List<GarFile> SourceFiles;

    public AdmHierarchiesEnumerator()
    {
        var ht = InitialGarSourceSingleton.getInstance();
        this.SourceFiles = ht.GetFactFullFilePathsByStringKey(this.SourceKey);
    }

    public IEnumerable<AdmHierarchy> IterAdmHierarchy()
    {
        foreach (var sourceFile in this.SourceFiles)
        {
            Log.Information("Импорт из файла {filePath}", sourceFile.FileFullPath);
            XDocument xDoc = XDocument.Load(sourceFile.FileFullPath);
            foreach (XElement el in xDoc.Root.Elements())
            {
                var adh = new AdmHierarchy();
                adh.Id = int.Parse(el.Attribute("ID").Value);
                adh.ObjectId = int.Parse(el.Attribute("OBJECTID").Value);
                adh.ParentObjId = int.Parse(el.Attribute("PARENTOBJID").Value);
                adh.ChangeId = int.Parse(el.Attribute("CHANGEID").Value);
                
                try
                {
                    adh.RegionCode = int.Parse(el.Attribute("REGIONCODE").Value);
                }
                catch
                {
                    adh.RegionCode = null;
                }

                try
                {
                    adh.AreaCode = int.Parse(el.Attribute("AREACODE").Value);
                }
                catch
                {
                    adh.AreaCode = null;
                }

                try
                {
                    adh.CityCode = int.Parse(el.Attribute("CITYCODE").Value);
                }
                catch
                {
                    adh.CityCode = null;
                }

                try
                {
                    adh.PlaceCode = int.Parse(el.Attribute("PLACECODE").Value);
                }
                catch
                {
                    adh.PlaceCode = null;
                }

                try
                {
                    adh.PlanCode = int.Parse(el.Attribute("PLANCODE").Value);
                }
                catch
                {
                    adh.PlanCode = null;
                }

                try
                {
                    adh.StreetCode = int.Parse(el.Attribute("STREETCODE").Value);
                }
                catch
                {
                    adh.StreetCode = null;
                }

                try
                {
                    adh.NextId = int.Parse(el.Attribute("NEXTID").Value);
                }
                catch
                {
                    adh.NextId = null;
                }

                try
                {
                    adh.PrevId = int.Parse(el.Attribute("PREVID").Value);
                }
                catch
                {
                    adh.PrevId = null;
                }
                
                adh.UpdateDate = DateOnly.Parse(el.Attribute("UPDATEDATE").Value);
                adh.StartDate = DateOnly.Parse(el.Attribute("STARTDATE").Value);
                adh.EndDate = DateOnly.Parse(el.Attribute("ENDDATE").Value);
                adh.IsActive = int.Parse(el.Attribute("ISACTIVE").Value);
                adh.Path = el.Attribute("PATH").Value;

                yield return adh;
            }
        }
    }
}