using System.Xml.Linq;
using ImportGeoEfc.models.garmodels;
using Shared.GarImportModels.garfiles;
using static Shared.MyLogger;

namespace ImportGeoEfc.SourceEnumerators.gar.facts;

public class ChangeHistoryEnumerator
{
    public string SourceKey = "AS_CHANGE_HISTORY";
    public List<GarFile> SourceFiles;

    public ChangeHistoryEnumerator()
    {
        var ht = InitialGarSourceSingleton.getInstance();
        this.SourceFiles = ht.GetFactFullFilePathsByStringKey(this.SourceKey);
    }

    public IEnumerable<ChangeHistory> IterChangeHistory()
    {
        foreach (var sourceFile in this.SourceFiles)
        {
            Log.Information("Импорт из файла {filePath}", sourceFile.FileFullPath);
            XDocument xDoc = XDocument.Load(sourceFile.FileFullPath);
            foreach (XElement el in xDoc.Root.Elements())
            {
                var ch = new ChangeHistory();
                ch.ChangeId = int.Parse(el.Attribute("CHANGEID").Value);
                ch.ObjectId = int.Parse(el.Attribute("OBJECTID").Value);
                ch.AdrObjectId = el.Attribute("ADROBJECTID").Value;
                ch.OperTypeId = int.Parse(el.Attribute("OPERTYPEID").Value);
                try
                {
                    ch.NDocId = int.Parse(el.Attribute("NDOCID").Value);
                }
                catch
                {
                    ch.NDocId = null;
                }
                ch.ChangeDate = DateOnly.Parse(el.Attribute("CHANGEDATE").Value);
                yield return ch;
            }
        }
    }
}