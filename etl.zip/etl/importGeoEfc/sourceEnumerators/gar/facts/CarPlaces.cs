using System.Xml.Linq;
using ImportGeoEfc.models.garmodels;
using Shared.GarImportModels.garfiles;
using static Shared.MyLogger;

namespace ImportGeoEfc.SourceEnumerators.gar.facts;

public class CarPlacesEnumerator
{
    public string SourceKey = "AS_CARPLACES";
    public List<GarFile> SourceFiles;

    public CarPlacesEnumerator()
    {
        var ht = InitialGarSourceSingleton.getInstance();
        this.SourceFiles = ht.GetFactFullFilePathsByStringKey(this.SourceKey);
    }

    public IEnumerable<CarPlace> IterCarPlaces()
    {
        foreach (var sourceFile in this.SourceFiles)
        {
            Log.Information("Импорт из файла {filePath}", sourceFile.FileFullPath);
            XDocument xDoc = XDocument.Load(sourceFile.FileFullPath);
            foreach (XElement el in xDoc.Root.Elements())
            {
                var cp = new CarPlace();
                cp.Id = int.Parse(el.Attribute("ID").Value);
                cp.ObjectId = int.Parse(el.Attribute("OBJECTID").Value);
                cp.ObjectGuid = el.Attribute("OBJECTGUID").Value;
                cp.ChangeId = int.Parse(el.Attribute("CHANGEID").Value);
                cp.Number = el.Attribute("NUMBER").Value;
                cp.OperTypeId = int.Parse(el.Attribute("OPERTYPEID").Value);
                cp.PrevId = int.Parse(el.Attribute("PREVID").Value);
                try
                {
                    cp.NextId = int.Parse(el.Attribute("NEXTID").Value);
                }
                catch
                {
                    cp.NextId = null;
                }
                cp.UpdateDate = DateOnly.Parse(el.Attribute("UPDATEDATE").Value);
                cp.StartDate = DateOnly.Parse(el.Attribute("STARTDATE").Value);
                cp.EndDate = DateOnly.Parse(el.Attribute("ENDDATE").Value);
                cp.IsActual = int.Parse(el.Attribute("ISACTUAL").Value);
                cp.IsActive = int.Parse(el.Attribute("ISACTIVE").Value);

                yield return cp;
            }
        }
    }
}