using System.Xml.Linq;
using ImportGeoEfc.models.garmodels;
using Shared.GarImportModels.garfiles;
using static Shared.MyLogger;

namespace ImportGeoEfc.SourceEnumerators.gar.facts;

public class AppartmentParamsEnumerator
{
    public string SourceKey = "AS_APARTMENTS_PARAMS";
    public List<GarFile> SourceFiles;

    public AppartmentParamsEnumerator()
    {
        var ht = InitialGarSourceSingleton.getInstance();
        this.SourceFiles = ht.GetFactFullFilePathsByStringKey(this.SourceKey);
    }

    public IEnumerable<AppartmentParam> IterAppartmentParam()
    {
        foreach (var sourceFile in this.SourceFiles)
        {
            Log.Information("Импорт из файла {filePath}", sourceFile.FileFullPath);
            XDocument xDoc = XDocument.Load(sourceFile.FileFullPath);
            foreach (XElement el in xDoc.Root.Elements())
            {
                var aop = new AppartmentParam();
                aop.Id = int.Parse(el.Attribute("ID").Value);
                aop.ObjectId = int.Parse(el.Attribute("OBJECTID").Value);
                aop.ChangeId = int.Parse(el.Attribute("CHANGEID").Value);
                aop.ChangeIdend = int.Parse(el.Attribute("CHANGEIDEND").Value);
                aop.TypeId = int.Parse(el.Attribute("TYPEID").Value);
                aop.Value = el.Attribute("VALUE").Value;
                aop.UpdateDate = DateOnly.Parse(el.Attribute("UPDATEDATE").Value);
                aop.StartDate = DateOnly.Parse(el.Attribute("STARTDATE").Value);
                aop.EndDate = DateOnly.Parse(el.Attribute("ENDDATE").Value);
                yield return aop;
            }
        }
    }
}