using System.Xml.Linq;
using ImportGeoEfc.models.garmodels;
using Shared.GarImportModels.garfiles;
using static Shared.MyLogger;

namespace ImportGeoEfc.SourceEnumerators.gar.facts;

public class AppartmentsEnumerator
{
    public string SourceKey = "AS_APARTMENTS";
    public List<GarFile> SourceFiles;

    public AppartmentsEnumerator()
    {
        var ht = InitialGarSourceSingleton.getInstance();
        this.SourceFiles = ht.GetFactFullFilePathsByStringKey(this.SourceKey);
    }

    public IEnumerable<Appartment> IterAppartment()
    {
        foreach (var sourceFile in this.SourceFiles)
        {
            Log.Information("Импорт из файла {filePath}", sourceFile.FileFullPath);
            XDocument xDoc = XDocument.Load(sourceFile.FileFullPath);
            foreach (XElement el in xDoc.Root.Elements())
            {
                var app = new Appartment();
                app.Id = int.Parse(el.Attribute("ID").Value);
                app.ObjectId = int.Parse(el.Attribute("OBJECTID").Value);
                app.ObjectGuid = el.Attribute("OBJECTGUID").Value;
                app.ChangeId = int.Parse(el.Attribute("CHANGEID").Value);
                app.Number = el.Attribute("NUMBER").Value;
                app.ApartType = int.Parse(el.Attribute("APARTTYPE").Value);
                app.OperTypeId = int.Parse(el.Attribute("OPERTYPEID").Value);
                app.PrevId = int.Parse(el.Attribute("PREVID").Value);
                try
                {
                    app.NextId = int.Parse(el.Attribute("NEXTID").Value);
                }
                catch
                {
                    app.NextId = null;
                }
                app.UpdateDate = DateOnly.Parse(el.Attribute("UPDATEDATE").Value);
                app.StartDate = DateOnly.Parse(el.Attribute("STARTDATE").Value);
                app.EndDate = DateOnly.Parse(el.Attribute("ENDDATE").Value);
                app.IsActual = int.Parse(el.Attribute("ISACTUAL").Value);
                app.IsActive = int.Parse(el.Attribute("ISACTIVE").Value);

                yield return app;
            }
        }
    }
}