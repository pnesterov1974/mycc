using System.Xml.Linq;
using ImportGeoEfc.models.garmodels;
using Shared.GarImportModels.garfiles;
using static Shared.MyLogger;

namespace ImportGeoEfc.SourceEnumerators.gar.facts;

public class AddrObjDivisionsEnumerator
{
    public string SourceKey = "AS_ADDR_OBJ_DIVISION";
    public List<GarFile> SourceFiles;

    public AddrObjDivisionsEnumerator()
    {
        var ht = InitialGarSourceSingleton.getInstance();
        this.SourceFiles = ht.GetFactFullFilePathsByStringKey(this.SourceKey);
    }

    public IEnumerable<AddrObjDivision> IterAddrObjDivision()
    {
        foreach (var sourceFile in this.SourceFiles)
        {
            Log.Information("Импорт из файла {filePath}", sourceFile.FileFullPath);
            XDocument xDoc = XDocument.Load(sourceFile.FileFullPath);
            foreach (XElement el in xDoc.Root.Elements())
            {
                var aod = new AddrObjDivision();
                aod.Id = int.Parse(el.Attribute("ID").Value);
                aod.ParentId = int.Parse(el.Attribute("PARENTID").Value);
                aod.ChildId = int.Parse(el.Attribute("CHILDID").Value);
                aod.ChangeId = int.Parse(el.Attribute("CHANGEID").Value);
                yield return aod;
            }
        }
    }
}