using System.Xml.Linq;
using ImportGeoEfc.models.garmodels;
using Shared.GarImportModels.garfiles;
using static Shared.MyLogger;

namespace ImportGeoEfc.SourceEnumerators.gar.facts;

public class AddrObjsEnumerator
{
    public string SourceKey = "AS_ADDR_OBJ";
    public List<GarFile> SourceFiles;

    public AddrObjsEnumerator()
    {
        var ht = InitialGarSourceSingleton.getInstance();
        this.SourceFiles = ht.GetFactFullFilePathsByStringKey(this.SourceKey);
    }

    public IEnumerable<AddrObj> IterAddrObj()
    {
        foreach (var sourceFile in this.SourceFiles)
        {
            Log.Information("Импорт из файла {filePath}", sourceFile.FileFullPath);
            XDocument xDoc = XDocument.Load(sourceFile.FileFullPath);
            foreach (XElement el in xDoc.Root.Elements())
            {
                var ao = new AddrObj();
                ao.Id = int.Parse(el.Attribute("ID").Value);
                ao.ObjectId = int.Parse(el.Attribute("OBJECTID").Value);
                ao.ObjectGuid = el.Attribute("OBJECTGUID").Value;
                ao.ChangeId = int.Parse(el.Attribute("CHANGEID").Value);
                ao.Name = el.Attribute("NAME").Value;
                ao.TypeName = el.Attribute("TYPENAME").Value;
                ao.Level = int.Parse(el.Attribute("LEVEL").Value);
                ao.OperTypeId = int.Parse(el.Attribute("OPERTYPEID").Value);
                ao.PrevId = int.Parse(el.Attribute("PREVID").Value);
                try
                {
                    ao.NextId = int.Parse(el.Attribute("NEXTID").Value);
                }
                catch
                {
                    ao.NextId = null;
                }
                ao.UpdateDate = DateOnly.Parse(el.Attribute("UPDATEDATE").Value);
                ao.StartDate = DateOnly.Parse(el.Attribute("STARTDATE").Value);
                ao.EndDate = DateOnly.Parse(el.Attribute("ENDDATE").Value);
                ao.IsActual = int.Parse(el.Attribute("ISACTUAL").Value);
                ao.IsActive = int.Parse(el.Attribute("ISACTIVE").Value);
                yield return ao;
            }
        }
    }
}