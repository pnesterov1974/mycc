using System.Xml.Linq;
using ImportGeoEfc.models.garmodels;
using Shared.GarImportModels.garfiles;
using static Shared.MyLogger;

namespace ImportGeoEfc.SourceEnumerators.gar.facts;

public class HousesEnumerator
{
    public string SourceKey = "AS_HOUSES";
    public List<GarFile> SourceFiles;

    public HousesEnumerator()
    {
        var ht = InitialGarSourceSingleton.getInstance();
        this.SourceFiles = ht.GetFactFullFilePathsByStringKey(this.SourceKey);
    }

    public IEnumerable<House> IterHouses()
    {
        foreach (var sourceFile in this.SourceFiles)
        {
            Log.Information("Импорт из файла {filePath}", sourceFile.FileFullPath);
            XDocument xDoc = XDocument.Load(sourceFile.FileFullPath);
            foreach (XElement el in xDoc.Root.Elements())
            {
                var h = new House();
                h.Id = int.Parse(el.Attribute("ID").Value);
                h.ObjectId = int.Parse(el.Attribute("OBJECTID").Value);
                h.ObjectGuid = el.Attribute("OBJECTGUID").Value;
                h.ChangeId = int.Parse(el.Attribute("CHANGEID").Value);
                try
                {
                    h.HouseNum = el.Attribute("HOUSENUM").Value;
                }
                catch
                {
                    h.HouseNum = null;
                }
                try
                {
                    h.HouseType = el.Attribute("HOUSETYPE").Value;
                }
                catch
                {
                    h.HouseType = null;
                }
                h.OperTypeId = int.Parse(el.Attribute("OPERTYPEID").Value);
                try
                {
                    h.PrevId = int.Parse(el.Attribute("PREVID").Value);
                }
                catch
                {
                    h.PrevId = null;
                }
                try
                {
                    h.NextId = int.Parse(el.Attribute("NEXTID").Value);
                }
                catch
                {
                    h.NextId = null;
                }
                h.UpdateDate = DateOnly.Parse(el.Attribute("UPDATEDATE").Value);
                h.StartDate = DateOnly.Parse(el.Attribute("STARTDATE").Value);
                h.EndDate = DateOnly.Parse(el.Attribute("ENDDATE").Value);
                h.IsActual = int.Parse(el.Attribute("ISACTUAL").Value);
                h.IsActive = int.Parse(el.Attribute("ISACTIVE").Value);

                yield return h;
            }
        }
    }
}