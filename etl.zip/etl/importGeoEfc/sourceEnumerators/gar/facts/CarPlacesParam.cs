using System.Xml.Linq;
using ImportGeoEfc.models.garmodels;
using Shared.GarImportModels.garfiles;
using static Shared.MyLogger;

namespace ImportGeoEfc.SourceEnumerators.gar.facts;

public class CarPlacesParamsEnumerator
{
    public string SourceKey = "AS_CARPLACES_PARAMS";
    public List<GarFile> SourceFiles;

    public CarPlacesParamsEnumerator()
    {
        var ht = InitialGarSourceSingleton.getInstance();
        this.SourceFiles = ht.GetFactFullFilePathsByStringKey(this.SourceKey);
    }

    public IEnumerable<CarPlacesParam> IterCarPlacesParams()
    {
        foreach (var sourceFile in this.SourceFiles)
        {
            Log.Information("Импорт из файла {filePath}", sourceFile.FileFullPath);
            XDocument xDoc = XDocument.Load(sourceFile.FileFullPath);
            foreach (XElement el in xDoc.Root.Elements())
            {
                var cpp = new CarPlacesParam();
                cpp.Id = int.Parse(el.Attribute("ID").Value);
                cpp.ObjectId = int.Parse(el.Attribute("OBJECTID").Value);
                cpp.ChangeId = int.Parse(el.Attribute("CHANGEID").Value);
                cpp.ChangeIdend = int.Parse(el.Attribute("CHANGEIDEND").Value);
                cpp.TypeId = int.Parse(el.Attribute("TYPEID").Value);
                cpp.Value = el.Attribute("VALUE").Value;
                cpp.UpdateDate = DateOnly.Parse(el.Attribute("UPDATEDATE").Value);
                cpp.StartDate = DateOnly.Parse(el.Attribute("STARTDATE").Value);
                cpp.EndDate = DateOnly.Parse(el.Attribute("ENDDATE").Value);
                yield return cpp;
            }
        }
    }
}