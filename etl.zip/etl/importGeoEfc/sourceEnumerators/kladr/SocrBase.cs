using Shared.KladrImportModels;
using static Shared.MyLogger;
using ImportGeoEfc.models.kladr;
using DbfDataReader;

namespace ImportGeoEfc.SourceEnumerators.kladr;

public class SocrBaseSourceEnumerator: BaseSourceEnumerator
{
    public IImportModel ImportModel = new SocrBaseImportModel();

    private DbfDataReaderOptions dbfOptions = new DbfDataReaderOptions { SkipDeletedRecords = true };

    public IEnumerable<SocrBase> SocrBaseIter()
    {
        string sourceFilePath = this.ImportModel.SourceFullPathName;
        Log.Information("Проверка источника KLADR из {kladrPath}", sourceFilePath);
        if (!this.ReadDbfInfo(sourceFilePath))
        {
            Log.Information("Источник {sourceFile} не валиден. Отмена обработки SOCRBASE", sourceFilePath);
            yield break;
        }
        string DtFileFullPath = this.ImportModel.DtFileFullPath;
        Log.Information("Дата-метка файл {dtFilePath}", DtFileFullPath);
        DateOnly Dt = this.ImportModel.Dt;
        Log.Information("Дата-метка {dt}", Dt);
        Log.Information("Загрузка SocrBase из {kladrPath}", sourceFilePath);
        using (var dbfDataReader = new DbfDataReader.DbfDataReader(sourceFilePath, this.dbfOptions))
        {
            while (dbfDataReader.Read())
            {
                var level = dbfDataReader.GetString(0);
                var scName = dbfDataReader.GetString(1);
                var socrName = dbfDataReader.GetString(2);
                var kodTst = dbfDataReader.GetString(3);

                var socrBase = new SocrBase
                {
                    Level = int.Parse(level),
                    ScName = scName,
                    SocrName = socrName,
                    KodTSt = kodTst,
                    BusinessDT = Dt
                };
                yield return socrBase;
            }
        }
    }
}