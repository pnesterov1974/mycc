using Shared.KladrImportModels;
using static Shared.MyLogger;
using ImportGeoEfc.models.kladr;
using DbfDataReader;

namespace ImportGeoEfc.SourceEnumerators.kladr;

public class AltNamesSourceEnumerator: BaseSourceEnumerator
{
    public IImportModel ImportModel = new AltNamesImportModel();

    private DbfDataReaderOptions dbfOptions = new DbfDataReaderOptions { SkipDeletedRecords = true };

    public IEnumerable<AltNames> AltNamesIter()
    {
        string sourceFilePath = this.ImportModel.SourceFullPathName;
        Log.Information("Проверка источника KLADR из {kladrPath}", sourceFilePath);
        if (!this.ReadDbfInfo(sourceFilePath))
        {
            Log.Information("Источник {sourceFile} не валиден. Отмена обработки KLADR", sourceFilePath);
            yield break;
        }
        string DtFileFullPath = this.ImportModel.DtFileFullPath;
        Log.Information("Дата-метка файл {dtFilePath}", DtFileFullPath);
        DateOnly Dt = this.ImportModel.Dt;
        Log.Information("Дата-метка {dt}", Dt);
        Log.Information("Загрузка AltNames из {kladrPath}", sourceFilePath);
        using (var dbfDataReader = new DbfDataReader.DbfDataReader(sourceFilePath, this.dbfOptions))
        {
            while (dbfDataReader.Read())
            {
                var oldCode = dbfDataReader.GetString(0);
                var newCode = dbfDataReader.GetString(1);
                var level = dbfDataReader.GetString(2);

                var altNames = new AltNames
                {
                    OldCode = oldCode,
                    NewCode = newCode,
                    Level = int.Parse(level),
                    BusinessDT = Dt
                };
                yield return altNames;
            }
        }
    }
}