using Shared.KladrImportModels;
using static Shared.MyLogger;
using ImportGeoEfc.models.kladr;
using DbfDataReader;

namespace ImportGeoEfc.SourceEnumerators.kladr;

public class KladrSourceEnumerator: BaseSourceEnumerator
{
    public IImportModel ImportModel = new KladrImportModel();

    private DbfDataReaderOptions dbfOptions = new DbfDataReaderOptions { SkipDeletedRecords = true };

    public IEnumerable<Kladr> KladrIter()
    {
        string sourceFilePath = this.ImportModel.SourceFullPathName;
        Log.Information("Проверка источника KLADR из {kladrPath}", sourceFilePath);
        if (!this.ReadDbfInfo(sourceFilePath))
        {
            Log.Information("Источник {sourceFile} не валиден. Отмена обработки KLADR", sourceFilePath);
            yield break;
        }
        string DtFileFullPath = this.ImportModel.DtFileFullPath;
        Log.Information("Дата-метка файл {dtFilePath}", DtFileFullPath);
        DateOnly Dt = this.ImportModel.Dt;
        Log.Information("Дата-метка {dt}", Dt);
        Log.Information("Загрузка KLADR из {kladrPath}", sourceFilePath);
        using (var dbfDataReader = new DbfDataReader.DbfDataReader(sourceFilePath, this.dbfOptions))
        {
            while (dbfDataReader.Read())
            {
                var name = dbfDataReader.GetString(0);
                var socr = dbfDataReader.GetString(1);
                var code = dbfDataReader.GetString(2);
                var index = dbfDataReader.GetString(3);
                var gninmb = dbfDataReader.GetString(4);
                var uno = dbfDataReader.GetString(5);
                var ocatd = dbfDataReader.GetString(6);
                var status = dbfDataReader.GetString(7);

                var kladr = new Kladr
                {
                    Name = name,
                    Socr = socr,
                    Code = code,
                    Index = index,
                    Gninmb = gninmb,
                    Uno = uno,
                    Ocatd = ocatd,
                    Status = int.Parse(status),
                    BusinessDT = Dt
                };
                yield return kladr;
            }
        }
    }
}