using Microsoft.EntityFrameworkCore;
using Shared;
using static Shared.MyLogger;
using Shared.connections;
using ImportGeoEfc.models.garmodels;

namespace ImportGeoEfc;

public class GarContext : DbContext
{
    public DbSet<HouseType> HouseTypes { get; set; } = null;
    public DbSet<AddrObjType> AddrObjTypes { get; set; } = null;
    public DbSet<AppartmentType> AppartmentTypes { get; set; } = null;
    public DbSet<NormativeDocsKind> NormativeDocsKinds { get; set; } = null;
    public DbSet<NormativeDocsType> NormativeDocsTypes { get; set; } = null;
    public DbSet<ObjectLevel> ObjectLevels { get; set; } = null;
    public DbSet<OperationType> OparationTypes { get; set; } = null;
    public DbSet<ParamType> ParamTypes { get; set; } = null;
    public DbSet<RoomType> RoomTypes { get; set; } = null;

    // Facts --------
    public DbSet<AddrObj> AddrObjs { get; set; } = null;
    public DbSet<AddrObjDivision> AddrObjDivisions { get; set; } = null;
    public DbSet<AddrObjParam> AddrObjParams { get; set; } = null;
    public DbSet<AdmHierarchy> AdmHierarchies { get; set; } = null;
    public DbSet<Appartment> Appartments { get; set; } = null;
    public DbSet<AppartmentParam> AppartmentParams { get; set; } = null;
    public DbSet<CarPlace> CarPlaces { get; set; } = null;
    public DbSet<CarPlacesParam> CarPlacesParams { get; set; } = null;
    public DbSet<ChangeHistory> ChangesHistory { get; set; } = null;
    public DbSet<House> Houses { get; set; } = null;

    private TargetDb tdb;

    public GarContext(TargetDb tdb = TargetDb.mssql)
    {
        this.tdb = tdb;
        Database.EnsureCreated();
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!ConnectionStrings.ConnectionStringsInitialized())
        {
            ConnectionStrings.InitConnectionStrings(Shared.TargetDb.pgsql);
        }

        string connStr = ConnectionStrings.GetConnectionStringByName("gar");
        Log.Debug("Строка подключения: {connStr}", connStr);

        switch (this.tdb)
        {
            case TargetDb.mssql:
                {
                    optionsBuilder.UseSqlServer(connStr);
                    break;
                }
            case TargetDb.pgsql:
                {
                    optionsBuilder.UseNpgsql(connStr);
                    break;
                }
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        switch (this.tdb)
        {
            case TargetDb.mssql:
                {
                    modelBuilder.HasDefaultSchema("stg");

                    modelBuilder.Entity<HouseType>().ToTable("HouseTypes");
                    modelBuilder.Entity<HouseType>().Property("Id").HasColumnName("Id");
                    modelBuilder.Entity<HouseType>().Property("Name").HasColumnName("Name");
                    modelBuilder.Entity<HouseType>().Property("ShortName").HasColumnName("ShortName");
                    modelBuilder.Entity<HouseType>().Property("Desc").HasColumnName("Desc");
                    modelBuilder.Entity<HouseType>().Property("UpdateDate").HasColumnName("UpdateDate");
                    modelBuilder.Entity<HouseType>().Property("StartDate").HasColumnName("StartDate");
                    modelBuilder.Entity<HouseType>().Property("EndDate").HasColumnName("EndDate");
                    modelBuilder.Entity<HouseType>().Property("IsActive").HasColumnName("IsActive");

                    modelBuilder.Entity<AddrObjType>().ToTable("AddrObjTypes");
                    modelBuilder.Entity<AddrObjType>().Property("Id").HasColumnName("Id");
                    modelBuilder.Entity<AddrObjType>().Property("Level").HasColumnName("Level");
                    modelBuilder.Entity<AddrObjType>().Property("ShortName").HasColumnName("ShortName");
                    modelBuilder.Entity<AddrObjType>().Property("Name").HasColumnName("Name");
                    modelBuilder.Entity<AddrObjType>().Property("Desc").HasColumnName("Desc");
                    modelBuilder.Entity<AddrObjType>().Property("UpdateDate").HasColumnName("UpdateDate");
                    modelBuilder.Entity<AddrObjType>().Property("StartDate").HasColumnName("StartDate");
                    modelBuilder.Entity<AddrObjType>().Property("EndDate").HasColumnName("EndDate");

                    modelBuilder.Entity<AppartmentType>().ToTable("AppartmentTypes");
                    modelBuilder.Entity<AppartmentType>().Property("Id").HasColumnName("Id");
                    modelBuilder.Entity<AppartmentType>().Property("Name").HasColumnName("Name");
                    modelBuilder.Entity<AppartmentType>().Property("ShortName").HasColumnName("ShortName");
                    modelBuilder.Entity<AppartmentType>().Property("Desc").HasColumnName("Desc");
                    modelBuilder.Entity<AppartmentType>().Property("UpdateDate").HasColumnName("UpdateDate");
                    modelBuilder.Entity<AppartmentType>().Property("StartDate").HasColumnName("StartDate");
                    modelBuilder.Entity<AppartmentType>().Property("EndDate").HasColumnName("EndDate");
                    modelBuilder.Entity<AppartmentType>().Property("IsActive").HasColumnName("IsActive");

                    modelBuilder.Entity<NormativeDocsKind>().ToTable("NormativeDocsKinds");
                    modelBuilder.Entity<NormativeDocsKind>().Property("Id").HasColumnName("Id");
                    modelBuilder.Entity<NormativeDocsKind>().Property("Name").HasColumnName("Name");

                    modelBuilder.Entity<NormativeDocsType>().ToTable("NormativeDocsTypes");
                    modelBuilder.Entity<NormativeDocsType>().Property("Id").HasColumnName("Id");
                    modelBuilder.Entity<NormativeDocsType>().Property("Name").HasColumnName("Name");
                    modelBuilder.Entity<NormativeDocsType>().Property("StartDate").HasColumnName("StartDate");
                    modelBuilder.Entity<NormativeDocsType>().Property("EndDate").HasColumnName("EndDate");

                    modelBuilder.Entity<ObjectLevel>().ToTable("ObjectLevels");
                    modelBuilder.Entity<ObjectLevel>().Property("Level").HasColumnName("Level");
                    modelBuilder.Entity<ObjectLevel>().Property("Name").HasColumnName("Name");
                    //modelBuilder.Entity<ObjectLevel>().Property("ShortName").HasColumnName("shortname");
                    modelBuilder.Entity<ObjectLevel>().Property("UpdateDate").HasColumnName("UpdateDate");
                    modelBuilder.Entity<ObjectLevel>().Property("StartDate").HasColumnName("StartDate");
                    modelBuilder.Entity<ObjectLevel>().Property("EndDate").HasColumnName("EndDate");
                    modelBuilder.Entity<ObjectLevel>().Property("IsActive").HasColumnName("IsActive");

                    modelBuilder.Entity<OperationType>().ToTable("OperationTypes");
                    modelBuilder.Entity<OperationType>().Property("Id").HasColumnName("Id");
                    modelBuilder.Entity<OperationType>().Property("Name").HasColumnName("Name");
                    //modelBuilder.Entity<OperationType>().Property("ShortName").HasColumnName("shortname");
                    //modelBuilder.Entity<OperationType>().Property("Desc").HasColumnName("desc");
                    modelBuilder.Entity<OperationType>().Property("UpdateDate").HasColumnName("UpdateDate");
                    modelBuilder.Entity<OperationType>().Property("StartDate").HasColumnName("StartDate");
                    modelBuilder.Entity<OperationType>().Property("EndDate").HasColumnName("EndDate");
                    modelBuilder.Entity<OperationType>().Property("IsActive").HasColumnName("IsActive");

                    modelBuilder.Entity<ParamType>().ToTable("ParamTypes");
                    modelBuilder.Entity<ParamType>().Property("Id").HasColumnName("Id");
                    modelBuilder.Entity<ParamType>().Property("Name").HasColumnName("Name");
                    modelBuilder.Entity<ParamType>().Property("Code").HasColumnName("Code");
                    modelBuilder.Entity<ParamType>().Property("Desc").HasColumnName("Desc");
                    modelBuilder.Entity<ParamType>().Property("UpdateDate").HasColumnName("UpdateDate");
                    modelBuilder.Entity<ParamType>().Property("StartDate").HasColumnName("StartDate");
                    modelBuilder.Entity<ParamType>().Property("EndDate").HasColumnName("EndDate");
                    modelBuilder.Entity<ParamType>().Property("IsActive").HasColumnName("IsActive");

                    modelBuilder.Entity<RoomType>().ToTable("RoomTypes");
                    modelBuilder.Entity<RoomType>().Property("Id").HasColumnName("Id");
                    modelBuilder.Entity<RoomType>().Property("Name").HasColumnName("Name");
                    //modelBuilder.Entity<RoomType>().Property("ShortName").HasColumnName("shortname");
                    modelBuilder.Entity<RoomType>().Property("Desc").HasColumnName("Desc");
                    //modelBuilder.Entity<RoomType>().Property("UpdateDate").HasColumnName("updatedate");
                    //modelBuilder.Entity<RoomType>().Property("StartDate").HasColumnName("startdate");
                    //modelBuilder.Entity<RoomType>().Property("EndDate").HasColumnName("enddate");
                    modelBuilder.Entity<RoomType>().Property("IsActive").HasColumnName("IsActive");

                    break;
                }
            case TargetDb.pgsql:
                {
                    modelBuilder.HasDefaultSchema("stg");
                    modelBuilder.Entity<HouseType>().ToTable("house_types");
                    modelBuilder.Entity<HouseType>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<HouseType>().Property("Name").HasColumnName("name");
                    modelBuilder.Entity<HouseType>().Property("ShortName").HasColumnName("shortname");
                    modelBuilder.Entity<HouseType>().Property("Desc").HasColumnName("desc");
                    modelBuilder.Entity<HouseType>().Property("UpdateDate").HasColumnName("updatedate");
                    modelBuilder.Entity<HouseType>().Property("StartDate").HasColumnName("startdate");
                    modelBuilder.Entity<HouseType>().Property("EndDate").HasColumnName("enddate");
                    modelBuilder.Entity<HouseType>().Property("IsActive").HasColumnName("isactive");

                    modelBuilder.Entity<AddrObjType>().ToTable("addr_obj_types");
                    modelBuilder.Entity<AddrObjType>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<AddrObjType>().Property("Level").HasColumnName("level");
                    modelBuilder.Entity<AddrObjType>().Property("ShortName").HasColumnName("shortname");
                    modelBuilder.Entity<AddrObjType>().Property("Name").HasColumnName("name");
                    modelBuilder.Entity<AddrObjType>().Property("Desc").HasColumnName("desc");
                    modelBuilder.Entity<AddrObjType>().Property("UpdateDate").HasColumnName("updatedate");
                    modelBuilder.Entity<AddrObjType>().Property("StartDate").HasColumnName("startdate");
                    modelBuilder.Entity<AddrObjType>().Property("EndDate").HasColumnName("enddate");

                    modelBuilder.Entity<AppartmentType>().ToTable("appartment_types");
                    modelBuilder.Entity<AppartmentType>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<AppartmentType>().Property("Name").HasColumnName("name");
                    modelBuilder.Entity<AppartmentType>().Property("ShortName").HasColumnName("shortname");
                    modelBuilder.Entity<AppartmentType>().Property("Desc").HasColumnName("desc");
                    modelBuilder.Entity<AppartmentType>().Property("UpdateDate").HasColumnName("updatedate");
                    modelBuilder.Entity<AppartmentType>().Property("StartDate").HasColumnName("startdate");
                    modelBuilder.Entity<AppartmentType>().Property("EndDate").HasColumnName("enddate");
                    modelBuilder.Entity<AppartmentType>().Property("IsActive").HasColumnName("isactive");

                    modelBuilder.Entity<NormativeDocsKind>().ToTable("normative_docs_kinds");
                    modelBuilder.Entity<NormativeDocsKind>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<NormativeDocsKind>().Property("Name").HasColumnName("name");

                    modelBuilder.Entity<NormativeDocsType>().ToTable("normative_docs_types");
                    modelBuilder.Entity<NormativeDocsType>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<NormativeDocsType>().Property("Name").HasColumnName("name");
                    modelBuilder.Entity<NormativeDocsType>().Property("StartDate").HasColumnName("startdate");
                    modelBuilder.Entity<NormativeDocsType>().Property("EndDate").HasColumnName("enddate");

                    modelBuilder.Entity<ObjectLevel>().ToTable("object_levels");
                    modelBuilder.Entity<ObjectLevel>().Property("Level").HasColumnName("level");
                    modelBuilder.Entity<ObjectLevel>().Property("Name").HasColumnName("name");
                    //modelBuilder.Entity<ObjectLevel>().Property("ShortName").HasColumnName("shortname");
                    modelBuilder.Entity<ObjectLevel>().Property("UpdateDate").HasColumnName("updatedate");
                    modelBuilder.Entity<ObjectLevel>().Property("StartDate").HasColumnName("startdate");
                    modelBuilder.Entity<ObjectLevel>().Property("EndDate").HasColumnName("enddate");
                    modelBuilder.Entity<ObjectLevel>().Property("IsActive").HasColumnName("isactive");

                    modelBuilder.Entity<OperationType>().ToTable("operation_types");
                    modelBuilder.Entity<OperationType>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<OperationType>().Property("Name").HasColumnName("name");
                    //modelBuilder.Entity<OperationType>().Property("ShortName").HasColumnName("shortname");
                    //modelBuilder.Entity<OperationType>().Property("Desc").HasColumnName("desc");
                    modelBuilder.Entity<OperationType>().Property("UpdateDate").HasColumnName("updatedate");
                    modelBuilder.Entity<OperationType>().Property("StartDate").HasColumnName("startdate");
                    modelBuilder.Entity<OperationType>().Property("EndDate").HasColumnName("enddate");
                    modelBuilder.Entity<OperationType>().Property("IsActive").HasColumnName("isactive");

                    modelBuilder.Entity<ParamType>().ToTable("param_types");
                    modelBuilder.Entity<ParamType>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<ParamType>().Property("Name").HasColumnName("name");
                    modelBuilder.Entity<ParamType>().Property("Code").HasColumnName("code");
                    modelBuilder.Entity<ParamType>().Property("Desc").HasColumnName("desc");
                    modelBuilder.Entity<ParamType>().Property("UpdateDate").HasColumnName("updatedate");
                    modelBuilder.Entity<ParamType>().Property("StartDate").HasColumnName("startdate");
                    modelBuilder.Entity<ParamType>().Property("EndDate").HasColumnName("enddate");
                    modelBuilder.Entity<ParamType>().Property("IsActive").HasColumnName("isactive");

                    modelBuilder.Entity<RoomType>().ToTable("room_types");
                    modelBuilder.Entity<RoomType>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<RoomType>().Property("Name").HasColumnName("name");
                    //modelBuilder.Entity<RoomType>().Property("ShortName").HasColumnName("shortname");
                    modelBuilder.Entity<RoomType>().Property("Desc").HasColumnName("desc");
                    //modelBuilder.Entity<RoomType>().Property("UpdateDate").HasColumnName("updatedate");
                    //modelBuilder.Entity<RoomType>().Property("StartDate").HasColumnName("startdate");
                    //modelBuilder.Entity<RoomType>().Property("EndDate").HasColumnName("enddate");
                    modelBuilder.Entity<RoomType>().Property("IsActive").HasColumnName("isactive");

                    // Facts ....

                    modelBuilder.Entity<AddrObj>().ToTable("addr_obj");
                    modelBuilder.Entity<AddrObj>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<AddrObj>().Property("ObjectId").HasColumnName("object_id");
                    modelBuilder.Entity<AddrObj>().Property("ObjectGuid").HasColumnName("object_guid");
                    modelBuilder.Entity<AddrObj>().Property("ChangeId").HasColumnName("change_id");
                    modelBuilder.Entity<AddrObj>().Property("Name").HasColumnName("name");
                    modelBuilder.Entity<AddrObj>().Property("TypeName").HasColumnName("type_name");
                    modelBuilder.Entity<AddrObj>().Property("Level").HasColumnName("level");
                    modelBuilder.Entity<AddrObj>().Property("OperTypeId").HasColumnName("opertype_id");
                    modelBuilder.Entity<AddrObj>().Property("PrevId").HasColumnName("prev_id");
                    modelBuilder.Entity<AddrObj>().Property("NextId").HasColumnName("next_id");
                    modelBuilder.Entity<AddrObj>().Property("UpdateDate").HasColumnName("update_date");
                    modelBuilder.Entity<AddrObj>().Property("StartDate").HasColumnName("start_date");
                    modelBuilder.Entity<AddrObj>().Property("EndDate").HasColumnName("end_date");
                    modelBuilder.Entity<AddrObj>().Property("IsActual").HasColumnName("is_actual");
                    modelBuilder.Entity<AddrObj>().Property("IsActive").HasColumnName("is_active");

                    modelBuilder.Entity<AddrObjDivision>().ToTable("addr_obj_division");
                    modelBuilder.Entity<AddrObjDivision>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<AddrObjDivision>().Property("ParentId").HasColumnName("parent_id");
                    modelBuilder.Entity<AddrObjDivision>().Property("ChildId").HasColumnName("child_id");
                    modelBuilder.Entity<AddrObjDivision>().Property("ChangeId").HasColumnName("change_id");
                    
                    modelBuilder.Entity<AddrObjParam>().ToTable("addr_obj_param");
                    modelBuilder.Entity<AddrObjParam>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<AddrObjParam>().Property("ObjectId").HasColumnName("object_id");
                    modelBuilder.Entity<AddrObjParam>().Property("ChangeId").HasColumnName("change_id");
                    modelBuilder.Entity<AddrObjParam>().Property("ChangeIdend").HasColumnName("change_idend");
                    modelBuilder.Entity<AddrObjParam>().Property("TypeId").HasColumnName("type_id");
                    modelBuilder.Entity<AddrObjParam>().Property("Value").HasColumnName("value");
                    modelBuilder.Entity<AddrObjParam>().Property("UpdateDate").HasColumnName("update_date");
                    modelBuilder.Entity<AddrObjParam>().Property("StartDate").HasColumnName("start_date");
                    modelBuilder.Entity<AddrObjParam>().Property("EndDate").HasColumnName("end_date");

                    modelBuilder.Entity<AdmHierarchy>().ToTable("adm_hierarchy");
                    modelBuilder.Entity<AdmHierarchy>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<AdmHierarchy>().Property("ObjectId").HasColumnName("object_id");
                    modelBuilder.Entity<AdmHierarchy>().Property("ParentObjId").HasColumnName("parentobj_id");
                    modelBuilder.Entity<AdmHierarchy>().Property("ChangeId").HasColumnName("change_idend");
                    modelBuilder.Entity<AdmHierarchy>().Property("RegionCode").HasColumnName("region_code");
                    modelBuilder.Entity<AdmHierarchy>().Property("AreaCode").HasColumnName("area_code");
                    modelBuilder.Entity<AdmHierarchy>().Property("CityCode").HasColumnName("city_code");
                    modelBuilder.Entity<AdmHierarchy>().Property("PlaceCode").HasColumnName("place_code");
                    modelBuilder.Entity<AdmHierarchy>().Property("PlanCode").HasColumnName("plan_code");
                    modelBuilder.Entity<AdmHierarchy>().Property("StreetCode").HasColumnName("street_code");
                    modelBuilder.Entity<AdmHierarchy>().Property("PrevId").HasColumnName("prev_id");
                    modelBuilder.Entity<AdmHierarchy>().Property("NextId").HasColumnName("next_id");
                    modelBuilder.Entity<AdmHierarchy>().Property("UpdateDate").HasColumnName("update_date");
                    modelBuilder.Entity<AdmHierarchy>().Property("StartDate").HasColumnName("start_date");
                    modelBuilder.Entity<AdmHierarchy>().Property("EndDate").HasColumnName("end_date");
                    modelBuilder.Entity<AdmHierarchy>().Property("IsActive").HasColumnName("is_active");
                    modelBuilder.Entity<AdmHierarchy>().Property("Path").HasColumnName("path");

                    modelBuilder.Entity<Appartment>().ToTable("appartment");
                    modelBuilder.Entity<Appartment>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<Appartment>().Property("ObjectId").HasColumnName("object_id");
                    modelBuilder.Entity<Appartment>().Property("ObjectGuid").HasColumnName("object_guid");
                    modelBuilder.Entity<Appartment>().Property("ChangeId").HasColumnName("change_id");
                    modelBuilder.Entity<Appartment>().Property("Number").HasColumnName("number");
                    modelBuilder.Entity<Appartment>().Property("ApartType").HasColumnName("apart_type");
                    modelBuilder.Entity<Appartment>().Property("OperTypeId").HasColumnName("opertype_id");
                    modelBuilder.Entity<Appartment>().Property("PrevId").HasColumnName("prev_id");
                    modelBuilder.Entity<Appartment>().Property("NextId").HasColumnName("next_id");
                    modelBuilder.Entity<Appartment>().Property("UpdateDate").HasColumnName("update_date");
                    modelBuilder.Entity<Appartment>().Property("StartDate").HasColumnName("start_date");
                    modelBuilder.Entity<Appartment>().Property("EndDate").HasColumnName("end_date");
                    modelBuilder.Entity<Appartment>().Property("IsActual").HasColumnName("is_actual");
                    modelBuilder.Entity<Appartment>().Property("IsActive").HasColumnName("is_active");

                    modelBuilder.Entity<AppartmentParam>().ToTable("appartment_param");
                    modelBuilder.Entity<AppartmentParam>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<AppartmentParam>().Property("ObjectId").HasColumnName("object_id");
                    modelBuilder.Entity<AppartmentParam>().Property("ChangeId").HasColumnName("change_id");
                    modelBuilder.Entity<AppartmentParam>().Property("ChangeIdend").HasColumnName("change_idend");
                    modelBuilder.Entity<AppartmentParam>().Property("TypeId").HasColumnName("type_id");
                    modelBuilder.Entity<AppartmentParam>().Property("Value").HasColumnName("value");
                    modelBuilder.Entity<AppartmentParam>().Property("UpdateDate").HasColumnName("update_date");
                    modelBuilder.Entity<AppartmentParam>().Property("StartDate").HasColumnName("start_date");
                    modelBuilder.Entity<AppartmentParam>().Property("EndDate").HasColumnName("end_date");

                    modelBuilder.Entity<CarPlace>().ToTable("carplace");
                    modelBuilder.Entity<CarPlace>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<CarPlace>().Property("ObjectId").HasColumnName("object_id");
                    modelBuilder.Entity<CarPlace>().Property("ObjectGuid").HasColumnName("object_guid");
                    modelBuilder.Entity<CarPlace>().Property("ChangeId").HasColumnName("change_id");
                    modelBuilder.Entity<CarPlace>().Property("Number").HasColumnName("number");
                    modelBuilder.Entity<CarPlace>().Property("OperTypeId").HasColumnName("opertype_id");
                    modelBuilder.Entity<CarPlace>().Property("PrevId").HasColumnName("prev_id");
                    modelBuilder.Entity<CarPlace>().Property("NextId").HasColumnName("next_id");
                    modelBuilder.Entity<CarPlace>().Property("UpdateDate").HasColumnName("update_date");
                    modelBuilder.Entity<CarPlace>().Property("StartDate").HasColumnName("start_date");
                    modelBuilder.Entity<CarPlace>().Property("EndDate").HasColumnName("end_date");
                    modelBuilder.Entity<CarPlace>().Property("IsActual").HasColumnName("is_actual");
                    modelBuilder.Entity<CarPlace>().Property("IsActive").HasColumnName("is_active");

                    modelBuilder.Entity<CarPlacesParam>().ToTable("carplace_param");
                    modelBuilder.Entity<CarPlacesParam>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<CarPlacesParam>().Property("ObjectId").HasColumnName("object_id");
                    modelBuilder.Entity<CarPlacesParam>().Property("ChangeId").HasColumnName("change_id");
                    modelBuilder.Entity<CarPlacesParam>().Property("ChangeIdend").HasColumnName("change_idend");
                    modelBuilder.Entity<CarPlacesParam>().Property("TypeId").HasColumnName("type_id");
                    modelBuilder.Entity<CarPlacesParam>().Property("Value").HasColumnName("value");
                    modelBuilder.Entity<CarPlacesParam>().Property("UpdateDate").HasColumnName("update_date");
                    modelBuilder.Entity<CarPlacesParam>().Property("StartDate").HasColumnName("start_date");
                    modelBuilder.Entity<CarPlacesParam>().Property("EndDate").HasColumnName("end_date");

                    modelBuilder.Entity<ChangeHistory>().ToTable("change_history");
                    modelBuilder.Entity<ChangeHistory>().Property("ChangeId").HasColumnName("change_id");
                    modelBuilder.Entity<ChangeHistory>().Property("ObjectId").HasColumnName("object_id");
                    modelBuilder.Entity<ChangeHistory>().Property("AdrObjectId").HasColumnName("adrobject_id");
                    modelBuilder.Entity<ChangeHistory>().Property("OperTypeId").HasColumnName("opertype_id");
                    modelBuilder.Entity<ChangeHistory>().Property("NDocId").HasColumnName("ndoc_id");
                    modelBuilder.Entity<ChangeHistory>().Property("ChangeDate").HasColumnName("change_date");

                    modelBuilder.Entity<House>().ToTable("house");
                    modelBuilder.Entity<House>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<House>().Property("ObjectId").HasColumnName("object_id");
                    modelBuilder.Entity<House>().Property("ObjectGuid").HasColumnName("object_guid");
                    modelBuilder.Entity<House>().Property("ChangeId").HasColumnName("change_id");
                    modelBuilder.Entity<House>().Property("HouseNum").HasColumnName("housenum");
                    modelBuilder.Entity<House>().Property("HouseType").HasColumnName("housetype");
                    modelBuilder.Entity<House>().Property("OperTypeId").HasColumnName("opertype_id");
                    modelBuilder.Entity<House>().Property("PrevId").HasColumnName("prev_id");
                    modelBuilder.Entity<House>().Property("NextId").HasColumnName("next_id");
                    modelBuilder.Entity<House>().Property("UpdateDate").HasColumnName("update_date");
                    modelBuilder.Entity<House>().Property("StartDate").HasColumnName("start_date");
                    modelBuilder.Entity<House>().Property("EndDate").HasColumnName("end_date");
                    modelBuilder.Entity<House>().Property("IsActual").HasColumnName("is_actual");
                    modelBuilder.Entity<House>().Property("IsActive").HasColumnName("is_active");

                    break;
                }
        }
    }
}
