using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace ImportGeoEfc;

public static class Extensions
{
    public static string? GetTableFullName<T>(this DbSet<T> dbSet) where T : class
    {
        var dbContext = dbSet.GetService<ICurrentDbContext>().Context;
        var model = dbContext.Model;
        var entityTypes = model.GetEntityTypes();
        var entityType = entityTypes.First(t => t.ClrType == typeof(T));
        var tableNameAnnotation = entityType.GetAnnotation("Relational:TableName");
        var schemaNameAnnotation = entityType.GetAnnotation("Relational:Schema");
        string? tableName = tableNameAnnotation.Value.ToString();
        string? schemaName = schemaNameAnnotation.Value.ToString();
        return string.Join('.', schemaName, tableName);
    }
}