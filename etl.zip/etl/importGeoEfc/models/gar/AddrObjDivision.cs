using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ImportGeoEfc.models.garmodels;

public class AddrObjDivision
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.None)]
    public long Id { get; set; }
    
    public long ParentId { get; set; }
    public long ChildId { get; set; }
    public long ChangeId { get; set; }
}
