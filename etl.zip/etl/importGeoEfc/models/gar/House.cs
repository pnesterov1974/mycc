using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ImportGeoEfc.models.garmodels;

public class House
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.None)]
    public long Id { get; set; }

    public long ObjectId { get; set; }

    [StringLength(36)]
    public string ObjectGuid { get; set; }
    public long ChangeId { get; set; }
    public string? HouseNum { get; set; }
    public string? HouseType { get; set; }
    public int OperTypeId { get; set; }
    public long? PrevId { get; set; }
    public long? NextId { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
    public int IsActual { get; set; }
    public int IsActive { get; set; }
}
