using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ImportGeoEfc.models.garmodels;

public class AdmHierarchy
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.None)]
    public long Id { get; set; }

    public long ObjectId { get; set; }
    public long? ParentObjId { get; set; }
    public long ChangeId { get; set; }
    public int? RegionCode { get; set; }
    public int? AreaCode { get; set; }
    public int? CityCode { get; set; }
    public int? PlaceCode { get; set; }
    public int? PlanCode { get; set; }
    public int? StreetCode { get; set; }
    public long? PrevId { get; set; }
    public long? NextId { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
    public int IsActive { get; set; }
    public string Path { get; set; }

}
