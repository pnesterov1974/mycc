using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ImportGeoEfc.models.garmodels;

public class AppartmentParam
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.None)]
    public long Id { get; set; }

    public long ObjectId { get; set; }
    public long? ChangeId { get; set; }
    public long ChangeIdend { get; set; }
    public int TypeId { get; set; }
    
    [StringLength(8000)]
    public string Value { get; set; }
    public DateOnly UpdateDate { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
}
