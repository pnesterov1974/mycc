using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ImportGeoEfc.models.garmodels;

public class ChangeHistory
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.None)]
    public long ChangeId { get; set; }

    public long ObjectId { get; set; }
    
    [MaxLength(36)]
    public string AdrObjectId { get; set; }
    
    public int OperTypeId { get; set; }
    public long? NDocId { get; set; }
    public DateOnly ChangeDate { get; set; }
}
