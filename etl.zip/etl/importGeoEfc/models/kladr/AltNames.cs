using System.ComponentModel.DataAnnotations;

namespace ImportGeoEfc.models.kladr;

public class AltNames
{
    [Key]
    public int Id { get; set; }

    [StringLength(19)]
    public string OldCode { get; set; }

    [StringLength(19)]
    public string NewCode { get; set; }

    public int Level { get; set; }
    public DateOnly BusinessDT { get; set; } = DateOnly.MinValue;
}
