using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ImportGeoEfc.models.kladr;

public class Doma
{
    [StringLength(40)]
    public string Name { get; set; }

    [StringLength(10)]
    public string Korp { get; set; }

    [StringLength(10)]
    public string Socr { get; set; }

    [Key]
    [StringLength(19)]
    [DatabaseGenerated(DatabaseGeneratedOption.None)]
    public string Code { get; set; }

    [StringLength(6)]
    public string Index { get; set; }

    [StringLength(4)]
    public string Gninmb { get; set; }

    [StringLength(4)]
    public string Uno { get; set; }

    [StringLength(11)]
    public string Ocatd { get; set; }
    public DateOnly BusinessDT { get; set; } = DateOnly.MinValue;
}
