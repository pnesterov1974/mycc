using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ImportGeoEfc.models.kladr;

public class SocrBase
{
    [Key]
    public int Id { get; set; }

    public int Level { get; set; }

    [StringLength(10)]
    public string ScName { get; set; }

    [StringLength(29)]
    public string SocrName { get; set; }

    [StringLength(3)]
    public string KodTSt { get; set; }

    public DateOnly BusinessDT { get; set; } = DateOnly.MinValue;
}
