using Microsoft.EntityFrameworkCore;
using Shared;
using static Shared.MyLogger;
using Shared.connections;
using ImportGeoEfc.models.kladr;

namespace ImportGeoEfc;

public class KladrContext : DbContext
{
    public DbSet<SocrBase> SocrBases { get; set; } = null;
    public DbSet<AltNames> AltNames { get; set; } = null;
    public DbSet<Kladr> Kladrs { get; set; } = null;
    public DbSet<Street> Streets { get; set; } = null;
    public DbSet<Doma> Domas { get; set; } = null;
    private TargetDb tdb;

    public KladrContext(TargetDb tdb = TargetDb.pgsql)
    {
        this.tdb = tdb;
        Database.EnsureCreated();
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        // if (!ConnectionStrings.ConnectionStringsInitialized())
        // {
        //     ConnectionStrings.InitConnectionStrings(Shared.TargetDb.pgsql);
        // }

        string connStr = ConnectionStrings.GetConnectionStringByName("kladr");
        Log.Debug("Строка подключения: {connStr}", connStr);

        switch (this.tdb)
        {
            case TargetDb.mssql:
                {
                    optionsBuilder.UseSqlServer(connStr);
                    break;
                }
            case TargetDb.pgsql:
                {
                    optionsBuilder.UseNpgsql(connStr);
                    break;
                }
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        switch (this.tdb)
        {
            case TargetDb.mssql:
                {
                    modelBuilder.HasDefaultSchema("stg");

                    modelBuilder.Entity<Kladr>().ToTable("Kladr");
                    modelBuilder.Entity<Kladr>().Property("Name").HasColumnName("Name");
                    modelBuilder.Entity<Kladr>().Property("Socr").HasColumnName("Socr");
                    modelBuilder.Entity<Kladr>().Property("Code").HasColumnName("Code");
                    modelBuilder.Entity<Kladr>().Property("Index").HasColumnName("Index");
                    modelBuilder.Entity<Kladr>().Property("Gninmb").HasColumnName("Gninmb");
                    modelBuilder.Entity<Kladr>().Property("Uno").HasColumnName("Uno");
                    modelBuilder.Entity<Kladr>().Property("Ocatd").HasColumnName("Ocatd");
                    modelBuilder.Entity<Kladr>().Property("Status").HasColumnName("Status");
                    modelBuilder.Entity<Kladr>().Property("BusinessDT").HasColumnName("BusinessDT");

                    modelBuilder.Entity<Street>().ToTable("Street");
                    modelBuilder.Entity<Street>().Property("Name").HasColumnName("Name");
                    modelBuilder.Entity<Street>().Property("Socr").HasColumnName("Socr");
                    modelBuilder.Entity<Street>().Property("Code").HasColumnName("Code");
                    modelBuilder.Entity<Street>().Property("Index").HasColumnName("Index");
                    modelBuilder.Entity<Street>().Property("Gninmb").HasColumnName("Gninmb");
                    modelBuilder.Entity<Street>().Property("Uno").HasColumnName("Uno");
                    modelBuilder.Entity<Street>().Property("Ocatd").HasColumnName("Ocatd");
                    modelBuilder.Entity<Street>().Property("BusinessDT").HasColumnName("BusinessDT");

                    modelBuilder.Entity<Doma>().ToTable("Doma");
                    modelBuilder.Entity<Doma>().Property("Name").HasColumnName("Name");
                    modelBuilder.Entity<Doma>().Property("Korp").HasColumnName("Korp");
                    modelBuilder.Entity<Doma>().Property("Socr").HasColumnName("Socr");
                    modelBuilder.Entity<Doma>().Property("Code").HasColumnName("Code");
                    modelBuilder.Entity<Doma>().Property("Index").HasColumnName("Index");
                    modelBuilder.Entity<Doma>().Property("Gninmb").HasColumnName("Gninmb");
                    modelBuilder.Entity<Doma>().Property("Uno").HasColumnName("Uno");
                    modelBuilder.Entity<Doma>().Property("Ocatd").HasColumnName("Ocatd");
                    modelBuilder.Entity<Doma>().Property("BusinessDT").HasColumnName("BusinessDT");

                    modelBuilder.Entity<AltNames>().ToTable("AltNames");
                    modelBuilder.Entity<AltNames>().Property("Id").HasColumnName("Id");
                    modelBuilder.Entity<AltNames>().Property("OldCode").HasColumnName("OldCode");
                    modelBuilder.Entity<AltNames>().Property("NewCode").HasColumnName("NewCode");
                    modelBuilder.Entity<AltNames>().Property("Level").HasColumnName("Level");
                    modelBuilder.Entity<AltNames>().Property("BusinessDT").HasColumnName("BusinessDT");

                    modelBuilder.Entity<SocrBase>().ToTable("SocrBase");
                    modelBuilder.Entity<SocrBase>().Property("Id").HasColumnName("Id");
                    modelBuilder.Entity<SocrBase>().Property("Level").HasColumnName("Level");
                    modelBuilder.Entity<SocrBase>().Property("ScName").HasColumnName("ScName");
                    modelBuilder.Entity<SocrBase>().Property("SocrName").HasColumnName("SocrName");
                    modelBuilder.Entity<SocrBase>().Property("KodTSt").HasColumnName("KodTSt");
                    modelBuilder.Entity<SocrBase>().Property("BusinessDT").HasColumnName("BusinessDT");

                    break;
                }
            case TargetDb.pgsql:
                {
                    modelBuilder.HasDefaultSchema("stg");

                    modelBuilder.Entity<Kladr>().ToTable("kladr");
                    modelBuilder.Entity<Kladr>().Property("Name").HasColumnName("name");
                    modelBuilder.Entity<Kladr>().Property("Socr").HasColumnName("socr");
                    modelBuilder.Entity<Kladr>().Property("Code").HasColumnName("code");
                    modelBuilder.Entity<Kladr>().Property("Index").HasColumnName("index");
                    modelBuilder.Entity<Kladr>().Property("Gninmb").HasColumnName("gninmb");
                    modelBuilder.Entity<Kladr>().Property("Uno").HasColumnName("uno");
                    modelBuilder.Entity<Kladr>().Property("Ocatd").HasColumnName("ocatd");
                    modelBuilder.Entity<Kladr>().Property("Status").HasColumnName("status");
                    modelBuilder.Entity<Kladr>().Property("BusinessDT").HasColumnName("business_dt");

                    modelBuilder.Entity<Street>().ToTable("street");
                    modelBuilder.Entity<Street>().Property("Name").HasColumnName("name");
                    modelBuilder.Entity<Street>().Property("Socr").HasColumnName("socr");
                    modelBuilder.Entity<Street>().Property("Code").HasColumnName("code");
                    modelBuilder.Entity<Street>().Property("Index").HasColumnName("index");
                    modelBuilder.Entity<Street>().Property("Gninmb").HasColumnName("gninmb");
                    modelBuilder.Entity<Street>().Property("Uno").HasColumnName("uno");
                    modelBuilder.Entity<Street>().Property("Ocatd").HasColumnName("ocatd");
                    modelBuilder.Entity<Street>().Property("BusinessDT").HasColumnName("business_dt");

                    modelBuilder.Entity<Doma>().ToTable("doma");
                    modelBuilder.Entity<Doma>().Property("Name").HasColumnName("name");
                    modelBuilder.Entity<Doma>().Property("Korp").HasColumnName("korp");
                    modelBuilder.Entity<Doma>().Property("Socr").HasColumnName("socr");
                    modelBuilder.Entity<Doma>().Property("Code").HasColumnName("code");
                    modelBuilder.Entity<Doma>().Property("Index").HasColumnName("index");
                    modelBuilder.Entity<Doma>().Property("Gninmb").HasColumnName("gninmb");
                    modelBuilder.Entity<Doma>().Property("Uno").HasColumnName("uno");
                    modelBuilder.Entity<Doma>().Property("Ocatd").HasColumnName("ocatd");
                    modelBuilder.Entity<Doma>().Property("BusinessDT").HasColumnName("business_dt");

                    modelBuilder.Entity<AltNames>().ToTable("altnames");
                    modelBuilder.Entity<AltNames>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<AltNames>().Property("OldCode").HasColumnName("oldcode");
                    modelBuilder.Entity<AltNames>().Property("NewCode").HasColumnName("newcode");
                    modelBuilder.Entity<AltNames>().Property("Level").HasColumnName("level");
                    modelBuilder.Entity<AltNames>().Property("BusinessDT").HasColumnName("business_dt");

                    modelBuilder.Entity<SocrBase>().ToTable("socrbase");
                    modelBuilder.Entity<SocrBase>().Property("Id").HasColumnName("id");
                    modelBuilder.Entity<SocrBase>().Property("Level").HasColumnName("level");
                    modelBuilder.Entity<SocrBase>().Property("ScName").HasColumnName("scname");
                    modelBuilder.Entity<SocrBase>().Property("SocrName").HasColumnName("socrname");
                    modelBuilder.Entity<SocrBase>().Property("KodTSt").HasColumnName("kod_t_st");
                    modelBuilder.Entity<SocrBase>().Property("BusinessDT").HasColumnName("business_dt");

                    break;
                }
        }
    }
}