namespace Dataread.pgsql
{
    public class KladrReadModelsCatalog
    {
        public List<IReadModel> Models = new List<IReadModel>()
        {
            new SocrBaseJustImportedModel(),
            new AltNamesJustImportedModel(),
            new KladrJustImportedModel(),
            new StreetJustImportedModel(),
            new DomaJustImportedModel(),
        };
    }

    public class SocrBaseJustImportedModel : ReadModelBase, IReadModel
    {
        public override string ModelName { get; set; } = "SocrBase_justImported";
        public override string SourceDbName { get; set; } = "kladrRaw";
        //public override List<string> SourceKeyFilelds { get; set; } = new List<string>() {"[KladrCode]"};
        public override string SourceSql { get; set; } = """
            SELECT
                level,
                scname,
                socrname,
                kod_t_st
            FROM
                kladr.socrbase
            """;
    }

    public class AltNamesJustImportedModel : ReadModelBase, IReadModel
    {
        public override string ModelName { get; set; } = "AltNames_justImported";
        public override string SourceDbName { get; set; } = "kladrRaw";
        //public override List<string> SourceKeyFilelds { get; set; } = new List<string>() {"[KladrCode]"};
        public override string SourceSql { get; set; } = """
            SELECT
                oldcode,
                newcode,
                level
            FROM
                kladr.altnames
            """;
    }

    public class KladrJustImportedModel : ReadModelBase, IReadModel
    {
        public override string ModelName { get; set; } = "Kladr_justImported";
        public override string SourceDbName { get; set; } = "kladrRaw";
        //public override List<string> SourceKeyFilelds { get; set; } = new List<string>() {"[KladrCode]"};
        public override string SourceSql { get; set; } = """
            SELECT
                name,
                korp,
                socr,
                code,
                index,
                gninmb,
                uno,
                ocatd,
                status
            FROM
                kladr.kladr
            """;
    }

    public class StreetJustImportedModel : ReadModelBase, IReadModel
    {
        public override string ModelName { get; set; } = "Street_justImported";
        public override string SourceDbName { get; set; } = "kladrRaw";
        //public override List<string> SourceKeyFilelds { get; set; } = new List<string>() {"[KladrCode]"};
        public override string SourceSql { get; set; } = """
            SELECT
                name,
                socr,
                code,
                index,
                gninmb,
                uno,
                ocatd
            FROM
                kladr.street
            """;
    }

    public class DomaJustImportedModel : ReadModelBase, IReadModel
    {
        public override string ModelName { get; set; } = "Doma_justImported";
        public override string SourceDbName { get; set; } = "kladrRaw";
        //public override List<string> SourceKeyFilelds { get; set; } = new List<string>() {"[KladrCode]"};
        public override string SourceSql { get; set; } = """
            SELECT
                name,
                korp,
                socr,
                code,
                index,
                gninmb,
                uno,
                ocatd
            FROM
                kladr.doma
            """;
    }
}
