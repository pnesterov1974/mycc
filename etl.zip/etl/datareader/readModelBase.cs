namespace Datareader
{
    public interface IReadModel
    {
        string ModelName { get; set; }
        string SourceDbName { get; set; }
        string SourceSql { get; set; }
    }

    public class ReadModelBase : IReadModel
    {
        public virtual string ModelName { get; set; } = string.Empty;
        public virtual string SourceDbName { get; set; } = string.Empty;
        public virtual string SourceSql { get; set; } = string.Empty;
    }

}
