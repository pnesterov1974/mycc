﻿namespace techdbMsSql;

public class Class1
{

}
