using System.Data;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Datamech.pgsql
{
    public class Target : SourceTargetBase
    {
        public string? Name
        {
            get => this.parentModel?.EtlModel?.TargetName;
        }
        public List<string> KeyFields
        {
            get => this.parentModel.EtlModel.SourceKeyFilelds;
        }
        public string SchemaName
        {
            get => this.parentModel.EtlModel.TargetSchemaName;
        }
        public string TableName
        {
            get => this.parentModel.EtlModel.TargetTableName;
        }
        public string FullName
        {
            get => string.Join('.', this.SchemaName, this.TableName);
        }
        private bool isObjectExists;
        private RunModel parentModel;

        // Принимает ссылку на RunModel. Через нее получает Доступ к EtlModel-параметрам про Target
        // Проводит операции с target. IfExists, Drop, Create
        // Запускает RunInsertInto ???? - наверное нужно переместить в RunMdel.
        public Target(RunModel parentModel)
        {
            this.parentModel = parentModel;
            Connections conns = new Connections(TargetDb.pgsql);
            this.ConnectionString = conns.GetConnectionStringByName(this.Name);
            this.connectionOk = this.tryPgSqlDbConnection();
        }

        public void ReadIfObjectExists()
        {
            string checkSql = this.parentModel.Sqls.GetIsObjectExistsSql();
            Log.Information("Проверка, существует ли уже объект {t}", this.FullName);
            Log.Debug("checkSql:\n{checkSql}", checkSql);
            using (NpgsqlConnection conn = new NpgsqlConnection(this.ConnectionString))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(checkSql, conn))
                {
                    try
                    {
                        conn.Open();
                        var result = cmd.ExecuteScalar();
                        int iresult = (int)result;
                        Log.Debug("Результат проверки: result {r}", iresult);
                        if (iresult == 1)
                        {
                            Log.Information("Объект {t} существует", this.FullName);
                            this.isObjectExists = true;
                        }
                        else
                        {
                            Log.Information("Объект {t} не существует", this.FullName);
                            this.isObjectExists = false;
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Ощибка проверки существования объекта {t}\n", this.FullName);
                        Log.Debug("{errmes}", ex.Message);
                        this.isObjectExists = false;
                    }
                }
            }
        }

        public void TouchObject(bool deleteIfExists)
        {
            if (this.isObjectExists)
            {
                if (deleteIfExists)
                {
                    this.dropTable();
                    this.createTable();
                }
            }
            else
            {
                this.createTable();
            }
        }

        private void dropTable()
        {
            string dropSql = this.parentModel.Sqls.GetDropTableSql();
            Log.Information("Удаление таблицы {t}", this.FullName);
            Log.Debug("checkSql:\n{checkSql}", dropSql);
            using (NpgsqlConnection conn = new NpgsqlConnection(this.ConnectionString))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(dropSql, conn))
                {
                    try
                    {
                        conn.Open();
                        int result = cmd.ExecuteNonQuery();
                        Log.Information("Объект {t} успешно удален", this.FullName);
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Ощибка удаления объекта {t}\n", this.FullName);
                        Log.Debug("{errmes}", ex.Message);
                    }
                }
            }
        }

        private void createTable()
        {
            string createSql = this.parentModel.Sqls.GetCreateTableSql();
            Log.Information("Создание таблицы {t}", this.FullName);
            Log.Debug("createSql:\n{createSql}", createSql);
            using (NpgsqlConnection conn = new NpgsqlConnection(this.ConnectionString))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(createSql, conn))
                {
                    try
                    {
                        conn.Open();
                        int result = cmd.ExecuteNonQuery();
                        Log.Information("Объект {t} успешно создан", this.FullName);
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Ощибка создания объекта {t}\n", this.FullName);
                        Log.Debug("{errmes}", ex.Message);
                    }
                }
            }
        }

        public int SaveBatch(DataTable batchData)
        {
            //string insertSql = this.parentModel.Sqls.GetInsertIntoValuesSql();
            //DbStru ds = this.parentModel.Source.Dbs;
            // ToDo TRANSACTION
            using NpgsqlConnection conn = new NpgsqlConnection(this.ConnectionString);
            conn.Open();

            using NpgsqlBatch batch = new NpgsqlBatch(conn);

            foreach (DataRow r in batchData.Rows)
            {
                NpgsqlBatchCommand bcmd = new NpgsqlBatchCommand(this.parentModel.Sqls.GetInsertIntoValuesSql());

                foreach (DataColumn c in batchData.Columns)
                {
                    bcmd.Parameters.AddWithValue(string.Concat('@', c.ColumnName), r[c.ColumnName]);
                }
                batch.BatchCommands.Add(bcmd);
            }
            try
            {
                int recs = batch.ExecuteNonQuery();
                return recs;
            }
            catch (Exception ex)
            {
                Log.Information("Ощибка загрузки пачки в {target}", this.FullName);
                Log.Error("\n {errorMsq}", ex.Message);
                return 0;
            }
        }
    }
}