using System.Text;

namespace Datamech.pgsql
{
    // Принимает ссылку на Source и Target
    // В конструктуре расчитывает DbStru dbs
    // чекрез public-методы возвращает sql-запросы в зависимости от механизма отбработки модели
    public class Sqls
    {
        private RunEtlModel parentModel;
        private RunEtlModel ParentModel
        {
            get
            {
                if (this.parentModel != null)
                {
                    return this.parentModel;
                }
                else
                {
                    throw new NullReferenceException("etlModelSource.parentModel: Отсутствует указатель на родительский объект TunModel parentModel");
                }
            }
        }
        private Source source 
        { 
            get => this.parentModel.Source;
        }
        private Target target 
        { 
            get => this.parentModel.Target;
        }

        public Sqls(RunEtlModel parentModel)
        {
            this.parentModel = parentModel;
        }

        public string GetCreateTableSql()
        {
            List<string> sqlRows = new List<string>();
            foreach (var kv in this.source.Dbs.Rows)
            {
                string colName = kv.Key;
                DbStruRow dbr = kv.Value;
                string colType = dbr.DataTypeName;
                string item = string.Concat(colName, ' ', colType, ' ', "null"); // null vs not null
                sqlRows.Add(item);
            }
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"CREATE TABLE {this.target.FullName} (");
            sb.AppendLine(string.Join(",\n", sqlRows));
            sb.AppendLine(");\n");
            return sb.ToString();
        }

        public string GetInsertIntoValuesSql()
        {
            List<string> cols = new List<string>();
            List<string> paramValues = new List<string>();

            foreach (var k in this.source.Dbs.Rows.Keys)
            {
                cols.Add(k);
                paramValues.Add(string.Concat("@", k));
            }

            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"INSERT INTO {this.target.FullName} (");
            sb.AppendLine(string.Join(", ", cols));
            sb.AppendLine(") VALUES (");
            sb.AppendLine(string.Join(", ", paramValues));
            sb.AppendLine(");");
            return sb.ToString();
        }

        public string GetInsertIntoSql()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"INSERT INTO {this.target.FullName}");
            sb.AppendLine(this.source.SelectSql);
            sb.AppendLine("\n");
            return sb.ToString();
        }

        public string GetDropTableSql()
        {
            string fullTargetName = string.Concat(this.target.SchemaName, '.', this.target.TableName);
            return $"DROP TABLE {fullTargetName};";
        }

        public string GetIsObjectExistsSql()
        {
            string fullTargetName = string.Concat(this.target.SchemaName, '.', this.target.TableName);
            return $"""
            SELECT COUNT(1)::INT FROM information_schema.tables 
                WHERE table_schema = '{this.target.SchemaName}'
                      AND table_name = '{this.target.TableName}';
            """;
        }

        public string GetSelectBatchSql()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("WITH data AS (");
            string strKeyFields = string.Join(", ", this.source.KeyFields);
            sb.AppendLine($"SELECT rnn = ROW_NUMBER() OVER (ORDER BY {strKeyFields}),");
            sb.AppendLine("        q.*");
            sb.AppendLine("FROM (");
            sb.AppendLine(this.source.SelectSql);
            sb.AppendLine($"      ) q");
            sb.AppendLine(")");
            sb.AppendLine("SELECT * FROM data");
            sb.AppendLine("WHERE rnn BETWEEN @rnnFrom AND @rnnTo;");
            return sb.ToString();
        }

        public string GetSelectBatchSqlBouded(int rnnFrom, int rnnTo)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("WITH data AS (");
            string strKeyFields = string.Join(", ", this.source.KeyFields);
            sb.AppendLine($"SELECT ROW_NUMBER() OVER (ORDER BY {strKeyFields}) as rnn,");
            sb.AppendLine("        q.*");
            sb.AppendLine("FROM (");
            sb.AppendLine(this.source.SelectSql);
            sb.AppendLine($"      ) q");
            sb.AppendLine(")");
            sb.AppendLine("SELECT * FROM data");
            sb.AppendLine($"WHERE rnn BETWEEN {rnnFrom} AND {rnnTo}");
            return sb.ToString();
        }

        public string GetSelectPageSql(int pageNum, int pageRecordSize = 10000)
        {
            int offsetRecords = (pageNum - 1) * pageRecordSize;
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("WITH data AS (");
            sb.AppendLine(this.source.SelectSql);
            sb.AppendLine(")");
            sb.AppendLine("SELECT * FROM data");
            sb.AppendLine($"LIMIT {pageRecordSize} OFFSET {offsetRecords};");
            return sb.ToString();
        }

        public string GetCreateViewSql()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"CREATE VIEW {this.target.FullName} AS");
            sb.AppendLine(this.source.SelectSql);
            return sb.ToString();
        }
    }
}
