//using Datamech.pgsql.etlmodels;
namespace Datamech.pgsql.etlmodels
{
    public class KladrModelsCatalog
    {
        public List<IEtlModel> Models = new List<IEtlModel>()
        {
            new Kladr1Model(),
            new Street1Model(),
            new Doma1Model()
        };
    }
}