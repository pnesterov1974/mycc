namespace Datamech.pgsql.etlmodels
{
public class Kladr1Model : EtlModelBase, IEtlModel
    {
        public override string ModelName { get; set; } = "Kladr1";
        public override string SourceDbName { get; set; } = "kladrStage";
        public override string TargetDbName { get; set; } = "kladrWork";
        public override string TargetTableName { get; set; } = "kladr_1";
        public override string TargetSchemaName { get; set; } = "ods";
        public override List<string> SourceKeyFilelds { get; set; } = new List<string>() {"kladr_code"};
        public override string SourceSql { get; set; } = """
            SELECT
            code AS kladr_code,
            LEFT(code, 11) AS kladr_sub_code,
            LEFT(code, 2) AS area_code,
            SUBSTRING(code, 3, 3) AS district_code,
            SUBSTRING(code, 6, 3) AS city_code,
            SUBSTRING(code, 9, 3) AS town_code,
            CASE
                WHEN SUBSTRING(code, 9, 3) <> '000' THEN 4
                ELSE CASE
                        WHEN SUBSTRING(code, 6, 3) <> '000' THEN 3
                        ELSE CASE
                                WHEN SUBSTRING(code, 3, 3) <> '000' THEN 2
                                ELSE 1
                            END
                     END
            END AS kladr_level,
            RIGHT(code, 2) AS actuality_status,
            name AS kladr_name,
            socr AS kladr_socr,
            index AS kladr_index,
            gninmb AS kladr_gninmb,
            uno AS kladr_uno,
            ocatd AS kladr_ocatd,
            status AS kladr_status
        FROM kladr.kladr
        WHERE (RIGHT(code, 2) = '00')
        """;
    }
}