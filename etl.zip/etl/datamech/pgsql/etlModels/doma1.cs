namespace Datamech.pgsql.etlmodels
{
public class Doma1Model : EtlModelBase, IEtlModel
    {
        public override string ModelName { get; set; } = "Doma1";
        public override string SourceDbName { get; set; } = "kladrStage";
        public override string TargetDbName { get; set; } = "kladrWork";
        public override string TargetTableName { get; set; } = "doma_1";
        public override string TargetSchemaName { get; set; } = "ods";
        public override List<string> SourceKeyFilelds { get; set; } = new List<string>() {"kladr_code"};
        public override string SourceSql { get; set; } = """
            SELECT code AS kladr_code,
                LEFT(code, 11) AS kladr_subcode,
                LEFT(code, 2 ) AS area_codee,
                SUBSTRING(code,  3, 3) AS district_code,
                SUBSTRING(code,  6, 3) AS city_code,
                SUBSTRING(code,  9, 3) AS town_code,
                SUBSTRING(code, 12, 4) AS street_code,
                SUBSTRING(code, 16, 4) AS bld_code,
                6 AS kladr_level, 
                name AS kladr_name,
                socr AS kladr_socr,
                index AS kladr_index,
                gninmb AS kladr_gninmb,
                uno AS kladr_uno,
                ocatd AS kladr_ocatd
            FROM kladr.doma
        """;
    }
}
