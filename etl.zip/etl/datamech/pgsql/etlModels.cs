using Newtonsoft.Json;
//using System.Xml.Serialization;
using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;

// Технические поля:
//      Код источника
//      Current dttm
//      

namespace Datamech.pgsql
{
    public interface IEtlModel
    {
        string ModelName { get; set; }
        string SourceName { get; set; }
        string TargetName { get; set; }
        string SourceSchema { get; set; }
        string SourceSql { get; set; }
        public List<string> SourceKeyFilelds { get; set; }
        string TargetTableName { get; set; }
        string TargetSchemaName { get; set; }
        string SerializedJsonFileName { get; }
        string SerializedYamlFileName { get; }
        string SerializedXmlFileName { get; }
        string TargetTableFullName { get; }
    }

    public class EtlModelBase
    {
        public virtual string ModelName { get; set; } = string.Empty;
        public virtual string TargetTableName { get; set; } = string.Empty;
        public virtual string TargetSchemaName { get; set; } = string.Empty;
        public List<string> SourceKeyFilelds { get; set; }
        public string SerializedJsonFileName
        {
            get => Path.Combine(Directory.GetCurrentDirectory(), "models", String.Join('.', this.ModelName, "json"));
        }
        public string SerializedYamlFileName
        {
            get => Path.Combine(Directory.GetCurrentDirectory(), "models", String.Join('.', this.ModelName, "yaml"));
        }
        public string SerializedXmlFileName
        {
            get => Path.Combine(Directory.GetCurrentDirectory(), "models", String.Join('.', this.ModelName, "xml"));
        }
        public string TargetTableFullName
        {
            get => string.Join('.', this.TargetSchemaName, this.TargetTableName);
        }
    }

    public class EmptyModel : EtlModelBase, IEtlModel
    {
        public override string ModelName { get; set; } = string.Empty;
        public string SourceName { get; set; } = string.Empty;
        public string TargetName { get; set; } = string.Empty;
        public string SourceSchema { get; set; } = string.Empty;
        public string SourceSql { get; set; } = string.Empty;
        public override string TargetTableName { get; set; } = string.Empty;
        public override string TargetSchemaName { get; set; } = string.Empty;
    }

    public class Kladr1Model : EtlModelBase, IEtlModel
    {
        public override string ModelName { get; set; } = "Kladr1";
        public string SourceName { get; set; } = "kladrRaw";
        public string TargetName { get; set; } = "kladrWork";
        public string SourceSchema { get; set; } = "kladr";
        public override string TargetTableName { get; set; } = "kladr_1";
        public override string TargetSchemaName { get; set; } = "kladr";
        public List<string> SourceKeyFilelds { get; set; } = new List<string>() {"kladr_code"};
        public string SourceSql { get; set; } = """
            SELECT
            code AS kladr_code,
            LEFT(code, 11) AS kladr_sub_code,
            LEFT(code, 2) AS area_code,
            SUBSTRING(code, 3, 3) AS district_code,
            SUBSTRING(code, 6, 3) AS city_code,
            SUBSTRING(code, 9, 3) AS town_code,
            CASE
                WHEN SUBSTRING(code, 9, 3) <> '000' THEN 4
                ELSE CASE
                        WHEN SUBSTRING(code, 6, 3) <> '000' THEN 3
                        ELSE CASE
                                WHEN SUBSTRING(code, 3, 3) <> '000' THEN 2
                                ELSE 1
                            END
                     END
            END AS kladr_level,
            RIGHT(code, 2) AS actuality_status,
            name AS kladr_name,
            socr AS kladr_socr,
            index AS kladr_index,
            gninmb AS kladr_gninmb,
            uno AS kladr_uno,
            ocatd AS kladr_ocatd,
            status AS kladr_status
        FROM kladr.kladr
        WHERE (RIGHT(code, 2) = '00')
        """;
    }

    public class Street1Model : EtlModelBase, IEtlModel
    {
        public override string ModelName { get; set; } = "Street1";
        public string SourceName { get; set; } = "kladrRaw";
        public string TargetName { get; set; } = "kladrWork";
        public string SourceSchema { get; set; } = "kladr";
        public override string TargetTableName { get; set; } = "street_1";
        public override string TargetSchemaName { get; set; } = "kladr";
        public List<string> SourceKeyFilelds { get; set; } = new List<string>() {"kladr_code"};
        public string SourceSql { get; set; } = """
            SELECT code AS kladr_code,
                LEFT(code, 11) AS kladr_subcode,
                LEFT(code, 2) AS area_code,
                SUBSTRING(code, 3, 3) AS district_code,
                SUBSTRING(code, 6, 3) AS city_code,
                SUBSTRING(code, 9, 3) AS town_code,
                SUBSTRING(code, 12, 4) AS street_code,
                RIGHT(code, 2) AS actuality_status,
                5 AS kladr_level,
                name AS kladr_name,
                socr AS kladr_socr,
                index AS kladr_index,
                gninmb AS kladr_gninmd,
                uno AS kladr_uno,
                ocatd AS kladr_okatd
            FROM kladr.street
            WHERE (RIGHT(code, 2) = '00')
        """;
    }

    public class Doma1Model : EtlModelBase, IEtlModel
    {
        public override string ModelName { get; set; } = "Doma1";
        public string SourceName { get; set; } = "kladrRaw";
        public string TargetName { get; set; } = "kladrWork";
        public string SourceSchema { get; set; } = "kladr";
        public override string TargetTableName { get; set; } = "doma_1";
        public override string TargetSchemaName { get; set; } = "kladr";
        public List<string> SourceKeyFilelds { get; set; } = new List<string>() {"kladr_code"};
        public string SourceSql { get; set; } = """
            SELECT code AS kladr_code,
                LEFT(code, 11) AS kladr_subcode,
                LEFT(code, 2 ) AS area_codee,
                SUBSTRING(code,  3, 3) AS district_code,
                SUBSTRING(code,  6, 3) AS city_code,
                SUBSTRING(code,  9, 3) AS town_code,
                SUBSTRING(code, 12, 4) AS street_code,
                SUBSTRING(code, 16, 4) AS bld_code,
                6 AS kladr_level, 
                name AS kladr_name,
                socr AS kladr_socr,
                index AS kladr_index,
                gninmb AS kladr_gninmb,
                uno AS kladr_uno,
                ocatd AS kladr_ocatd
            FROM kladr.doma
        """;
    }

    public class Serializator
    {
        public IEtlModel EtlModel;
        public Serializator(IEtlModel etlModel) => this.EtlModel = etlModel;
        public void SerializeToJson()
        {
            string serialized = JsonConvert.SerializeObject(this.EtlModel, Formatting.Indented);
            File.WriteAllText(this.EtlModel.SerializedJsonFileName, serialized);
        }
        public void SerializeToYaml()
        {
            var serializer = new SerializerBuilder()
                .WithNamingConvention(CamelCaseNamingConvention.Instance)
                .Build();
            var yaml = serializer.Serialize(this.EtlModel);
            File.WriteAllText(this.EtlModel.SerializedYamlFileName, yaml);
        }
        public void SerializeToXml()
        {
            //XmlSerializer xmlSerializer = new XmlSerializer(typeof(this.EtlModel));
            //using (FileStream fs = new FileStream(this.EtlModel.SerializedXmlFileName, FileMode.OpenOrCreate))
            //{
            //    xmlSerializer.Serialize(fs, this.EtlModel);
            //    Console.WriteLine("Object model1 has been serialized in XML");
            //}
            ;
        }
    }
}
