namespace Datamech.mssql.etlmodels
{

    // push_model_list
    // pull_model_list
    // modelname_unique

    public class KladrModelsCatalog
    {
        public List<IEtlModel> Models = new List<IEtlModel>()
        {
            new Kladr1Model(),
            new Street1Model(),
            new Doma1Model()
        };
    }
}