namespace Datamech.mssql.etlmodels
{
    public class Street1Model : EtlModelBase, IEtlModel
    {
        public override string ModelName { get; set; } = "Street1";
        public override string SourceDbName { get; set; } = "kladrRaw";
        public override string TargetDbName { get; set; } = "kladrWork";
        public override string TargetTableName { get; set; } = "[street_1]";
        public override string TargetSchemaName { get; set; } = "dbo";
        public override List<string> SourceKeyFilelds { get; set; } = new List<string>() { "[KladrCode]" };
        public override string SourceSql { get; set; } = """
            SELECT s.[code] AS [KladrCode],
               LEFT(s.[code], 11) AS [KladrSubCode],
               LEFT(s.[code], 2) AS [AreaCode],
               SUBSTRING(s.[code], 3, 3) AS [DistrictCode],
               SUBSTRING(s.[code], 6, 3) AS [CityCode],
               SUBSTRING(s.[code], 9, 3) AS [TownCode],
               SUBSTRING(s.[code], 12, 4) AS [StreetCode],
               RIGHT(s.[code], 2) AS [ActualityStatus],
               5 AS [KladrLevel],
               s.[name] AS [KladrName],
               s.[socr] AS [KladrSocr],
               s.[index] AS [KladrIndex],
               s.[gninmb] AS [KladrGninmd],
               s.[uno] AS [KladrUno],
               s.[ocatd] AS [KLadrOkatd]
        FROM kladr.[Street] s
        WHERE (RIGHT(s.[code], 2) = N'00')
        """;
    }
}