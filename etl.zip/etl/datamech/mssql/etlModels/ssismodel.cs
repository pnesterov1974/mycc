namespace Datamech.mssql.etlmodels
{
    public class ssisModel : EtlModelBase, IEtlModel
    {
        public override string ModelName { get; set; } = "ssisModel";
        public override string SourceDbName { get; set; } = "dwh";
        public override string TargetDbName { get; set; } = "etlSsisP02";
        public override string TargetTableName { get; set; } = "[dwh_event_log]";
        public override string TargetSchemaName { get; set; } = "dbo";
        public override List<string> SourceKeyFilelds { get; set; } = new List<string>() { "[execution_id]" };
        public override string SourceSql { get; set; } = """
            SELECT gd.[msg],
                gd.[event_category_code],
                gd.[event_dttm],
                gd.[log_table],
                gd.[log_pk],
                gd.[log_solved_flag],
                gd.[suser],
                gd.[date_change],
                el.[control_process_id],
                cpi.[execution_id]
            FROM [DWH].[monitoring].[grafana_dashboard] gd
            LEFT JOIN meta.[event_log] el ON 
                el.[event_log_id] = gd.[log_pk]
            LEFT JOIN meta.[control_process_instance] cpi ON
                cpi.[control_process_id] = el.[control_process_id]
            WHERE CAST(gd.[event_dttm] AS DATE) = CAST(GETDATE() AS DATE)
                  AND (gd.[log_table] = 'event_log')
        """;
    }
}