namespace Datamech.mssql.etlmodels
{
public class Kladr1Model : EtlModelBase, IEtlModel
    {
        public override string ModelName { get; set; } = "Kladr1";
        public override string SourceDbName { get; set; } = "kladrRaw";
        public override string TargetDbName { get; set; } = "kladrWork";
        public override string TargetTableName { get; set; } = "[kladr_1]";
        public override string TargetSchemaName { get; set; } = "dbo";
        public override List<string> SourceKeyFilelds { get; set; } = new List<string>() {"[KladrCode]"};
        public override string SourceSql { get; set; } = """
            SELECT k.[code] AS [KladrCode],
                   LEFT(k.[code], 11) AS [KladrSubCode],
                   LEFT(k.[Code], 2) AS [AreaCode],
                   SUBSTRING(k.[code], 3, 3) AS [DistrictCode],
                   SUBSTRING(k.[code], 6, 3) AS [CityCode],
                   SUBSTRING(k.[code], 9, 3) AS [TownCode],
                   IIF(SUBSTRING(k.[code], 9, 3) <> N'000', 4,
                       (IIF(SUBSTRING(k.[code], 6, 3) <> N'000', 3,
                           (IIF(SUBSTRING(k.[code], 3, 3) <> N'000', 2, 1))
                        )
                      )
                    ) AS [KladrLevel],
                    RIGHT(k.[code], 2) AS [ActualityStatus],
                    k.[name] AS [KladrName],
                    k.[socr] AS [KladrSocr],
                    k.[index] AS [KladrIndex],
                    k.[gninmb] AS [KladrGninmb],
                    k.[uno] AS [KladrUno],
                    k.[ocatd] AS [KladrOcatd],
                    k.[status] AS [KladrStatus]
        FROM kladr.[kladr] k
        WHERE (RIGHT(k.[code], 2) = N'00')
        """;
    }
}