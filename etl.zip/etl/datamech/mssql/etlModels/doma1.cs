namespace Datamech.mssql.etlmodels
{

    // push_model_list
    // pull_model_list
    // modelname_unique

    public class Doma1Model : EtlModelBase, IEtlModel
    {
        public override string ModelName { get; set; } = "Doma1";
        public override string SourceDbName { get; set; } = "kladrRaw";
        public override string TargetDbName { get; set; } = "kladrWork";
        public override string TargetTableName { get; set; } = "[doma_1]";
        public override string TargetSchemaName { get; set; } = "dbo";
        public override List<string> SourceKeyFilelds { get; set; } = new List<string>() { "[KladrCode]" };
        public override string SourceSql { get; set; } = """
            SELECT d.[code] AS [KladrCode],
               LEFT(d.[code], 11) AS [KladrSubCode],
               LEFT(d.[code], 2) AS [AreaCodee],
               SUBSTRING(d.[code],  3, 3) AS [DistrictCode],
               SUBSTRING(d.[code],  6, 3) AS [CitryCode],
               SUBSTRING(d.[code],  9, 3) AS [TownCode],
               SUBSTRING(d.[code], 12, 4) AS [StreetCode],
               SUBSTRING(d.[code], 16, 4) AS [BldCode],
               6 AS [KladrLevel], 
               d.[name] AS [KladrName],
               d.[socr] AS [KladrSocr],
               d.[index] AS [KladrIndex],
               d.[gninmb] AS [KladrGninmb],
               d.[uno] AS [KladrUno],
               d.[ocatd] AS [KladrOcatd]
        FROM kladr.[Doma] d
        """;
    }
}