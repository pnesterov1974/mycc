WITH [selectOds] AS (
    SELECT 
        [CODE], [NAME], [SOCR], [INDEX], [GNINMB], [UNO], [OCATD], [STATUS],
        [DTTM_FROM], [DTTM_TO], [IS_ACTIVE], [IS_DELETED]
    FROM ods.[KLADR]
    WHERE [IS_ACTIVE] = 1
),
[selectStg] AS (
    SELECT [CODE], [NAME], [SOCR], [INDEX], [GNINMB], [UNO], [OCATD], [STATUS], [BusinessDT]
    FROM stg.[KLADR]
),
-- новые
[forInsert] AS (
    SELECT stg.[CODE], stg.[NAME], stg.[SOCR], stg.[INDEX], stg.[GNINMB], stg.[UNO], stg.[OCATD], stg.[STATUS],
        [DTTM_FROM] = CAST(stg.[BusinessDT] AS DATETIME),
        [DTTM_TO] = CAST("2999-01-01" AS DATETIME),
        [IS_ACTIVE] = 1,
        [IS_DELETED] = 0       
    FROM [selectStg] stg
    LEFT JOIN [selectOds] ods ON ods.[CODE] = stg.[CODE]
    WHERE ods.[CODE] IS NULL
),
[forDelete] AS (
    SELECT ods.[CODE]--, stg.[NAME], stg.[SOCR], stg.[INDEX], stg.[GNINMB], stg.[UNO], stg.[OCATD], stg.[STATUS],
    FROM selectStg
    RIGHT JOIN [selectOds] ods ON ods.[CODE] = stg.[CODE]
    WHERE stg.[CODE] OS NULL
), -- при удалении UPDATE  is_deleted = 1, as_actual = 0, DTTN_FROM = CAST(stg.[BusinessDT] AS DATETIME),
[forUpdateBase] AS (
    SELECT stg.[CODE] AS stg_CODE, ods.[CODE] AS ods_CODE,
           stg.[NAME] AS stg_NAME, ods.[NAME] AS ods_CODE,
           stg.[SOCR] AS stg_SOCR, ods.[SOCR] AS ods_CODE,
           stg.[INDEX] AS stg_INDEX, ods.[INDEX] AS ods_CODE,
           stg.[GNINMB] AS stg_GNINMB, ods.[GNINMB] AS ods_CODE,
           stg.[UNO] AS stg_UNO, ods.[UNO] AS ods_CODE,
           stg.[OCATD] AS stg_OCATD, ods.[OCATD] AS ods_CODE,
           stg.[STATUS] AS stg_STATUS, ods.[STATUS] AS ods_CODE
        [DTTM_FROM] = CAST(stg.[BusinessDT] AS DATETIME),
        [DTTM_TO] = CAST("2999-01-01" AS DATETIME),
        [IS_ACTIVE] = 1,
        [IS_DELETED] = 0       
    FROM [selectStg] stg
    INNER JOIN [selectOds] ods ON ods.[CODE] = stg.[CODE]
    --- если она с изменениями внутренностей и без изменений
),
[forUpdateEqual] AS (
    SELECT ods_CODE
    FROM [forUpdateBase]
    WHERE (stg_CODE = ods_CODE)
          AND
          (stg_NAME = ods_NAME)
          AND
          (stg_SOCR = ods_SOCR)
          AND
          (stg_NDEX = ods_INDEX)
          AND
          (stg_GNINMB = ods_GNINMB)
          AND
          (stg_UNO = ods_UNO)
          AND
          (stg_OCATD = ods_OCATD)
          AND
          (stg_STATUS = ods_STATUS)
)
UPDATE всех ods кроме forUpdateEqual

---  INSERT NEW
WITH [selectOds] AS (
    SELECT 
        [CODE], [NAME], [SOCR], [INDEX], [GNINMB], [UNO], [OCATD], [STATUS],
        [DTTM_FROM], [DTTM_TO], [IS_ACTIVE], [IS_DELETED]
    FROM ods.[KLADR]
    WHERE [IS_ACTIVE] = 1
),
[selectStg] AS (
    SELECT [CODE], [NAME], [SOCR], [INDEX], [GNINMB], [UNO], [OCATD], [STATUS], [BusinessDT]
    FROM stg.[KLADR]
),
[forInsert] AS (
    SELECT stg.[CODE], stg.[NAME], stg.[SOCR], stg.[INDEX], stg.[GNINMB], stg.[UNO], stg.[OCATD], stg.[STATUS],
        [DTTM_FROM] = CAST(stg.[BusinessDT] AS DATETIME),
        [DTTM_TO] = CAST("2999-01-01" AS DATETIME),
        [IS_ACTIVE] = 1,
        [IS_DELETED] = 0       
    FROM [selectStg] stg
    LEFT JOIN [selectOds] ods ON ods.[CODE] = stg.[CODE]
    WHERE ods.[CODE] IS NULL
)
INSERT INTO ods.[KLADR] (
    [CODE], [NAME], [SOCR], [INDEX], [GNINMB], [UNO], [OCATD], [STATUS],
    [DTTM_FROM], [DTTM_TO], [IS_ACTIVE], [IS_DELETED]
)
SELECT [CODE], [NAME], [SOCR], [INDEX], [GNINMB], [UNO], [OCATD], [STATUS],
       [DTTM_FROM], [DTTM_TO], [IS_ACTIVE], [IS_DELETED]
FROM [forInsert];

---  DELETE
WITH [selectOds] AS (
    SELECT 
        [CODE], [NAME], [SOCR], [INDEX], [GNINMB], [UNO], [OCATD], [STATUS],
        [DTTM_FROM], [DTTM_TO], [IS_ACTIVE], [IS_DELETED]
    FROM ods.[KLADR]
    WHERE [IS_ACTIVE] = 1
),
[selectStg] AS (
    SELECT [CODE], [NAME], [SOCR], [INDEX], [GNINMB], [UNO], [OCATD], [STATUS], [BusinessDT]
    FROM stg.[KLADR]
),
[forDelete] AS (
    SELECT ods.[CODE], MAX(stg.[BusinessDT]) OVER() AS [LastDTTM]
    FROM [selectStg] stg
    RIGHT JOIN [selectOds] ods ON ods.[CODE] = stg.[CODE]
    WHERE stg.[CODE] IS NULL
)
UPDATE ods.[KLADR] src
SET [IS DELETED] = 1,
    [IS_ACTUAL] = 0,
    [DTTM_TO] = (
        SELECT TOP 1 d.[LastDTTM]
        FROM [forDelete] d
        WHERE d.[CODE] = src.[CODE]
        ORDER BY d.[LastDTTM] DESC
    )
WHERE src.[CODE] IN ( -- EXISTS
    SELECT DISTINCT FROM [forDelete]
);

-- UPDATE
WITH [selectOds] AS (
    SELECT 
        [CODE], [NAME], [SOCR], [INDEX], [GNINMB], [UNO], [OCATD], [STATUS],
        [DTTM_FROM], [DTTM_TO], [IS_ACTIVE], [IS_DELETED]
    FROM ods.[KLADR]
    WHERE [IS_ACTIVE] = 1
),
[selectStg] AS (
    SELECT [CODE], [NAME], [SOCR], [INDEX], [GNINMB], [UNO], [OCATD], [STATUS], [BusinessDT]
    FROM stg.[KLADR]
),
[forUpdateBase] AS (
    SELECT stg.[CODE] AS [stg_CODE], ods.[CODE] AS [ods_CODE],
           stg.[NAME] AS [stg_NAME], ods.[NAME] AS [ods_CODE],
           stg.[SOCR] AS [stg_SOCR], ods.[SOCR] AS [ods_CODE],
           stg.[INDEX] AS [stg_INDEX], ods.[INDEX] AS [ods_CODE],
           stg.[GNINMB] AS [stg_GNINMB], ods.[GNINMB] AS [ods_CODE],
           stg.[UNO] AS [stg_UNO], ods.[UNO] AS [ods_CODE],
           stg.[OCATD] AS [stg_OCATD], ods.[OCATD] AS [ods_CODE],
           stg.[STATUS] AS [stg_STATUS], ods.[STATUS] AS [ods_CODE],
           stg.[BusinessDT] AS BusinessDT 
        FROM [selectStg] stg
        INNER JOIN [selectOds] ods ON ods.[CODE] = stg.[CODE]
),
[needToSkip] AS ( -- do not touch
    SELECT ods_CODE
    FROM [forUpdateBase]
    WHERE (stg_CODE = ods_CODE)
          AND
          (stg_NAME = ods_NAME)
          AND
          (stg_SOCR = ods_SOCR)
          AND
          (stg_NDEX = ods_INDEX)
          AND
          (stg_GNINMB = ods_GNINMB)
          AND
          (stg_UNO = ods_UNO)
          AND
          (stg_OCATD = ods_OCATD)
          AND
          (stg_STATUS = ods_STATUS)
),
...