using Datamech.mssql.etlmodels;
using Newtonsoft.Json;
using Serilog;
using System.Xml.Serialization;
using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;

namespace Datamech
{
    public class Serializator
    {
        public IEtlModel EtlModel;
        public Serializator(IEtlModel etlModel) => this.EtlModel = etlModel;
        private string SerializedJsonFileName
        {
            get => Path.Combine(Directory.GetCurrentDirectory(), "etl_models", String.Join('.', $"{this.EtlModel.ModelName}", "json"));
        }
        public string SerializedYamlFileName
        {
            get => Path.Combine(Directory.GetCurrentDirectory(), "etl_models", String.Join('.', $"{this.EtlModel.ModelName}", "yaml"));
        }
        public string SerializedXmlFileName
        {
            get => Path.Combine(Directory.GetCurrentDirectory(), "etl_models", String.Join('.', $"{this.EtlModel.ModelName}", "xml"));
        }
        public void SerializeToJson()
        {
            string serialized = JsonConvert.SerializeObject(this.EtlModel, Formatting.Indented);
            File.WriteAllText(this.SerializedJsonFileName, serialized);
        }
        public void SerializeToYaml()
        {
            var serializer = new SerializerBuilder()
                .WithNamingConvention(CamelCaseNamingConvention.Instance)
                .Build();
            var yaml = serializer.Serialize(this.EtlModel);
            File.WriteAllText(this.SerializedYamlFileName, yaml);
        }
        public void SerializeToXml()
        {
            //var concreteMessageInstance = message as NetworkDataMessage;
            //if(concreteMessageInstance != null) { /* ... */ }
            Kladr1Model etlModel = this.EtlModel as Kladr1Model;
            if (etlModel != null)
            {
                Log.Information("Зашли...");
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(Kladr1Model));
                using (FileStream fs = new FileStream(this.SerializedXmlFileName, FileMode.OpenOrCreate))
                {
                    xmlSerializer.Serialize(fs, etlModel);
                    Console.WriteLine("Object model1 has been serialized in XML");
                }
                //}
            }
        }
    }
}
