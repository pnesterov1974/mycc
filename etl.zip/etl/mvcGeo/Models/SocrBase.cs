namespace mvcGeo.Models;

public class SocrBase
{
    public int Id { get; set; }

    public int LEVEL { get; set; }

    public string SCNAME { get; set; }

    public string SOCRNAME { get; set; }

    public string KOD_T_ST { get; set; }
}
