namespace mvcGeo.Models;

public class MockSocrBaseRepository: ISocrBaseRepository
{
    public IEnumerable<SocrBase> AllSocrBase =>
        new List<SocrBase>
        {
            new SocrBase {
               Id = 0, LEVEL = 1, SCNAME = "ScName_1", SOCRNAME = "SocrName_1", KOD_T_ST = "First" 
            },
            new SocrBase {
               Id = 1, LEVEL = 2, SCNAME = "ScName_2", SOCRNAME = "SocrName_1", KOD_T_ST = "Second" 
            },
            new SocrBase {
               Id = 2, LEVEL = 4, SCNAME = "ScName_3", SOCRNAME = "SocrName_1", KOD_T_ST = "Third" 
            },
        };
}

public class MockAltNamesRepository: IAltNamesRepository
{
    public IEnumerable<AltNames> AllAltNames =>
        new List<AltNames>
        {
            new AltNames {
               Id = 0, LEVEL = 1, OLDCODE = "OldCode_1", NEWCODE = "NewCode_1" 
            },
             new AltNames {
               Id = 1, LEVEL = 1, OLDCODE = "OldCode_2", NEWCODE = "NewCode_2" 
            },
             new AltNames {
               Id = 2, LEVEL = 2, OLDCODE = "OldCode_3", NEWCODE = "NewCode_3" 
            },
             new AltNames {
               Id = 3, LEVEL = 2, OLDCODE = "OldCode_4", NEWCODE = "NewCode_4" 
            },
             new AltNames {
               Id = 4, LEVEL = 3, OLDCODE = "OldCode_", NEWCODE = "NewCode_5" 
            },
        };
}