namespace mvcGeo.Models;

public interface ISocrBaseRepository
{
    IEnumerable<SocrBase> AllSocrBase { get; }
}

public interface IAltNamesRepository
{
    IEnumerable<AltNames> AllAltNames { get; }
}