namespace mvcGeo.Models;

public class AltNames
{
    public int Id { get; set; }

    public string OLDCODE { get; set; }

    public string NEWCODE { get; set; }

    public int LEVEL { get; set; }
}
