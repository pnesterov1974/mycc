using Microsoft.AspNetCore.Mvc;
using mvcGeo.Models;

namespace mvcGeo.Controllers;

public class SocrBaseController : Controller
{
    private readonly ISocrBaseRepository socrBaseRepository;
    public SocrBaseController(ISocrBaseRepository socrBaseRepository)
    {
        this.socrBaseRepository = socrBaseRepository;
    }

    public IActionResult Index()
    {
        ViewBag.Message = "A List of KLADR SocrBases"; // dynamic object
        return View();
    }

    public IActionResult List()
    {
        return View(socrBaseRepository.AllSocrBase);
    }
}
