using Microsoft.AspNetCore.Mvc;
using mvcGeo.Models;

namespace mvcGeo.Controllers;

public class AltNamesController : Controller
{
    private readonly IAltNamesRepository altNamesRepository;
    public AltNamesController(IAltNamesRepository altNamesRepository)
    {
        this.altNamesRepository = altNamesRepository;
    }

    public IActionResult Index()
    {
        ViewBag.Message = "A List of KLADR AltNames";
        return View();
    }

    public IActionResult List()
    {
        return View(altNamesRepository.AllAltNames);
    }
}
