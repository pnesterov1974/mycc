using System.Data;
using DbfDataReader;
using Npgsql;
using NpgsqlTypes;
using Shared.importModels;
using static Shared.MyLogger;

namespace ImportGeo.kladr.pgsql;

public class PgImportSocrBase : BaseCommonImport
{
    public IImportModel ImportModel { get; set; } = new SocrBaseImportModel();

    public void DoImport(bool clearDestTableInAdvance = true, int BufferRecs = 100000)
    {
        int bufferRecs;
        if (this.ImportModel.BufferRecs > 0)
        {
            bufferRecs = this.ImportModel.BufferRecs;
        }
        else
        {
            bufferRecs = BufferRecs;
        }

        if (!clearDestTableInAdvance ||
                (clearDestTableInAdvance &&
                    this.DBUtils.ClearDestTable(this.TargetConnectionString, this.TargetTableFullName)
                )
            )
        {
            Log.Information("Начинаю импорт данных в {table}", this.TargetTableName);
            DbfDataReaderOptions dbfOptions = new DbfDataReaderOptions { SkipDeletedRecords = true };
            using (var dbfDataReader = new DbfDataReader.DbfDataReader(this.ImportModel.SourceFullPathName, dbfOptions))
            {
                var dataSourceBuilder = new NpgsqlDataSourceBuilder(this.TargetConnectionString);
                var dataSource = dataSourceBuilder.Build();

                DateTime dtStart = DateTime.Now;

                using NpgsqlConnection conn = dataSource.OpenConnection();
                //var t = conn.BeginTransaction(System.Data.IsolationLevel.ReadCommitted);

                int RecordCount = 0;
                while (dbfDataReader.Read())
                {
                    var level = dbfDataReader.GetString(0);
                    var scname = dbfDataReader.GetString(1);
                    var socrname = dbfDataReader.GetString(2);
                    var kod_t_st = dbfDataReader.GetString(3);

                    NpgsqlCommand cmd = dataSource.CreateCommand(
                        $"INSERT INTO {this.TargetTableFullName}(level, scname, socrname, kod_t_st) VALUES (@level, @scname, @socrname, @kod_t_st);"
                    );

                    NpgsqlParameter pLevel = new NpgsqlParameter
                    {
                        ParameterName = "@level",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = level,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pScName = new NpgsqlParameter
                    {
                        ParameterName = "@scname",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = scname,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pSocrName = new NpgsqlParameter
                    {
                        ParameterName = "@socrname",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = socrname,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pKodTSt = new NpgsqlParameter
                    {
                        ParameterName = "@kod_t_st",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = kod_t_st,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    cmd.Parameters.Add(pLevel);
                    cmd.Parameters.Add(pScName);
                    cmd.Parameters.Add(pSocrName);
                    cmd.Parameters.Add(pKodTSt);

                    RecordCount = cmd.ExecuteNonQuery();
                }
                DateTime dtFinish = DateTime.Now;
                TimeSpan duration = dtFinish - dtStart;
                Log.Information("{table} Всего загружено: {recs} записей за {duration}", this.TargetTableName, RecordCount, duration);
            }
        }
    }
}
