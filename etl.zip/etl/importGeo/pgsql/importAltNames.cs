using Npgsql;
using static Shared.MyLogger;
using DbfDataReader;
using System.Data;
using NpgsqlTypes;
using Utils;
using Shared.KladrImportModels;

namespace ImportGeo.kladr.pgsql;

public class PgImportAltNames : BaseCommonImport
{
    public IImportModel ImportModel { get; set; } = new AltNamesImportModel();

    public PgImportAltNames()
    {
        this.TargetDb = Shared.TargetDb.pgsql;
    }

    public void DoImport(bool clearDestTableInAdvance = true, int BufferRecs = 100000)
    {
        int bufferRecs;
        if (this.ImportModel.BufferRecs > 0)
        {
            bufferRecs = this.ImportModel.BufferRecs;
        }
        else
        {
            bufferRecs = BufferRecs;
        }

        var u = new UtilsCommon();
        u.ReadDbfInfo(this.ImportModel.SourceFullPathName);

        if (!clearDestTableInAdvance ||
                (clearDestTableInAdvance && 
                    this.DBUtils.ClearDestTable(this.TargetConnectionString, this.TargetTableFullName)
                )
            )
        {
            Log.Information("Начинаю импорт данных в {table}", this.TargetTableName);
            DbfDataReaderOptions dbfOptions = new DbfDataReaderOptions { SkipDeletedRecords = true };
            using (var dbfDataReader = new DbfDataReader.DbfDataReader(this.ImportModel.SourceFullPathName, dbfOptions))
            {
                int RecordCount = 0;
                int CurBufferRecs = 0;
                using var conn = new NpgsqlConnection(this.TargetConnectionString);
                conn.Open();
                //var t = conn.BeginTransaction(System.Data.IsolationLevel.ReadCommitted);
                var batch = new NpgsqlBatch(conn);
                DateTime dtStart = DateTime.Now;

                while (dbfDataReader.Read())
                {
                    var oldcode = dbfDataReader.GetString(0);
                    var newcode = dbfDataReader.GetString(1);
                    var level = dbfDataReader.GetString(2);

                    var batchCommand = new NpgsqlBatchCommand(
                        $"INSERT INTO {this.TargetTableFullName}(oldcode, newcode, level) VALUES (@oldcode, @newcode, @level);"
                        );

                    NpgsqlParameter pOldCode = new NpgsqlParameter
                    {
                        ParameterName = "@oldcode",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = oldcode,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pNewCode = new NpgsqlParameter
                    {
                        ParameterName = "@newcode",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = newcode,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pLevel = new NpgsqlParameter
                    {
                        ParameterName = "@level",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = level,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    batchCommand.Parameters.Add(pOldCode);
                    batchCommand.Parameters.Add(pNewCode);
                    batchCommand.Parameters.Add(pLevel);

                    batch.BatchCommands.Add(batchCommand);
                    CurBufferRecs += 1;
                    if (CurBufferRecs >= bufferRecs)
                    {
                        RecordCount += batch.ExecuteNonQuery();
                        Log.Information("{table}: загружено {recs} записей", this.TargetTableName, RecordCount);
                        CurBufferRecs = 0;
                        batch.BatchCommands.Clear();
                    }
                }
                if (CurBufferRecs > 0)
                {
                    RecordCount += batch.ExecuteNonQuery();
                    Log.Information("{table}: загружено {recs} записей", this.TargetTableName, RecordCount);
                    batch.BatchCommands.Clear();
                }
                DateTime dtFinish = DateTime.Now;
                TimeSpan duration = dtFinish - dtStart;
                Log.Information("{table} Всего загружено: {recs} записей за {duration}", this.TargetTableName, RecordCount, duration);
            }
        }
    }
}
