using System.Data;
using System.Text;
using DbfDataReader;
using Npgsql;
using NpgsqlTypes;
using Shared.importModels;
using static Shared.MyLogger;

namespace ImportGeo.kladr.pgsql;

class BaseSourceEnumerator
{
    protected bool ReadDbfInfo(string sourceFilePath)
    {
        Log.Information("Считывание информации о файле {filepath}", sourceFilePath);
        long recordCount = 0;
        if (File.Exists(sourceFilePath))
        {
            Log.Information("Файл {filepath} найден, обработка...", sourceFilePath);
            using (var dbfTable = new DbfTable(sourceFilePath, Encoding.UTF8))
            {
                var header = dbfTable.Header;
                var versionDescription = header.VersionDescription;
                var hasMemo = dbfTable.Memo != null;
                recordCount = header.RecordCount;
                Log.Information("versionDescription: {versionDescription}\thasMemo: {hasMemo}\trecordCount: {recordCount}", versionDescription, hasMemo, recordCount);
                foreach (var dbfColumn in dbfTable.Columns)
                {
                    var name = dbfColumn.ColumnName;
                    var columnType = dbfColumn.ColumnType;
                    var length = dbfColumn.Length;
                    var decimalCount = dbfColumn.DecimalCount;
                    Log.Information("name: {name}\tcolumnType: {columnType}\tlength: {length}\tdecimalCount: {decimalCount}", name, columnType, length, decimalCount);
                }
            }
            return recordCount > 0;
        }
        else
        {
            Log.Information("Файла {@filepath} не сушествует, останов...", sourceFilePath);
            return false;
        }
    }
}

public class Kladr
{
    public string NAME;
    public string SOCR;
    public string CODE;
    public string INDEX;
    public string GNINMB;
    public string UNO;
    public string OCATD;
    public string STATUS;
}

class KladrSourceEnumerator : BaseSourceEnumerator
{
    //public IImportModel ImportModel = new KladrImportModel();

    private DbfDataReaderOptions dbfOptions = new DbfDataReaderOptions { SkipDeletedRecords = true };

    private string sourceFilePath = string.Empty;

    public KladrSourceEnumerator(string sourceFullPathName)
    {
        this.sourceFilePath = sourceFullPathName;
    }

    public IEnumerator<Kladr> GetEnumerator()
    {
        //string sourceFilePath = this.ImportModel.SourceFullPathName;
        Log.Information("Проверка источника KLADR из {kladrPath}", this.sourceFilePath);
        if (!this.ReadDbfInfo(sourceFilePath))
        {
            Log.Information("Источник {sourceFile} не валиден. Отмена обработки KLADR", this.sourceFilePath);
            yield break;
        }
        //string DtFileFullPath = this.ImportModel.DtFileFullPath;
        //Log.Information("Дата-метка файл {dtFilePath}", DtFileFullPath);
        //DateOnly Dt = this.ImportModel.Dt;
        //Log.Information("Дата-метка {dt}", Dt);
        Log.Information("Загрузка KLADR из {kladrPath}", this.sourceFilePath);
        using (var dbfDataReader = new DbfDataReader.DbfDataReader(this.sourceFilePath, this.dbfOptions))
        {
            while (dbfDataReader.Read())
            {
                var name = dbfDataReader.GetString(0);
                var socr = dbfDataReader.GetString(1);
                var code = dbfDataReader.GetString(2);
                var index = dbfDataReader.GetString(3);
                var gninmb = dbfDataReader.GetString(4);
                var uno = dbfDataReader.GetString(5);
                var ocatd = dbfDataReader.GetString(6);
                var status = dbfDataReader.GetString(7);

                var kladr = new Kladr
                {
                    NAME = name,
                    SOCR = socr,
                    CODE = code,
                    INDEX = index,
                    GNINMB = gninmb,
                    UNO = uno,
                    OCATD = ocatd,
                    STATUS = status,
                };
                yield return kladr;
            }
        }
    }
}

public class PgImportKladrIEnum2 : BaseCommonImport
{
    public IImportModel ImportModel { get; set; } = new KladrImportModel();

    public void DoImport(bool clearDestTableInAdvance = true, int BufferRecs = 100000)
    {
        int bufferRecs;
        if (this.ImportModel.BufferRecs > 0)
        {
            bufferRecs = this.ImportModel.BufferRecs;
        }
        else
        {
            bufferRecs = BufferRecs;
        }

        if (!clearDestTableInAdvance ||
                (clearDestTableInAdvance &&
                    this.DBUtils.ClearDestTable(this.TargetConnectionString, this.TargetTableFullName)
                )
            )
        {
            {
                Log.Information("Начинаю импорт данных в {table}", this.TargetTableName);


                int RecordCount = 0;
                int CurBufferRecs = 0;
                using var conn = new NpgsqlConnection(this.TargetConnectionString);
                conn.Open();

                var batch = new NpgsqlBatch(conn);
                DateTime dtStart = DateTime.Now;

                var kse = new KladrSourceEnumerator(this.ImportModel.SourceFullPathName);
                foreach(var k in kse)
                {
                    var name = k.NAME;
                    var socr = k.SOCR;
                    var code = k.CODE;
                    var index = k.INDEX;
                    var gninmb = k.GNINMB;
                    var uno = k.UNO;
                    var ocatd = k.OCATD;
                    var status = k.STATUS;

                    var bcmd = new NpgsqlBatchCommand(
                        $"INSERT INTO {this.TargetTableFullName}(name, socr, code, index, gninmb, uno, ocatd, status) VALUES (@name, @socr, @code, @index, @gninmb, @uno, @ocatd, @status);"
                        );

                    NpgsqlParameter pName = new NpgsqlParameter
                    {
                        ParameterName = "@name",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = name,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pSocr = new NpgsqlParameter
                    {
                        ParameterName = "@socr",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = socr,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pCode = new NpgsqlParameter
                    {
                        ParameterName = "@code",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = code,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pIndex = new NpgsqlParameter
                    {
                        ParameterName = "@index",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = index,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pGninmb = new NpgsqlParameter
                    {
                        ParameterName = "@gninmb",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = gninmb,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pUno = new NpgsqlParameter
                    {
                        ParameterName = "@uno",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = uno,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pOcatd = new NpgsqlParameter
                    {
                        ParameterName = "@ocatd",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = ocatd,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    NpgsqlParameter pStatus = new NpgsqlParameter
                    {
                        ParameterName = "@status",
                        Direction = ParameterDirection.Input,
                        NpgsqlValue = status,
                        NpgsqlDbType = NpgsqlDbType.Text
                    };

                    bcmd.Parameters.Add(pName);
                    bcmd.Parameters.Add(pSocr);
                    bcmd.Parameters.Add(pCode);
                    bcmd.Parameters.Add(pIndex);
                    bcmd.Parameters.Add(pGninmb);
                    bcmd.Parameters.Add(pUno);
                    bcmd.Parameters.Add(pOcatd);
                    bcmd.Parameters.Add(pStatus);

                    batch.BatchCommands.Add(bcmd);
                    CurBufferRecs += 1;
                    if (CurBufferRecs >= bufferRecs)
                    {
                        RecordCount += batch.ExecuteNonQuery();
                        Log.Information("{table} загружено {recs} записей", this.TargetTableName, RecordCount);
                        CurBufferRecs = 0;
                        batch.BatchCommands.Clear();
                    }
                }
                if (CurBufferRecs > 0)
                {
                    RecordCount += batch.ExecuteNonQuery();
                    Log.Information("{table} загружено {recs} записей", this.TargetTableName, RecordCount);
                    batch.BatchCommands.Clear();
                }
                DateTime dtFinish = DateTime.Now;
                TimeSpan duration = dtFinish - dtStart;
                Log.Information("{table} Всего загружено: {recs} записей за {duration}", this.TargetTableName, RecordCount, duration);

            }
        }
    }
}
