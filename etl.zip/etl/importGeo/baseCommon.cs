using Shared;
using Shared.KladrImportModels;
using Utils;

namespace ImportGeo;

public class BaseCommonImport
{
    public IImportModel ImportModel { get; set; }
    public string TargetSchemaName { get; set; } = string.Empty;
    public string TargetTableName { get; set; } = string.Empty;
    public string TargetConnectionString { get; set; } = string.Empty;

    public IDBUtils DBUtils;
    public UtilsCommon UtilsCommon = new UtilsCommon();
    private TargetDb targetDb;
    public TargetDb TargetDb
    {
        get => this.targetDb;
        set
        {
            this.targetDb = value;
            switch (this.targetDb)
            {
                case Shared.TargetDb.mssql:
                    this.DBUtils = new UtilsMsSql();
                    break;
                case Shared.TargetDb.pgsql:
                    this.DBUtils = new UtilsPgSql();
                    break;
            }
        }
    }

    public string TargetTableFullName
    {
        get => string.Join('.', this.TargetSchemaName, this.TargetTableName);
    }
}