using Shared.importModels;
using utilsPgSql;

namespace ImportGeo;

public class BaseCommonImport
{
    public IImportModel ImportModel { get; set; }
    public string TargetSchemaName { get; set; } = string.Empty;
    public string TargetTableName { get; set; } = string.Empty;
    public string TargetConnectionString { get; set; } = string.Empty;

    public string TargetTableFullName
    {
        get
        {
            return string.Join('.', this.TargetSchemaName, this.TargetTableName);
        }
    }
    protected UtilsPgSql utilsPg = new UtilsPgSql();
}