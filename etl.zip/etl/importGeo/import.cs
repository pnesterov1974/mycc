﻿namespace import_kladr;

// TargetTableInModel ???

public class ImportKladr
{
}
