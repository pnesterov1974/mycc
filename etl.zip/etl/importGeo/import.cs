namespace import_kladr;

// Target Names in importModels

public class ImportKladr
{}
