using static Shared.MyLogger;
using Shared.connections;
using Datamech;
//using Datamech.pgsql;
//using Datamech.pgsql.etlmodels;
using Datamech.mssql;
using Datamech.mssql.etlmodels;
//using System.Data;
//using Dataread.pgsql;
//using Dataread.mssql;
using importGeoEfc;
using ImportGeo.kladr.pgsql;

using Shared;
using importGeoEfc.models;
using Data.Import.kladr.pgsql;

// ===== model validation
// check if targetschema exists
// parameters in sqls {@Param1} {@Param2}  ! arch
// same server instance vs same db ->
//    model execution options   insertinto/bulkinsert/batsches
// -- model name uniquness


// ==== model
// -- targetFullName exclude from etlModelBase (need for sirialization)
// -- presql  --postsql  --pullmotivation -- pushmotivation
// -- execute-model-as   table vs view
// -- techfields list
// -- batchSizeInModel Batch vs Page names

// TODO
// pg: when create table with pk Cannot define PRIMARY KEY constraint on nullable column in table 'kladr_1'.
// datameshmodels
//
// -- 

// tech_db  <-use delegates and events
// -- executions
// -- locks

// in pg:
// efc_import_kladr delete rows in advanced
// efc_import_kladr CombineImport use batch count

// Review conrolflow with Exceptions Validation pre execute No validation while execute pg + ms
// model yaml & json deserialization

// efc_import_kladr FirstImportModels + BusinessModels ?? NotMappedFields in models

// model xml serialization
// pgsql: RunBatch ... using bulkInsert

// Многопоточность

InitLogger();
if (!ConnectionStrings.ConnectionStringsInitialized())
{
    ConnectionStrings.InitConnectionStrings(Shared.TargetDb.pgsql);
    //ConnectionStrings.InitConnectionStrings(Shared.TargetDb.mssql, useAD:false);
}
string etlModelsFolder = Path.Join(Directory.GetCurrentDirectory(), "etl_models");
string readModelsFolder = Path.Join(Directory.GetCurrentDirectory(), "read_models");
Log.Information("Папка etl-моделей: {etlModelsfolder}", etlModelsFolder);
Log.Information("Папка read-моделей: {readModelsfolder}", readModelsFolder);

//SerilizeEtlModels();
//RunClientFaceEtlModels();
//RunEtlModels();
//RunReadModels();
//ValidateEtlModels();
ReadEf();
//TestOneEtlModel();

void RunEtlModels()
{
    var KladrModelsCat = new KladrModelsCatalog();

    foreach (var etlModel in KladrModelsCat.Models)
    {
        try
        {
            RunEtlModel rm = new RunEtlModel(etlModel);
            rm.Run();
        }
        catch (Exception ex)
        {
            Log.Information("Модель {etl} пропущена из-за ошибки", etlModel);
            Log.Error("\n{errorMessage}", ex.Message);
        }
    }
}

void RunClientFaceEtlModels()
{
    // var ClientFaceModels = new ClientFaceModelsCatalog();

    // foreach (var etlModel in ClientFaceModels.Models)
    // {
    //     try
    //     {
    //         RunEtlModel rm = new RunEtlModel(etlModel);
    //         rm.Run();
    //     }
    //     catch (Exception ex)
    //     {
    //         Log.Information("Модель {etl} пропущена из-за ошибки", etlModel);
    //         Log.Error("\n{errorMessage}", ex.Message);
    //     }
    // }
}

void SerilizeEtlModels()
{
    KladrModelsCatalog mcatalog = new KladrModelsCatalog();
    foreach (var model in mcatalog.Models)
    {
        Serializator szr = new Serializator(model);
        szr.SerializeToJson();
        szr.SerializeToYaml();
    }
    // Kladr1Model klm1 = new Kladr1Model();
    // Serializator klm1s = new Serializator(klm1);
    // klm1s.SerializeToXml();
}

void RunReadModels()
{
    // var kladr = new KladrReadModelsCatalog();

    // foreach (var readModel in kladr.Models)
    // {
    //     try
    //     {
    //         RunReadModel rm = new RunReadModel(readModel);
    //         string ss = rm.SchemaAsJson;
    //         Log.Information(ss);
    //     }
    //     catch (Exception ex)
    //     {
    //         Log.Information("Модель {readModel} пропущена из-за ошибки", readModel);
    //         Log.Error("\n{errorMessage}", ex.Message);
    //     }
    // }
}

void ValidateEtlModels()
{

    var KladrModelsCat = new KladrModelsCatalog();

    foreach (var etlModel in KladrModelsCat.Models)
    {
        try
        {
            //var v = new ValidateEtlModel(TargetDb.pgsql, etlModel);
            var v = new ValidateEtlModel(TargetDb.mssql, etlModel);
            v.Validate();
        }
        catch (Exception ex)
        {
            Log.Information("Модель {etl} пропущена из-за ошибки", etlModel);
            Log.Error("\n{errorMessage}", ex.Message);
        }
    }
}

void ValidateReadModels()
{

    var KladrModelsCat = new KladrModelsCatalog();

    foreach (var etlModel in KladrModelsCat.Models)
    {
        try
        {
            var v = new ValidateEtlModel(TargetDb.pgsql, etlModel);
            v.Validate();
        }
        catch (Exception ex)
        {
            Log.Information("Модель {etl} пропущена из-за ошибки", etlModel);
            Log.Error("\n{errorMessage}", ex.Message);
        }
    }
}

void ReadEf()
{
    //KladrEfcImport.SaveKladr(TargetDb.pgsql);
    //var worker = new KladrEfcImportWorker{ tdb = TargetDb.mssql };
    var worker = new KladrEfcImportWorker{ tdb = TargetDb.pgsql };
    worker.SaveSocrBaseUsingEnumerator();
    worker.SaveAltNamesUsingEnumerator();
    worker.SaveKladrUsingEnumerator();
    worker.SaveKladrUsingEnumerator();
    worker.SaveStreetUsingEnumerator();
    worker.SaveDomaUsingEnumerator();
}

void TestOneEtlModel()
{
    //NewModel nm = new NewModel();
    //var t = nm.GetParameterNames();
}

void ImportWithoutEf()
{
    var altnames = new PgImportAltNames()
    {
        TargetConnectionString = ConnectionStrings.GetConnectionStringByName("kladrStage"),
        TargetTableName = "altnames",
        TargetSchemaName = "kladr"
    };
    altnames.DoImport();

    var socrbase = new PgImportSocrBase()
    {
        TargetConnectionString = ConnectionStrings.GetConnectionStringByName("kladrStage"),
        TargetTableName = "socrbase",
        TargetSchemaName = "kladr"
    };
    socrbase.DoImport();

    var kladr = new PgImportKladr()
    {
        TargetConnectionString = ConnectionStrings.GetConnectionStringByName("kladrStage"),
        TargetTableName = "kladr",
        TargetSchemaName = "kladr"
    };
    kladr.DoImport();

    var street = new PgImportStreet()
    {
        TargetConnectionString = ConnectionStrings.GetConnectionStringByName("kladrStage"),
        TargetTableName = "street",
        TargetSchemaName = "kladr"
    };
    street.DoImport();

    var doma = new PgImportDoma()
    {
        TargetConnectionString = ConnectionStrings.GetConnectionStringByName("kladrStage"),
        TargetTableName = "doma",
        TargetSchemaName = "kladr"
    };
    doma.DoImport();
}
