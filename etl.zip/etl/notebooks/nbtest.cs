public static class DoTest
{
    // https://accessibleai.dev/post/polyglot_imports/
    public static void PrintTest()
    {
        Console.WriteLine("Из класса");
    }

    public static string GetTest()
    {
        return "Из класса";
    }
}