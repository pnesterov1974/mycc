public class SocrBase
{
    public int Id;
    public int LEVEL;
    public string SCNAME;
    public string SOCRNAME;
    public string KOD_T_ST;
    //public DateOnly BusinessDT;
}

public static class PgConnTest
{
    public static string PgConnectionString()
    {
        NpgsqlConnectionStringBuilder sqb = new NpgsqlConnectionStringBuilder
        {
            ApplicationName = "ETL Application",
            Host = "127.0.0.1:5432",
            Username = "postgres",
            Password = "my_pass",
            Database = "kladr",
            Timeout = 100,
            CommandTimeout = 0,
            Pooling = true,
            IncludeErrorDetail = true
        };
        return sqb.ToString();
    }

    public static string SelectSql = """
        SELECT
            "Id",
            "LEVEL",
            "SCNAME",
            "SOCRNAME",
            "KOD_T_ST"
            --,
            --"BusinessDT"
        FROM
            "stg"."socrbase"
    """;

    public static IEnumerable<SocrBase> IterSocrBase()
    {
        string connString = PgConnTest.PgConnectionString();
        using (NpgsqlConnection conn = new NpgsqlConnection(connString))
        {
            conn.Open();
            NpgsqlCommand command = new NpgsqlCommand(PgConnTest.SelectSql, conn);
            using NpgsqlDataReader reader = command.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    var em = new SocrBase
                    {
                        Id = (int)reader.GetInt16(0),
                        LEVEL = (int)reader.GetInt16(1),
                        SCNAME = reader.GetString(2),
                        SOCRNAME = reader.GetString(3),
                        KOD_T_ST = reader.GetString(4),
                        //BusinessDT = DateOnly.Parse(reader.GetString(5))
                    };
                    yield return em;
                }
            }
            else
            {
                Console.WriteLine("Данные отсутствуют...");
                yield break;
            }
        }
    }
}