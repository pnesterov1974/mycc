// Select All Columns using LINQ syntax
public List<Product> GetAll()
{
    List<Product> products = GetProducts();
    List<Product> list;

    list = (from prod in products
            select prod).ToList();

    list = products.Select(prod => prod).ToList();

    return list;
}


// Select One Columns using LINQ syntax
public List<string> GetSingleColumn()
{
    List<Product> products = GetProducts();
    List<string> list = new();

    list.AddRange(from prod in products
                  select prod.Name);
    list.AddRange(products.Select(prod => prod.Name));
    return list;
}


// Query some columns using LINQ syntax
public List<Product> GetSpecificColumnsQuery()
{
    List<Product> products = GetProducts();
    List<Product> list;

    list = (from prod in products
            select new Product
            {
                ProductID = prod.ProductID,
                Name = prod.Name,
                Size = prod.Size
            }).ToList();

    list = products.Select(prod => new Product
    {
        ProductID = prod.ProductID,
        Name = prod.Name,
        Size = prod.Size
    }).ToList();

    return list;
}


// Query some columns using anonimous class LINQ syntax
public string AnonymousClassQuery()
{
    List<Product> products = GetProducts();
    StringBuilder sb = new(2048);

    var list = (from prod in products
                select new
                {
                    Identifier = prod.ProductID,
                    ProductName = prod.Name,
                    ProductSize = prod.Size
                });

    var list = products.Select(prod => new
    {
        Identifier = prod.ProductID,
        ProductName = prod.Name,
        ProductSize = prod.Size
    });

    // Loop through anonymous class
    foreach (var prod in list)
    {
        sb.AppendLine($"Product ID: {prod.Identifier}");
        sb.AppendLine($"   Product Name: {prod.ProductName}");
        sb.AppendLine($"   Product Size: {prod.ProductSize}");
    }

    return sb.ToString();
}


public List<Product> OrderByQuery()
{
    List<Product> products = GetProducts();
    List<Product> list;

    list = (from prod in products
            orderby prod.Color descending, prod.Name
            select prod).ToList();

    list = products.OrderBy(prod => prod.Name).ToList();
    list = products.OrderByDescending(prod => prod.Color)
                     .ThenBy(prod => prod.Name).ToList();
    list = products.OrderByDescending(prod => prod.Color)
                      .ThenByDescending(prod => prod.Name).ToList();

    return list;
}

public List<Product> WhereTwoFieldsQuery()
{
    List<Product> products = GetProducts();
    List<Product> list;

    list = (from prod in products
            where prod.Name.StartsWith("L") && prod.StandardCost > 200
            select prod).ToList();

    list = products.Where(prod => prod.Name.StartsWith("L") &&
                                  prod.StandardCost > 200).ToList();

    return list;
}

/// Extension Method from VIDEO ---------------------------------------------------
public List<Product> WhereExtensionQuery()
{
    List<Product> products = GetProducts();
    List<Product> list;

    list = (from prod in products
            select prod).ByColor("Red").ToList();
    list = products.ByColor("Red").ToList();

    return list;
}

public Product First()
{
    List<Product> products = GetProducts();
    Product value;
    /// NOTE: First() throws an exception if the result does not produce any values
    value = (from prod in products
             select prod)
              .First(prod => prod.Color == "Red");
    value = products.First(prod => prod.Color == "Red");

    return value;
}

public Product FirstOrDefault()
{
    List<Product> products = GetProducts();
    Product value;
    /// NOTE: FirstOrDefault() returns a null if no value is found
    value = (from prod in products
             select prod)
             .FirstOrDefault(prod => prod.Color == "Red");
    value = products.FirstOrDefault(prod => prod.Color == "Red");

    return value;
}


public Product FirstOrDefaultWithDefault()
{
    List<Product> products = GetProducts();
    Product value;
    /// NOTE: You may specify the return value with FirstOrDefault() if not found
    value = (from prod in products
             select prod)
             .FirstOrDefault(prod => prod.Color == "Red",
                             new Product { ProductID = -1, Name = "PRODUCT NOT FOUND" });
    value = products.FirstOrDefault(prod => prod.Color == "Red",
                                      new Product { ProductID = -1, Name = "NOT FOUND" });
    return value;
}


public Product Last()
{
    List<Product> products = GetProducts();
    Product value;
    /// NOTE: Last returns the last value from a collection, or throws an exception if no value is found
    value = (from prod in products
             select prod)
             .Last(prod => prod.Color == "Red");

    value = products.Last(prod => prod.Color == "Red");
    return value;
}

// LastOrDefault .... same as First

public Product Single()
{
    List<Product> products = GetProducts();
    Product value;
    /// NOTE: Single() expects only a single element to be found in the collection, otherwise an exception is thrown
    value = (from prod in products
             select prod)
              .Single(prod => prod.ProductID == 706);
    value = products.Single(prod => prod.ProductID == 706);

    return value;
}

public Product SingleOrDefault()
{
    List<Product> products = GetProducts();
    Product value;
    /// NOTE: SingleOrDefault() returns a single element found in the collection, 
    /// or a null value if none found in the collection, if multiple values are found an exception is thrown.
    value = (from prod in products
             select prod)
            .SingleOrDefault(prod => prod.ProductID == 706);

    value = products.SingleOrDefault(prod => prod.ProductID == 706);

    return value;
}

public List<Product> Take()
{
    List<Product> products = GetProducts();
    List<Product> list;

    // Write Query Syntax Here
    list = (from prod in products
            orderby prod.Name
            select prod).Take(5).ToList();
    list = products.OrderBy(prod => prod.Name).Take(5).ToList();

    return list;
}

public List<Product> TakeRange()
{
    List<Product> products = GetProducts();
    List<Product> list;

    list = (from prod in products
            orderby prod.Name
            select prod).Take(5..8).ToList();

    list = products.OrderBy(prod => prod.Name).Take(5..8).ToList();

    return list;
}

public List<Product> TakeWhile()
{
    List<Product> products = GetProducts();
    List<Product> list;
    /// Use TakeWhile() to select a specified number of items from the beginning of a collection based on a true condition
    list = (from prod in products
            orderby prod.Name
            select prod).TakeWhile(prod => prod.Name.StartsWith("A")).ToList();

    list = products.OrderBy(prod => prod.Name)
                  .TakeWhile(prod => prod.Name.StartsWith("A")).ToList();

    return list;
}

public List<Product> Skip()
{
    List<Product> products = GetProducts();
    List<Product> list;
    /// Use Skip() to move past a specified number of items from the beginning of a collection
    list = (from prod in products
            orderby prod.Name
            select prod).Skip(30).ToList();
    list = products.OrderBy(prod => prod.Name).Skip(30).ToList();

    return list;
}

public List<Product> SkipWhile()
{
    List<Product> products = GetProducts();
    List<Product> list;
    /// Use SkipWhile() to move past a specified number of items from the beginning of a collection based on a true condition
    list = (from prod in products
            orderby prod.Name
            select prod).SkipWhile(prod => prod.Name.StartsWith("A")).ToList();
    list = products.OrderBy(prod => prod.Name)
        .SkipWhile(prod => prod.Name.StartsWith("A")).ToList();

    return list;
}

public List<string> Distinct()
{
    List<Product> products = GetProducts();
    List<string> list;
    /// The Distinct() operator finds all unique values within a collection.
    list = (from prod in products
            select prod.Color)
            .Distinct().OrderBy(c => c).ToList();
    list = products.Select(p => p.Color).Distinct().OrderBy(c => c).ToList();

    return list;
}

public List<Product> DistinctBy()
{
    List<Product> products = GetProducts();
    List<Product> list;
    /// The DistinctBy() operator finds all unique values within a collection using a property.
    /// ----- ????????????????
    list = (from prod in products
            select prod)
            .DistinctBy(prod => prod.Color)
            .OrderBy(p => p.Color).ToList();

    list = products.DistinctBy(prod => prod.Color, default)
                  .OrderBy(p => p.Color).ToList();

    return list;
}

public List<Product[]> Chunk()
{
    List<Product> products = GetProducts();
    List<Product[]> list;
    /// Chunk() splits the elements of a larger list into a collection of arrays 
    /// of a specified size where each element of the collection is an array of those items.
    list = (from prod in products
            select prod).Chunk(5).ToList();

    list = products.Chunk(5).ToList();

    return list;
}

public bool All()
{
    List<Product> products = GetProducts();
    bool value;
    /// Use All() to see if all items in a collection meet a specified conditio
    value = (from prod in products
             select prod)
              .All(prod => prod.ListPrice > prod.StandardCost);
    value = products.All(prod => prod.ListPrice > prod.StandardCost);

    return value;
}

public bool Any()
{
    List<SalesOrder> sales = GetSales();
    bool value;
    /// Use Any() to see if at least one item in a collection meets a specified
    value = (from sale in sales
             select sale)
              .Any(sale => sale.LineTotal > 10000);
    value = sales.Any(sale => sale.LineTotal > 10000);

    return value;
}

public bool ContainsQuery()
{
    List<int> numbers = new() { 1, 2, 3, 4, 5 };
    bool value;
    /// Use the Contains() operator to see if a collection contains a specific 
    value = (from num in numbers
             select num).Contains(3);

    value = numbers.Contains(3);

    return value;
}

public bool ContainsComparer() /// Get ComparaporClass from video
{
    List<Product> products = GetProducts();
    ProductIdComparer pc = new();
    bool value;

    value = (from prod in products
             select prod)
              .Contains(new Product { ProductID = 744 }, pc);
    value = products.Contains(new Product { ProductID = 744 }, pc);

    return value;
}