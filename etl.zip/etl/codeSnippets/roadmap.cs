// 1. LINQ
// 2. Delegates => Events => Lambdas
// 3. Exceptions .... Concept How to use
// 4. Nulls   !   ?  ??  HasValue ...  Null References

// Records Tuples .... Advanced Language Features
// Web API + MVC ...   

