using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesAndEvents
{
    // delegate is a pipeline between event and eventHandler, providing EventArgs
    public delegate void WorkPerformedHandler(int hours, WorkType workType);
    class Program
    {
        static void Main(string[] args)
        {
            WorkPerformedHandler del1 = new WorkPerformedHandler(WorkPerformed1);
            WorkPerformedHandler del2 = new WorkPerformedHandler(WorkPerformed2);
            WorkPerformedHandler del3 = new WorkPerformedHandler(WorkPerformed3);

            del1(5, WorkType.Golf);
            del2(10, WorkType.GoToMeetings);

            //int finalHours = del1(10, WorkType.GenerateReports);
            //Console.WriteLine(finalHours);  IF void->int

            //del1 += del2;
            //del1 += del3;

            del1 += del2 + del3;

            del1(10, WorkType.Golf);  // Runs 3 delegates by InvocationList

            Console.Read();
        }

        static void DoWork1()
        {
            WorkPerformed1(7, WorkType.GenerateReports);
        }

        static void DoWork2(WorkPerformedHandler wh) ///// Power !!!!
        {
            wh(7, WorkType.GenerateReports);
        }

        static void WorkPerformed1(int hours, WorkType workType)
        {
            Console.WriteLine("WorkPerformed1 called " + hours.ToString());
            //return hours + 1;
        }

        static void WorkPerformed2(int hours, WorkType workType)
        {
            Console.WriteLine("WorkPerformed2 called " + hours.ToString());
            //return hours + 2;
        }

        static void WorkPerformed3(int hours, WorkType workType)
        {
            Console.WriteLine("WorkPerformed3 called " + hours.ToString());
            //return hours + 3;
        }
    }

    public enum WorkType
    {
        GoToMeetings,
        Golf,
        GenerateReports
    }
}
