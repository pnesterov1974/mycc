// Select All Columns using LINQ syntax
public List<Product> GetAllQuery()
{
    List<Product> products = GetProducts();
    List<Product> list;

    list = (from prod in products
            select prod).ToList();

    return list;
}

// Select All Columns Using Fluent Syntax
public List<Product> GetAllMethod()
{
    List<Product> products = GetProducts();
    List<Product> list;

    list = products.Select(prod => prod).ToList();

    return list;
}

// Select One Columns using LINQ syntax
public List<string> GetSingleColumnQuery()
{
    List<Product> products = GetProducts();
    List<string> list = new();

    list.AddRange(from prod in products
                  select prod.Name);
    return list;
}

// Select One Columns using Fluent syntax
public List<string> GetSingleColumnMethod()
{
    List<Product> products = GetProducts();
    List<string> list = new();

    list.AddRange(products.Select(prod => prod.Name));
    return list;
}

// Query some columns using LINQ syntax
public List<Product> GetSpecificColumnsQuery()
{
    List<Product> products = GetProducts();
    List<Product> list;

    list = (from prod in products
            select new Product
            {
                ProductID = prod.ProductID,
                Name = prod.Name,
                Size = prod.Size
            }).ToList();

    return list;
}

// Query some columns using Fluent syntax
public List<Product> GetSpecificColumnsMethod()
{
    List<Product> products = GetProducts();
    List<Product> list;

    list = products.Select(prod => new Product
    {
        ProductID = prod.ProductID,
        Name = prod.Name,
        Size = prod.Size
    }).ToList();

    return list;
}

// Query some columns using anonimous class LINQ syntax
public string AnonymousClassQuery()
{
    List<Product> products = GetProducts();
    StringBuilder sb = new(2048);

    var list = (from prod in products
                select new
                {
                    Identifier = prod.ProductID,
                    ProductName = prod.Name,
                    ProductSize = prod.Size
                });

    // Loop through anonymous class
    foreach (var prod in list)
    {
        sb.AppendLine($"Product ID: {prod.Identifier}");
        sb.AppendLine($"   Product Name: {prod.ProductName}");
        sb.AppendLine($"   Product Size: {prod.ProductSize}");
    }

    return sb.ToString();
}


// Query some columns using anonimous class using Fluent syntax
public string AnonymousClassMethod()
{
    List<Product> products = GetProducts();
    StringBuilder sb = new(2048);

    // Write Method Syntax Here
    var list = products.Select(prod => new
    {
        Identifier = prod.ProductID,
        ProductName = prod.Name,
        ProductSize = prod.Size
    });

    // Loop through anonymous class
    foreach (var prod in list)
    {
        sb.AppendLine($"Product ID: {prod.Identifier}");
        sb.AppendLine($"   Product Name: {prod.ProductName}");
        sb.AppendLine($"   Product Size: {prod.ProductSize}");
    }

    return sb.ToString();
}

public List<Product> OrderByQuery()
{
    List<Product> products = GetProducts();
    List<Product> list;

    list = (from prod in products
            orderby prod.Color descending, prod.Name
            select prod).ToList();

    list = products.OrderBy(prod => prod.Name).ToList();
    list = products.OrderByDescending(prod => prod.Color)
                     .ThenBy(prod => prod.Name).ToList();
    list = products.OrderByDescending(prod => prod.Color)
                      .ThenByDescending(prod => prod.Name).ToList();

    return list;
}

public List<Product> WhereTwoFieldsQuery()
{
    List<Product> products = GetProducts();
    List<Product> list;

    list = (from prod in products
            where prod.Name.StartsWith("L") && prod.StandardCost > 200
            select prod).ToList();

    list = products.Where(prod => prod.Name.StartsWith("L") &&
                                  prod.StandardCost > 200).ToList();

    return list;
}

public List<Product> WhereExtensionQuery()
{
    List<Product> products = GetProducts();
    List<Product> list;

    list = (from prod in products
            select prod).ByColor("Red").ToList();
    list = products.ByColor("Red").ToList();

    return list;
}
return list;

