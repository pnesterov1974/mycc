﻿namespace utilsMsSql;

public class Class1
{

}
