using DbfDataReader;
using import_kladr_efc;
using import_kladr_efcpg.models;

namespace import_kladr_efcpg;

public static class FirstDBRun
{
    public static void KladrData()
    {
        using (KladrContext ctx = new KladrContext())
        {
            bool isAvailaible = ctx.Database.CanConnect();
            if (isAvailaible)
            {
                Console.WriteLine("Подключаюсь...");
                var kladrs = ctx.Kladrs.ToList();
                foreach (var kladr in kladrs)
                {
                    Console.WriteLine($"{kladr.NAME} {kladr.SOCR} {kladr.CODE} {kladr.INDEX} {kladr.GNINMB} {kladr.UNO} {kladr.OCATD} {kladr.STATUS}");
                }
            }
            else
            {
                Console.WriteLine("Подулючение недоступно...");
            }
        }
    }

    public static void SaveKladr()
    {
        using (KladrContext ctx = new KladrContext())
        {
            List<Kladr> kladr = FirstDBRun.DoImportKladr();
            foreach(var k in kladr)
            {
                ctx.Add<Kladr>(k);
            }
            int recs = ctx.SaveChanges();
            Console.WriteLine($"Записано {recs} записей");
        }
    }

    public static List<Kladr> DoImportKladr()
    {
        IImportObjectInfo oi = new KladrImportObjectInfo();
        List<Kladr> data = new List<Kladr>();
        DbfDataReaderOptions dbfOptions = new DbfDataReaderOptions { SkipDeletedRecords = true };
        string sourceFilePath = Path.Combine(oi.SourceDirPath, oi.SourceFileName);
        Console.WriteLine(sourceFilePath);
        using (var dbfDataReader = new DbfDataReader.DbfDataReader(sourceFilePath, dbfOptions))
        {
            while (dbfDataReader.Read())
            {   
                var name = dbfDataReader.GetString(0);
                var socr = dbfDataReader.GetString(1);
                var code = dbfDataReader.GetString(2);
                var index = dbfDataReader.GetString(3);
                var gninmb = dbfDataReader.GetString(4);
                var uno = dbfDataReader.GetString(5);
                var ocatd = dbfDataReader.GetString(6);
                var status = dbfDataReader.GetString(7);
                
                var kladr = new Kladr
                {
                    NAME = name,
                    SOCR = socr,
                    CODE = code,
                    INDEX = index,
                    GNINMB = gninmb,
                    UNO = uno,
                    OCATD = ocatd,
                    STATUS = int.Parse(status)
                };
                data.Add(kladr);
            }
        }
        Console.WriteLine($"Считано {data.Count} записей");
        return data;
    }
}
