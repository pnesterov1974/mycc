﻿namespace import_kladr;

public class ImportKladr
{
}
