from datetime import datetime

def filename_timestamp(d: datetime):
    dt = datetime.date(d)    
    dy = dt.year
    dm = dt.month
    dd = dt.day

    tt = datetime.time(d)
    th = tt.hour
    tm = tt.minute
    ts = tt.second
    tms = tt.microsecond

    di = '-'.join(list(map(str, [dy, dm, dd])))
    ti = '-'.join(list(map(str, [th, tm, ts, tms])))

    return '_'.join([di, ti])

# -----------------------------------------------------------------------------
if __name__ == "__main__": pass