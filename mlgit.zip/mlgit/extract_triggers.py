from pathlib import Path

import pymssql

from server_code import MSSQL_TRIGGERS_EXTRACTIION_SQL
from extract_metadata_mxn import ExtractMetadataMxn
from logger_conf import logger

class ExtractTriggers(ExtractMetadataMxn):
    SQL = MSSQL_TRIGGERS_EXTRACTIION_SQL
    SUBDIR_NAME = 'TRIGGERS'

    def __init__(self, server_name: str, db_name: str, repo_dir):
        self.__server_name = server_name
        self.__db_name = db_name
        self.__target_dir = Path(repo_dir) / ExtractTriggers.SUBDIR_NAME

    def __select_from_metadata(self, server_name: str, db_name: str):
        with pymssql.connect(server_name, ExtractTriggers.DB_USER, ExtractTriggers.DB_PASSWORD, db_name,
            appname='GitLab autocommit master branch'
            ) as conn:
            with conn.cursor(as_dict=True) as db_cursor:
                db_cursor.execute(ExtractTriggers.SQL)
                for r in db_cursor:
                    yield r

    def process(self):
        self.__target_dir.mkdir(parents=True, exist_ok=True)
        log_str = f'TRIGGERS into {self.__target_dir}'
        print(log_str)
        logger.debug(log_str)
        for r in self.__select_from_metadata(
                server_name=self.__server_name,
                db_name=self.__db_name
            ):
            schema_name = ExtractTriggers.str_for_filename(r['SchemaName'])
            proc_name = ExtractTriggers.str_for_filename(r['TriggerName'])
            proc_code = r['SQLCode']
            if not proc_code:
                log_str = f"Нет кода для триггера: {schema_name}.{proc_name}"
                print(log_str)
                logger.debug(log_str)
            else:
                proc_code = ExtractTriggers.check_create_or_alter(proc_code, sql_object_type_name='trigger')
                proc_code = ExtractTriggers.check_use_db(proc_code, self.__db_name)

                file_name = '_'.join([schema_name, proc_name])
                file_name_ext = '.'.join([file_name, 'sql'])

                target_file = Path(self.__target_dir) / file_name_ext
                Path.touch(target_file)
                
                with open(target_file, 'wt', encoding='utf-8', newline='') as f :
                    f.write(proc_code)
                ExtractTriggers.normalize_spaces(target_file)


# -----------------------------------------------------------------------------
if __name__ == "__main__": pass
