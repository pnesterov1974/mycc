import os, subprocess, tempfile
from datetime import datetime
from pathlib import Path

from logger_conf import logger
from server_code import get_ssas_script
from git_ops import GitOps 
from shared import filename_timestamp

REPO_SUBURL = 'https://gitlab.merlion.ru'

class ExtractSSAS:

    def __init__(self, server_name: str, db_name: str, group: str, repo: str):
        self.__server_name = server_name
        self.__db_name = db_name

        self.__repo_dir = Path(tempfile.gettempdir()) / 'ML_GITLAB' / repo / filename_timestamp(datetime.now())
        print(self.__repo_dir)
        logger.debug(f'Repo dir: {self.__repo_dir}\n')

        self.__repo_url = '/'.join([REPO_SUBURL, group, repo + '.git'])
        print(f'Repository full name: {self.__repo_url}')
        logger.debug(f'Repository full name: {self.__repo_url}')

        self.__script_filename = self.__repo_dir / '_extract_ssas.ps1'
        print(f'PS script full path: {self.__script_filename}')
        logger.debug(f'PS script full path: {self.__script_filename}')

        self.__git = GitOps(repo_dir=self.__repo_dir, repo_url=self.__repo_url)
        
    def __extract_ssas_script(self):
        self.__repo_dir.mkdir(parents=True, exist_ok=True)
        pss = get_ssas_script(self.__server_name, self.__repo_dir)
        logger.debug(f"ps script :\n {pss} \n")
        with open(self.__script_filename, 'w', encoding='utf-8', newline='') as f :
            f.write(pss)
        os.chdir(self.__repo_dir)
        c = subprocess.run(
                [r'powershell', r'./_extract_ssas.ps1'], 
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                shell=False)
        result_code = c.returncode
        logger.debug(f"RESULT CODE: {result_code}")
        logger.debug(f"stdout:\n {c.stdout}")
        logger.debug(f"stderr:\n {c.stderr}")

    def process(self):
        print(f"\n----> Обработка {self.__server_name}:{self.__db_name} из репо {self.__repo_dir}\n")

        self.__git.clone()
        self.__git.checkout()
        
        self.__extract_ssas_script()

        self.__git.add()
        self.__git.commit()
        self.__git.push()

# -----------------------------------------------------------------------------
if __name__ == "__main__": pass
