from pathlib import Path

import pymssql

from server_code import MSSQL_FUNCTIONS_EXTRACTIION_SQL
from extract_metadata_mxn import ExtractMetadataMxn
from logger_conf import logger

class ExtractFunctions(ExtractMetadataMxn):
    SQL = MSSQL_FUNCTIONS_EXTRACTIION_SQL
    SUBDIR_NAME = 'FUNCTIONS'

    def __init__(self, server_name: str, db_name: str, repo_dir):
        self.__server_name = server_name
        self.__db_name = db_name
        self.__target_dir = Path(repo_dir) / ExtractFunctions.SUBDIR_NAME

    def __select_from_metadata(self, server_name: str, db_name: str):
        self.__target_dir.mkdir(parents=True, exist_ok=True)
        with pymssql.connect(
            server_name, ExtractFunctions.DB_USER, ExtractFunctions.DB_PASSWORD, db_name,
            appname='GitLab autocommit master branch'
            ) as conn:
            with conn.cursor(as_dict=True) as db_cursor:
                db_cursor.execute(ExtractFunctions.SQL)
                for r in db_cursor:
                    yield r

    def process(self):
        self.__target_dir.mkdir(parents=True, exist_ok=True)
        log_str = f'FUNCTIONS into {self.__target_dir}'
        print(log_str)
        logger.debug(log_str)
        for r in self.__select_from_metadata(
                server_name=self.__server_name,
                db_name=self.__db_name
            ):
            schema_name = ExtractFunctions.str_for_filename(r['SchemaName'])
            func_name = ExtractFunctions.str_for_filename(r['FuncName'])
            func_code = r['SQLCode']
            if not func_code:
                log_str = f"Нет кода для функции: {schema_name}.{func_name}"
                print(log_str)
                logger.debug(log_str)
            else:
                func_code = ExtractFunctions.check_create_or_alter(func_code, sql_object_type_name="function")  #func
                func_code = ExtractFunctions.check_use_db(func_code, self.__db_name)

                file_name = '_'.join([schema_name, func_name])
                file_name_ext = '.'.join([file_name, 'sql'])

                target_file = Path(self.__target_dir) / file_name_ext
                Path.touch(target_file)
                
                with open(target_file, 'wt', encoding='utf-8', newline='') as f :
                    f.write(func_code)
                ExtractFunctions.normalize_spaces(target_file)


# -----------------------------------------------------------------------------
if __name__ == "__main__": pass
