
MSSQL_VIEWS_EXTRACTIION_SQL = """
SELECT v.[object_id]              AS [ObjectID],
       v.[name]                   AS [ViewName], 
       v.[schema_id]              AS [SchemaID], 
       sh.[name]                  AS [SchemaName],
       sh.[name] + '.' + v.[name] AS [ViewFullName],
       m.[definition]             AS [SQLCode]
FROM [sys].[views] v
INNER JOIN sys.[schemas] sh ON sh.[schema_id] = v.[schema_id]
INNER JOIN sys.[sql_modules] m ON m.[object_id] = v.[object_id];
"""

MSSQL_PROCEDURES_EXTRACTIION_SQL = """
SELECT p.[object_id]              AS [ObjectID],
       p.[name]                   AS [ProcName], 
       p.[schema_id]              AS [SchemaID], 
       sh.[name]                  AS [SchemaName],
       sh.[name] + '.' + p.[name] AS [ProcFullName],
       m.[definition]             AS [SQLCode]
FROM sys.[procedures] p
INNER JOIN sys.[schemas] sh ON sh.[schema_id] = p.[schema_id]
INNER JOIN sys.[sql_modules] m ON m.[object_id] = p.[object_id]
WHERE p.[type] = 'P';
"""

MSSQL_FUNCTIONS_EXTRACTIION_SQL = """
SELECT o.[object_id]    AS [ObjectID],
       o.[name]         AS [FuncName],
	   o.[schema_id]    AS [SchemaID],
	   sh.[name]        AS [SchemaName],
       m.[definition]   AS [SQLCode]
FROM sys.[objects] AS o
INNER JOIN sys.[schemas] sh ON sh.[schema_id] = o.[schema_id]
INNER JOIN sys.[sql_modules] m ON m.[object_id] = o.[object_id]
WHERE o.[type] IN (N'FN', N'IF', N'TF', N'FS', N'FT')
"""

MSSQL_TRIGGERS_EXTRACTIION_SQL = """
SELECT o.[object_id]    AS [ObjectID],
       o.[name]         AS [TriggerName],
	   o.[schema_id]    AS [SchemaID],
	   sh.[name]        AS [SchemaName],
       m.[definition]   AS [SQLCode]
FROM sys.[objects] AS o
INNER JOIN sys.[schemas] sh ON sh.[schema_id] = o.[schema_id]
INNER JOIN sys.[sql_modules] m ON m.[object_id] = o.[object_id]
WHERE o.[type] = N'TR'
"""

# -----------------------------------------------------------------------------
def get_ssas_script(server_name: str, target_folder: str) :

    ps1 = r'''

#cls;
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices") >$NULL
 
$SourceServers = @( "@ServerName" );
$path="@TargetPathName\"

Get-ChildItem -Path $path -Recurse | Remove-Item -force -recurse

$stringbuilder = new-Object System.Text.StringBuilder
$stringwriter = new-Object System.IO.StringWriter($stringbuilder)
$xmlOut = New-Object System.Xml.XmlTextWriter($stringwriter)
$xmlOut.Formatting = [System.Xml.Formatting]::Indented
$ScriptObject = New-Object Microsoft.AnalysisServices.Scripter
 
ForEach( $srv in $SourceServers )
{
    $server = New-Object Microsoft.AnalysisServices.Server
    $server.connect($srv)
    ForEach(  $database in $server.Databases ) 
    {    
        $db_dir = $path + $database.Name + "\"
        New-Item -ItemType directory -Path $db_dir >$NULL
        $dims_dir = $db_dir + "dimensions\"
        New-Item -ItemType directory -Path $dims_dir >$NULL

        Write-Host  ">>>>>>>>>>>dimensions"
        ForEach(   $dim in $database.Dimensions ) 
        {
            Write-Host  $dim.Name" : "$dim.LastProcessed
            $MSASObject = [Microsoft.AnalysisServices.MajorObject[]] @($dim)
            $stringbuilder.Clear()>$NULL
            $ScriptObject.ScriptCreate($MSASObject,$xmlOut,$false)
            $file_name = $dims_dir + $dim.Name + ".xmla"
            $stringbuilder.ToString() |out-file -filepath $file_name
        }

        $cubes_dir = $db_dir + "cubes\"
        New-Item -ItemType directory -Path $cubes_dir >$NULL

        $MSASObject=[Microsoft.AnalysisServices.MajorObject[]] @($database)
        $stringbuilder.Clear()>$NULL
        $ScriptObject.ScriptCreate($MSASObject,$xmlOut,$false)
        $stringbuilder.ToString() |out-file -filepath $db_dir"full.xmla"
    
        Write-Host  ">>>>>>>>>>>cubes"
        ForEach(   $cub in $database.Cubes )
        {

            $cub_dir = $cubes_dir + $cub.Name + "\"
            New-Item -ItemType directory -Path $cub_dir >$NULL

            $MSASObject=[Microsoft.AnalysisServices.MajorObject[]] @($cub)
            $stringbuilder.Clear()>$NULL
            $ScriptObject.ScriptCreate($MSASObject,$xmlOut,$false)
            $stringbuilder.ToString() |out-file -filepath $cub_dir"full.xmla"
            if($cub.DefaultMdxScript.Commands.Count -gt 0)
            {  
                $cub.DefaultMdxScript.Commands[0].Text|out-file -filepath $cub_dir"DefaultMdxScript.xmla"
            };
               
            $roles_dir = $cub_dir + "roles\"
            New-Item -ItemType directory -Path $roles_dir >$NULL

            ForEach(   $role in $database.Roles ) 
            {
                $MSASObject=[Microsoft.AnalysisServices.MajorObject[]] @($role)
                $stringbuilder.Clear()>$NULL
                $ScriptObject.ScriptCreate($MSASObject,$xmlOut,$false)
                $role_path = $roles_dir + $role.Name + ".xmla"
                $stringbuilder.ToString() |out-file -filepath $role_path
            }


            $mgs_dir = $cub_dir + "measure_groups\"
            New-Item -ItemType directory -Path $mgs_dir >$NULL

            ForEach( $mg in $cub.MeasureGroups ) 
            {
                $mg_dir = $mgs_dir + $mg.Name + "\"
				Write-Host  "Measure Group:"$mg.Name"- State:"$mg.State": "$mg.LastProcessed
                New-Item -ItemType directory -Path $mg_dir >$NULL
                ForEach(   $prt in $mg.Partitions ) 
                {
                    $stringbuilder.Clear()>$NULL
                     
                    $prt_file_name = $mg_dir + $prt.Name + "." + $prt.Source.DataSourceID + ".sql"
                    Write-Host  $prt.Name" : "$prt.LastProcessed

                    if($prt.Source.QueryDefinition.Length -gt 0) 
                    {
                        $prt.Source.QueryDefinition |out-file -filepath $prt_file_name
                    } 
                    elseif($prt.Source.DbTableName.Length -gt 0) 
                    {
                        $prt.Source.DbTableName|out-file -filepath $prt_file_name
                    }
                    else 
                    {
                        $prt.Source.TableID|out-file -filepath $prt_file_name
                    }  
                }
            }
        }
    }    
}

'''.replace('@ServerName', str(server_name)).replace('@TargetPathName', str(target_folder))
    
    return ps1


# -----------------------------------------------------------------------------
def get_ssis_script(server_name: str, project_name: str, target_folder: str) :

    ps1 = r'''

$SsisServer = "@SSISServer"
$FolderName = "SSIS Packages"
$ProjectName = "@ProjectName"
$DownloadFolder = "@TargetFolder"
$UnzipIspac = $false

if (-not $DownloadFolder.EndsWith("\"))
{
    $DownloadFolder = $DownloadFolder + "\"
}

Clear-Host
Write-Host "========================================================================================================================================================"
Write-Host "== Used parameters =="
Write-Host "========================================================================================================================================================"
Write-Host "SSIS Server             :" $SsisServer
Write-Host "Folder Name             :" $FolderName
Write-Host "Project Name            :" $ProjectName
Write-Host "Local Download Folder   :" $DownloadFolder
Write-Host "========================================================================================================================================================"


########## SERVER ##########

# Load the Integration Services Assembly
Write-Host "Connecting to server $SsisServer "
$SsisNamespace = "Microsoft.SqlServer.Management.IntegrationServices"
[System.Reflection.Assembly]::LoadWithPartialName($SsisNamespace) | Out-Null;

# Create a connection to the server
$SqlConnectionstring = "Data Source=" + $SsisServer + ";Initial Catalog=master;Integrated Security=SSPI;"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection $SqlConnectionstring

# Create the Integration Services object
$IntegrationServices = New-Object $SsisNamespace".IntegrationServices" $SqlConnection

# Check if connection succeeded
if (-not $IntegrationServices)
{
    Throw [System.Exception] "Failed to connect to server $SsisServer "
}
else
{
    Write-Host "Connected to server" $SsisServer
}


########## CATALOG ##########

# Create object for SSISDB Catalog
$Catalog = $IntegrationServices.Catalogs["SSISDB"]

# Check if the SSISDB Catalog exists
if (-not $Catalog)
{
    # Catalog doesn't exists. Different name used?
    Throw [System.Exception] "SSISDB catalog doesn't exist."
}
else
{
    Write-Host "Catalog SSISDB found"
}


########## FOLDER ##########

if ($FolderName -ne "")
{
    # Create object to the folder
    $Folder = $Catalog.Folders[$FolderName]
    # Check if folder exists
    if (-not $Folder)
    {
        # Folder doesn't exists, so throw error.
        Write-Host "Folder" $FolderName "not found"
        Throw [System.Exception] "Aborting, folder not found"
    }
    else
    {
        Write-Host "Folder" $FolderName "found"
    }
}


########## Project ##########

if ($ProjectName -ne "" -and $FolderName -ne "")
{
    $Project = $Folder.Projects[$ProjectName]
    # Check if project already exists
    if (-not $Project)
    {
        # Project doesn't exists, so throw error.
        Write-Host "Project" $ProjectName "not found"
        Throw [System.Exception] "Aborting, project not found"
    }
    else
    {
        Write-Host "Project" $ProjectName "found"
    }
}

########## Downloading ##########

Write-Host $DownloadFolder
New-Item -ItemType Directory -Path $DownloadFolder -Force > $null

# Check if new ispac already exists
if (Test-Path ($DownloadFolder + $Project.Name + ".ispac"))
{
    Write-Host ("Downloading [" + $Project.Name + ".ispac" + "] to " + $DownloadFolder + " (Warning: replacing existing file)")
}
else
{
    Write-Host ("Downloading [" + $Project.Name + ".ispac" + "] to " + $DownloadFolder)
}

# Download ispac
$ISPAC = $Project.GetProjectBytes()
[System.IO.File]::WriteAllBytes(($DownloadFolder + "\" + $Project.Name + ".ispac"),$ISPAC)
if ($UnzipIspac)
{
    # Add reference to compression namespace
    Add-Type -assembly "system.io.compression.filesystem"

    # Extract ispac file to temporary location (.NET Framework 4.5) 
    Write-Host ("Unzipping [" + $Project.Name + ".ispac" + "]")

    # Delete unzip folder if it already exists
    if (Test-Path ($DownloadFolder + "\" + $Project.Name))
    {
        [System.IO.Directory]::Delete(($DownloadFolder + "\" + $Project.Name), $true)
    }

    # Unzip ispac
    [io.compression.zipfile]::ExtractToDirectory(($DownloadFolder + "\" + $Project.Name + ".ispac"), ($DownloadFolder + "\" + $Project.Name))

    # Delete ispac
    Write-Host ("Deleting [" + $Project.Name + ".ispac" + "]")
    [System.IO.File]::Delete(($DownloadFolder + "\" + $Project.Name + ".ispac"))
}

########## Finalizing ##########
# Kill connection to SSIS
$IntegrationServices = $null
Write-Host "Finished, total downloads"
'''.replace('@SSISServer', server_name).replace('@ProjectName', project_name).replace('@TargetFolder', target_folder)

    return ps1

# -----------------------------------------------------------------------------
if __name__ == '__main__': pass