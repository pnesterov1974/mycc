from settings import DB_USER as DBU
from settings import DB_PASSWORD as DBP

class ExtractMetadataMxn:
    DB_USER     = DBU
    DB_PASSWORD = DBP

    @staticmethod
    def str_for_filename(source: str) :
        if source :
            return source.replace("\\", "_").replace("<", "%").replace(">", "%").replace("/", "_")
        else :
            return "%"

    @staticmethod
    def normalize_spaces(file_path):

        def process_line(line: list):
            ll = line.lower()
            if ('create' in ll) and ('or' in ll) and ('alter' in ll):
                lc = line.split()
                return ' '.join(lc) + '\n'
            else:
                return line

        new_lines = []
        with open(file_path, "r", encoding='utf-8', newline='') as f:
            lines = f.readlines()
            for l in lines:
                new_lines.append(process_line(l))

        if len(new_lines) > 0:
            with open(file_path, "w" , encoding='utf-8', newline='') as f:
                f.writelines(new_lines)

    @staticmethod
    def check_create_or_alter(astr: str, sql_object_type_name: str):
        #
        la = astr.lower().split()  # весть текст в нижний регистр
        
        try:
            _create_i = la.index('create')   # первое вхождение create
        except ValueError:
            _creata_i = -1

        try:
            _or_i = la.index('or')  # первое вхождение or
        except ValueError:
            _or_i = -1

        try:
            _alter_i = la.index('alter') # первое вхождение alter
        except ValueError:
            _alter_i = -1

        try:
            _sql_type_i = la.index(sql_object_type_name.lower()) # первое вхождение sql_object_type
        except ValueError:
            _sql_type_i = -1

        already_replaced = (   #признак того, что менять ничего не нужно
            (_create_i > -1) and (_or_i == _create_i + 1) and (_alter_i == _or_i + 1) 
            and (_sql_type_i == _alter_i + 1)
            )
        
        if (_create_i > -1) and not already_replaced:
            _l_create_i = astr.find('create')
            _u_create_i = astr.find('CREATE')
            replaced = False
            if _l_create_i == -1:
                astr = astr.replace('CREATE', 'CREATE OR ALTER', 1)
                replaced = True
            if _u_create_i == -1:
                astr = astr.replace('create', 'CREATE OR ALTER', 1)
                replaced = True

            if not replaced:
                if _l_create_i < _u_create_i:
                    astr = astr.replace('create', 'CREATE OR ALTER', 1)
                elif _l_create_i > _u_create_i:
                    astr = astr.replace('CREATE', 'CREATE OR ALTER', 1)
        return astr
    
    # @staticmethod
    # def check_use_db(script: str, db_name: str):
    #     la = script.lower().split()
        
    #     try:
    #         _has_use = la.index('use')
    #     except ValueError:
    #         _has_use = -1

    #     try:
    #         _has_use_db = la.index(db_name.lower().join(['[', ']']))
    #     except ValueError:
    #         _has_use_db = -1

    #     _already_has_usedb = (_has_use > 0) and (_has_use_db == _has_use + 1)
        
    #     if not _already_has_usedb:
    #         astr = ' '.join(['USE', db_name.join(['[', ']'])])
    #         astr = '\n'.join([astr, 'GO'])
    #         #return '\n'.join([astr, '', script])
    #         return '\n'.join([astr, script])  # попробовать 1
    #     else:
    #         return script
        
        #if not _already_has_use:             # попробовать 2
        #    udb = 'USE [{db_name}]\nGO'
        #    return f'{udb}\n{script}'
    
    @staticmethod
    def check_use_db(script: str, db_name: str):

        def get_new_script(ascript: str):
            #1. Вычисление строки, корорая начинается с CREATE и не коммент
            #2. Удаление всего что выше
            lines = script.split('\n')
            for i, l in enumerate(lines):
                words = l.lower().split()
                _has_create = 'create' in words
                _create_index = words.index('create') if _has_create else -1

                words2s = list(map(lambda s: s[:2], words))
                _has_comment = '--' in words2s
                _has_comment_index = words2s.index('--') if _has_comment else -1

                _commented = _has_comment and _has_comment_index < _create_index
                # TODO: commented by /* */

                if _has_create and not _commented:
                    new_script_lines = lines[i:]
                    return '\n'.join(new_script_lines)
            return script

        nscript = get_new_script(script)
        #3. Выше строки CREATE добавляем USE DBn GO \n " "  \n
        udb = f'USE [{db_name}]\nGO\n'

        udbs = '\n'.join([udb, nscript])

        return udbs

        
        
        

# -----------------------------------------------------------------------------
if __name__ == "__main__": pass
