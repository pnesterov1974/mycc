from pathlib import Path

import pymssql

# from server_code import MSSQL_FUNCTIONS_EXTRACTIION_SQL
from server_code_t import (
    list_of_tables_sql,
    list_of_table_fields_sql,
    list_pk_sql,
    list_pk_fields_sql,
    list_nonclustered_indexes,
    list_nonclustered_indexes_key_columns,
    list_nonclustered_indexes_include_columns,
    list_of_check_constraints_sql,
    list_index_options,
    get_fk_sql,
)

from extract_metadata_mxn import ExtractMetadataMxn
from logger_conf import logger

TAB_CHARACTERS = ' ' * 4

class ExtractTables(ExtractMetadataMxn):
    SUBDIR_NAME = "TABLES"

    def __init__(self, server_name: str, db_name: str, repo_dir):
        self.__server_name = server_name
        self.__db_name = db_name
        self.__target_dir = Path(repo_dir) / ExtractTables.SUBDIR_NAME
        self.__tables = None
        self.init_table_list()

    def for_each_object(self, sql: str):
        with pymssql.connect(
            self.__server_name,
            ExtractTables.DB_USER,
            ExtractTables.DB_PASSWORD,
            self.__db_name,
            appname="GitLab autocommit master branch",
        ) as conn:
            with conn.cursor(as_dict=True) as db_cursor:
                db_cursor.execute(sql)
                for r in db_cursor:
                    yield r

    def init_table_list(self):
        self.__tables = [
            t
            for t in ExtractTables.for_each_object(sql=list_of_tables_sql)
            # if t["table_name"] == "nacitilink#value_entry"
            if t["table_name"] == "PRRF"
        ]


    def get_table_name_by_table_id(self, table_id):
        for t in self.__tables:
            if t['table_id']==table_id:
                return {
                    'table_name': t['table_name'],
                    'schema_name': t['schema_name']
                }

    def get_table_field_list(self, table_id: int):
        sql = list_of_table_fields_sql(table_id)
        ll = list()
        for r in ExtractTables.for_each_object(sql):
            l = TAB_CHARACTERS +  ' '.join([i for i in r.values()])
            ll.append(l)
        ls = ',\n'.join(ll)
        return ls

    def get_pk(self, table_id: int):
        sql = list_pk_sql(table_id)
        for r in ExtractTables.for_each_object(sql):
            return r
        
    def get_pk_fields(self, table_id: int, unique_index_id: int):
        sql = list_pk_fields_sql(object_id=table_id, unique_index_id=unique_index_id)
        ll = list()
        for r in ExtractTables.for_each_object(sql):
            l = TAB_CHARACTERS + r['idx_field_name']
            ll.append(l)
        ls = ',\n'.join(ll)
        return ls
    
    def get_list_nonclustered_indexes(self, table_id: int):
        sql = list_nonclustered_indexes(object_id=table_id)
        for r in ExtractTables.for_each_object(sql):
            yield {
                'name': r['name'],
                'index_id': r['index_id'],
                'is_unique': r['is_unique']
            }

    def process_indexes_for_table(self, table_id: int):
        for idx in self.get_list_nonclustered_indexes(table_id=table_id):
            idx_id = idx['index_id']
            tn = self.get_table_name_by_table_id(table_id=table_id)
            table_name = tn['table_name']
            schema_name = tn['schema_name']
            if idx['is_unique'] == 1:
                t1 = f"\nCREATE UNIQUE NONCLUSTERED INDEX {idx['name']} ON [{schema_name}].[{table_name}] ("
            else:
                t1 = f"\nCREATE NONCLUSTERED INDEX {idx['name']} ON [{schema_name}].[{table_name}] ("
            sql3 = list_index_options(table_id=table_id, index_id=idx_id)
            _ll = list([r for r in ExtractTables.for_each_object(sql3)][0].values())
            ll3 = _ll[:5]
            ll4 = _ll[6]
            t7 = 'WITH ('
            t8 = ', '.join(ll3)
            t9 = f') ON {ll4};'
            
            sql1 = list_nonclustered_indexes_key_columns(table_id=table_id, index_id=idx_id)
            ll1 = [TAB_CHARACTERS + r['name'] for r in ExtractTables.for_each_object(sql1)]
            if len(ll1) > 0:
                t2 = ',\n'.join(ll1)
                t3 = ')'
                sql2 = list_nonclustered_indexes_include_columns(table_id=table_id, index_id=idx_id)
                ll2 = [TAB_CHARACTERS + r['name'] for r in ExtractTables.for_each_object(sql2)]
                if len(ll2) > 0:
                    t4 = 'INCLUDE ('
                    t5 = ',\n'.join(ll2)
                    t6 = ')'
                    t = '\n'.join([t1, t2, t3, t4, t5, t6, t7, t8, t9])
                else:
                    t = '\n'.join([t1, t2, t3, t7, t8, t9])
            return t

    def process_check_constraints_for_table(self, table_id: int):
        sql = list_of_check_constraints_sql(table_id)
        for cc in ExtractTables.for_each_object(sql):
            tn = self.get_table_name_by_table_id(table_id=table_id)
            table_name = tn['table_name']
            schema_name = tn['schema_name']
            t1 = f"\nALTER TABLE [{schema_name}].[{table_name}] WITH CHECK ADD CONSTRAINT [{cc['name']}]"
            t2 = TAB_CHARACTERS + f"CHECK {cc['definition']};"
            t = '\n'.join([t1, t2])
            return t

    def iter_process_tables(self):
        final_list = []
        for t in self.__tables:
            tn = f"[{t['schema_name']}].[{t['table_name']}]"
            ct1 = f"CREATE TABLE {tn} ("
            ct2 = self.get_table_field_list(t['table_id'])
            final_list.append(ct1)
            final_list.append(ct2)
            _pk = self.get_pk(t['table_id'])
            if _pk and len(_pk) > 0:
                ct3 = f"CONSTRAINT [{_pk['pk_name']}] PRIMARY KEY CLUSTERED ("
                ct4 = self.get_pk_fields(table_id=t['table_id'], unique_index_id=_pk['unique_index_id'])
                ct41 = ') WITH ('

                sql3 = list_index_options(table_id=_pk['pk_table_id'], index_id=_pk['unique_index_id'])

                _ll = list([r for r in ExtractTables.for_each_object(sql3)][0].values())
            
                ll3 = _ll[:5]
                ll4 = _ll[6]
                
                ct42 = ', '.join(ll3)
                ct43 = f') ON {ll4}'
            
                final_list.append(ct3)
                final_list.append(ct4)
                final_list.append(ct41)
                final_list.append(ct42)
                final_list.append(ct43)
    
            ct6 = ");"
            final_list.append(ct6)

            fks = None
            fk_sql = get_fk_sql(table_id=t['table_id'], table_name=tn)

            fks = [r['fk_sql_script'] for r in ExtractTables.for_each_object(fk_sql)]
            if fks and len(fks) > 0:
                fkss = '\n' + '\n'.join(fks)
                final_list.append(fkss)

            ii = self.process_indexes_for_table(t['table_id'])
            if ii and len(ii) > 0:
                final_list.append(ii)
            cc = self.process_check_constraints_for_table(t['table_id'])
            if cc and len(cc) > 0:
                final_list.append(cc)
            ct = '\n'.join(final_list)

            rd = {
                'schema_name': ExtractTables.str_for_filename(t['schema_name']),
                'table_name': ExtractTables.str_for_filename(t['table_name']),
                'SQLCode': ct
            }
            return rd

    def process(self):
        self.__target_dir.mkdir(parents=True, exist_ok=True)
        log_str = f"TABLES into {self.__target_dir}"
        print(log_str)
        logger.debug(log_str)

        for r in self.process_tables():
            file_name = "_".join([r['schema_name'], r['table_name'])
            file_name_ext = ".".join([file_name, "sql"])

            target_file = Path(self.__target_dir) / file_name_ext
            Path.touch(target_file)

            with open(target_file, "wt", encoding="utf-8", newline="") as f:
                    f.writelines(r['SQLCode'])

# -----------------------------------------------------------------------------
if __name__ == "__main__": pass
