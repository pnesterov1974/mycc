from pathlib import Path

import pymssql

from server_code import MSSQL_VIEWS_EXTRACTIION_SQL
from extract_metadata_mxn import ExtractMetadataMxn
from logger_conf import logger

class ExtractViews(ExtractMetadataMxn):
    SQL = MSSQL_VIEWS_EXTRACTIION_SQL
    SUBDIR_NAME = 'VIEWS'

    def __init__(self, server_name: str, db_name: str, repo_dir):
        self.__server_name = server_name
        self.__db_name = db_name
        self.__target_dir = Path(repo_dir) / ExtractViews.SUBDIR_NAME

    def __select_from_metadata(self, server_name: str, db_name: str):
        with pymssql.connect(server_name, ExtractViews.DB_USER, ExtractViews.DB_PASSWORD, db_name,
                appname='GitLab autocommit master branch'
            ) as conn:
            with conn.cursor(as_dict=True) as db_cursor:
                db_cursor.execute(ExtractViews.SQL)
                for r in db_cursor:
                    yield r

    def process(self):
        try:
            self.__target_dir.mkdir(parents=True, exist_ok=True)
            log_str = f'VIEWS into {self.__target_dir}'
            print(log_str)
            logger.debug(log_str)
            for r in self.__select_from_metadata(
                    server_name=self.__server_name,
                    db_name=self.__db_name
                ):
                schema_name = ExtractViews.str_for_filename(r['SchemaName'])
                view_name = ExtractViews.str_for_filename(r['ViewName'])
                view_code = r['SQLCode']
                if not view_code:
                    log_str = f"Нет кода для представления: {schema_name}.{view_name}"
                    print(log_str)
                    logger.debug(log_str)
                else:
                    view_code = ExtractViews.check_create_or_alter(view_code, sql_object_type_name='view')
                    view_code = ExtractViews.check_use_db(view_code, self.__db_name)

                    file_name = '_'.join([schema_name, view_name])
                    file_name_ext = '.'.join([file_name, 'sql'])

                    target_file = Path(self.__target_dir) / file_name_ext
                    Path.touch(target_file)
                    
                    with open(target_file, 'wt', encoding='utf-8', newline='') as f :
                        f.write(view_code)
                    ExtractViews.normalize_spaces(target_file)
        except Exception as ex:
            raise ValueError(str(ex))



# -----------------------------------------------------------------------------
if __name__ == "__main__": pass
