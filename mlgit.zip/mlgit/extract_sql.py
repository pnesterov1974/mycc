import tempfile
from pathlib import Path
from datetime import datetime

from logger_conf import logger
from extract_views import ExtractViews
from extract_functions import ExtractFunctions
from extract_procedures import ExtractProcedures
from extract_triggers import ExtractTriggers
from extract_tables import ExtractTables
from git_ops import GitOps
from shared import filename_timestamp

REPO_SUBURL = 'https://gitlab.merlion.ru'

class ExtractSql:

    def __init__(self, server_name: str, db_name: str, group: str, repo: str):
        self.__server_name = server_name
        self.__db_name = db_name
        
        self.__repo_dir = Path(tempfile.gettempdir()) / 'ML_GITLAB' / repo / filename_timestamp(datetime.now())
        print(self.__repo_dir)
        logger.debug(f'Temp dir: {self.__repo_dir}\n')

        self.__repo_url = '/'.join([REPO_SUBURL, group, repo + '.git'])
        print(f'Repository full name: {self.__repo_url}')
        logger.debug(f'Repository full name: {self.__repo_url}')

        self.__git = GitOps(repo_dir=self.__repo_dir, repo_url=self.__repo_url)
        
        self.__views = ExtractViews(
            server_name=server_name, db_name=db_name, repo_dir=self.__repo_dir
            )
        self.__functions = ExtractFunctions(
            server_name=server_name, db_name=db_name, repo_dir=self.__repo_dir
            )
        self.__procedures = ExtractProcedures(
            server_name=server_name, db_name=db_name, repo_dir=self.__repo_dir
            )
        self.__triggers = ExtractTriggers(
            server_name=server_name, db_name=db_name, repo_dir=self.__repo_dir
            )
        self.__tables = ExtractTables(
            server_name=server_name, db_name=db_name, repo_dir=self.__repo_dir
            )
        
    def process(self):
        print(f"\n----> Обработка {self.__server_name}:{self.__db_name} из репо {self.__repo_dir}\n")
        
        def _rmdir(directory):
            directory = Path(directory)
            for item in directory.iterdir():
                if item.is_dir():
                    _rmdir(item)
                else:
                    item.unlink()
            directory.rmdir()

        try:
            print(f'папка {self.__repo_dir}')
            self.__git.clone()
            self.__git.checkout()

            print(f'Процедура очистки...')
            logger.debug(f'Процедура очистки...')
            
            v = self.__repo_dir / 'VIEWS'
            if v.exists():
                _rmdir(v)
            f = self.__repo_dir / 'FUNCTIONS'
            if f.exists():
                _rmdir(f)
            p = self.__repo_dir / 'PROCEDURES'
            if p.exists():
                _rmdir(p)
            t = self.__repo_dir / 'TRIGGERS'
            if t.exists():
                _rmdir(t)
            t = self.__repo_dir / 'TABLES'
            if t.exists():
                _rmdir(t)
            print(f'Процедура очистки завершена')
            logger.debug(f'Процедура очистки завершена')

            self.__views.process()
            self.__functions.process()
            self.__procedures.process()
            self.__triggers.process()
            self.__tables.process()

            self.__git.add()
            self.__git.commit()
            self.__git.push()

        except Exception as ex:
            err_msg = str(ex)
            print(err_msg)
            raise ValueError(err_msg)

# -----------------------------------------------------------------------------
if __name__ == "__main__": pass


