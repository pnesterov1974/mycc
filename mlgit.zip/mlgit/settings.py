DB_USER     = r'MERLION\srv_san'
DB_PASSWORD = r'N32bzwtqLe'

GIT_USERNAME = r'srv_san'
GIT_EMAIL    = r'srv_san@merlion.ru'
GIT_PASSWORD = r'Extlvo%40ML'

DBOBJECTS = [
    {'SERVER' : 'GALAXY',  'DBNAME': 'OLYMPDB',     'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/olympdb.git'            },
    {'SERVER' : 'GALAXY',  'DBNAME': 'naGDR',       'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/nagdr.git'              },
    {'SERVER' : 'GALAXY',  'DBNAME': 'naMerlion',   'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/namerlion.git'          },
    {'SERVER' : 'GALAXY',  'DBNAME': 'naPCM',       'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/napcm.git'              },
    {'SERVER' : 'GALAXY',  'DBNAME': 'naPowercom',  'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/napowercom.git'         },
    {'SERVER' : 'NAOS',    'DBNAME': 'naSC',        'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/nasc.git'               },
    
    {'SERVER' : 'GALAXY',  'DBNAME': 'CardItem',    'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/carditem.git'           },
    {'SERVER' : 'GALAXY',  'DBNAME': 'nfMain',      'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/nfmain.git'             },
    {'SERVER' : 'GALAXY',  'DBNAME': 'nfImage',     'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/nfimage.git'            },
    {'SERVER' : 'GALAXY',  'DBNAME': 'Shared_Arch', 'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/shared_arch.git'        },
    
    {'SERVER' : 'GALAXY',  'DBNAME': 'SharedDB',    'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/shareddb.git'           },
    {'SERVER' : 'DWH',     'DBNAME': 'DB_DWH',      'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/db_dwh.git'             },
    {'SERVER' : 'DWH',     'DBNAME': 'DB_DWH_Stage','KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/db_dwh_stage.git'       },
    
    {'SERVER' : 'OLYMP',         'DBNAME': 'SSAS',        'KIND': 'SSAS', 'REPO': 'https://gitlab.merlion.ru/sql/ssas.git'         },
    {'SERVER' : 'MLSQL-MERCURY', 'DBNAME': 'naMercury',   'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/namercury.git'    },
    {'SERVER' : 'MLSQL-REC',     'DBNAME': 'SharedDB',    'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/shareddbrec.git'  },
    {'SERVER' : 'MLSQL-CAN',     'DBNAME': 'naBuro',      'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/naburo.git'       },
    {'SERVER' : 'MLSQL-CAN',     'DBNAME': 'nfStaff',     'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/nfstaff.git'      },
    {'SERVER' : 'SPICA',         'DBNAME': 'izMerlion',   'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/izMerlion.git'    },
    {'SERVER' : 'MLSQL-REC',     'DBNAME': 'naRecCenter', 'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql/nareccenter.git'  },
    {'SERVER' : 'NAOS',     'DBNAME': 'naBPC', 'KIND': 'SQL',  'REPO': 'https://gitlab.merlion.ru/sql_gitlab/nabpc.git'  },
]

# -----------------------------------------------------------------------------
if __name__ == '__main__' : pass