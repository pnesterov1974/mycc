from pathlib import Path

import pymssql

from server_code import MSSQL_PROCEDURES_EXTRACTIION_SQL
from extract_metadata_mxn import ExtractMetadataMxn
from logger_conf import logger

class ExtractProcedures(ExtractMetadataMxn):
    SQL = MSSQL_PROCEDURES_EXTRACTIION_SQL
    SUBDIR_NAME = 'PROCEDURES'

    def __init__(self, server_name: str, db_name: str, repo_dir):
        self.__server_name = server_name
        self.__db_name = db_name
        self.__target_dir = Path(repo_dir) / ExtractProcedures.SUBDIR_NAME

    def __select_from_metadata(self, server_name: str, db_name: str):
        with pymssql.connect(
            server_name, ExtractProcedures.DB_USER, ExtractProcedures.DB_PASSWORD, db_name,
            appname='GitLab autocommit master branch'
            ) as conn:
            with conn.cursor(as_dict=True) as db_cursor:
                db_cursor.execute(ExtractProcedures.SQL)
                for r in db_cursor:
                    yield r

    def process(self):
        self.__target_dir.mkdir(parents=True, exist_ok=True)
        log_str = f'PROCEDURES into {self.__target_dir}'
        print(log_str)
        logger.debug(log_str)
        for r in self.__select_from_metadata(
                server_name=self.__server_name,
                db_name=self.__db_name
            ):
            schema_name = ExtractProcedures.str_for_filename(r['SchemaName'])
            proc_name = ExtractProcedures.str_for_filename(r['ProcName'])
            proc_code = r['SQLCode']
            if not proc_code:
                log_str = f"Нет кода для процедуры: {schema_name}.{proc_name}"
                print(log_str)
                logger.debug(log_str)
            else:
                proc_code = ExtractProcedures.check_create_or_alter(proc_code, sql_object_type_name='procedure')
                #proc_code = ExtractProcedures.check_use_db_2(proc_code, self.__db_name)
                proc_code = ExtractProcedures.check_use_db(proc_code, self.__db_name)

                file_name = '_'.join([schema_name, proc_name])
                file_name_ext = '.'.join([file_name, 'sql'])

                target_file = Path(self.__target_dir) / file_name_ext
                Path.touch(target_file)
                
                with open(target_file, 'wt', encoding='utf-8', newline='') as f :
                    f.write(proc_code)
                ExtractProcedures.normalize_spaces(target_file)


# -----------------------------------------------------------------------------
if __name__ == "__main__": pass
