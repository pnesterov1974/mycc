import os
import subprocess
from datetime import datetime
from pathlib import Path

from logger_conf import logger
from settings import GIT_USERNAME, GIT_EMAIL, GIT_PASSWORD
from shared import filename_timestamp

class GitOps:
    GITLAB_USERNAME = GIT_USERNAME
    GITLAB_EMAIL = GIT_EMAIL
    GITLAB_PASSWORD = GIT_PASSWORD

    @staticmethod
    def shell_command(cl: list):
        sbpr = subprocess.run(cl, 
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, 
            encoding='utf-8' 
        )
        result_code = sbpr.returncode
        logger.debug(f"{str(sbpr)}")
        logger.debug(f"RESULT CODE: {result_code}")
        logger.debug(f"stdout:\n {sbpr.stdout}")
        logger.debug(f"stderr:\n {sbpr.stderr}")

        return sbpr.returncode==0, sbpr.stdout, sbpr.stderr

    @staticmethod
    def get_repo_with_credentials(repo: str):
        i = repo.index(r'//')
        lstr = repo[:i+2]
        rstr = repo[i+2:]
        cred = ''.join([':'.join([GIT_USERNAME, GIT_PASSWORD]), '@'])
        return cred.join([lstr, rstr])

    def __init__(self, repo_dir, repo_url: str):
        self.__repo_dir = repo_dir
        self.__repo_url = GitOps.get_repo_with_credentials(repo_url)
        logger.debug(f'Git repo with creds: {self.__repo_url}')

    def clone(self):
        print(f'Repo cloning into ... {self.__repo_dir}')
        resultOk, mes, err_mes = GitOps.shell_command(
             ['git', 'clone', '-v', '--recurse-submodules', 
              self.__repo_url, self.__repo_dir]
              )
        if resultOk:
            print("Cloning ok")
        else:
            print(f"\nstdout= {mes}")
            print(f"\nstdout= {err_mes}")
        return resultOk
    
    def checkout(self):
        os.chdir(self.__repo_dir)
        print(f'Repo checkout current dir ...  {Path.cwd()}')
        resultOk, mes, err_mes = GitOps.shell_command(
            ['git', 'checkout', '-B', 'master', 'origin/master']
            )
        if resultOk:
            print("Checkout ok")
        else:
            print(f"\nstdout= {mes}")
            print(f"\nstdout= {err_mes}")
        return resultOk
    
    def add(self):
        os.chdir(self.__repo_dir)
        print(f'Repo adding current dir ...  {Path.cwd()}')
        resultOk, mes, err_mes = GitOps.shell_command(
            ['git', 'add', '.']
        )
        if resultOk:
            print("Add ok")
        else:
            print(f"\nstdout= {mes}")
            print(f"\nstdout= {err_mes}")
        return resultOk
    
    def commit(self):
        os.chdir(self.__repo_dir)
        print(f'Repo commiting current dir ...  {os.curdir}')
        ts = ''.join(
            ['"', filename_timestamp(datetime.now()), '"']
        )
        author = f'--author="{GitOps.GITLAB_USERNAME}<{GitOps.GITLAB_EMAIL}>"'
        resultOk, mes, err_mes = GitOps.shell_command(
            ['git', 'commit', '-m', ts, author]
        )
        if resultOk:
            print("Commit ok")
        else:
            print(f"\nstdout= {mes}")
            print(f"\nstdout= {err_mes}")
        return resultOk

    def push(self):
        os.chdir(self.__repo_dir)
        print(f'Repo pushing current dir ...  {os.curdir}')
        resultOk, mes, err_mes = GitOps.shell_command(
            ['git', 'push', self.__repo_url, '--all']
            )
        if resultOk:
            print("Push ok")
        else:
            print(f"\nstdout= {mes}")
            print(f"\nstdout= {err_mes}")
        return resultOk

# -----------------------------------------------------------------------------
if __name__ == "__main__": pass