namespace Shared.Transformations.pqsql;

public static class SocrBasePgSql
{
    public static string ModelName = "SocrBase";
    public static string ConnectionName = "KladrPgConnection";
    public static string TargetTableName = "socrbase_t";
    public static string TargetSchemaName = "public";
    public static string SQL = """
            SELECT level, scname, socrname, kod_t_st
            FROM public.socrbase
        """;
}

public static class AltNamesPgSql
{
    public static string ModelName = "AltNames";
    public static string ConnectionName = "KladrPgConnection";
    public static string TargetTableName = "altnames_t";
    public static string TargetSchemaName = "public";
    public static string SQL = """
            SELECT oldcode, newcode, level
            FROM public.altnames
        """;
}

public static class KladrPgSql
{
    public static string ModelName = "Kladr";
    public static string ConnectionName = "KladrPgConnection";
    public static string TargetTableName = "kladr_t";
    public static string TargetSchemaName = "kladr";
    public static string SQL = """
            SELECT code,
                   name,
                   socr,
                   index,
                   gninmb,
                   uno,
                   ocatd,
                   status
            FROM public.kladr
        """;
}

public static class StreetPgSql
{
    public static string ModelName = "Street";
    public static string ConnectionName = "KladrConnection";
    public static string TargetTableName = "street_t";
    public static string TargetSchemaName = "kladr";
    public static string SQL = """
            SELECT code,
                   name,
                   socr,
                   index,
                   gninmb,
                   uno,
                   ocatd
            FROM public.street
            LIMIT 100
        """;
}

public static class DomaPgSql
{
    public static string ModelName = "Doma";
    public static string ConnectionName = "KladrConnection";
    public static string TargetTableName = "doma_t";
    public static string TargetSchemaName = "kladr";
    public static string SQL = """
            SELECT code,
                   name,
                   korp,
                   socr,
                   index,
                   gninmb,
                   uno,
                   ocatd
            FROM public.doma
            LIMIT 100
        """;
}