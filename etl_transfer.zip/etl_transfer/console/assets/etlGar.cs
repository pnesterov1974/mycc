namespace Etl.gar;

public static class GarStringAssets
{
    public static string garFirst { get; set; } = string.Empty;
}