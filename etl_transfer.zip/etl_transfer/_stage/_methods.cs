
void ReadWritePgData()
{
    PgSqlData pgRead = new PgSqlData(PgSqlConnectionString, SocrBasePgSql.SQL);
    pgRead.Read();
    DataTable pgd = pgRead.Data;
    //WritePgSqlData pgWrite = new WritePgSqlData(PgSqlConnectionString, "public", "socrbase2", pgd);
    //{
    //    Data = pgd
    //};
    //pgWrite.Write();
}


// void TestMechMsSql()
// {
//     TransformObjectInfo toiKladr1 = new TransformObjectInfo
//     {
//         TargetSchemaName = Kladr1MsSql.TargetSchemaName,
//         TargetTableName = Kladr1MsSql.TargetTableName,
//         ConnectionString = MsSqlConnectionString,
//         SelectSql = Kladr1MsSql.SQL,

//     };
//     InsertIntoMsSql insKladr1 = new InsertIntoMsSql(toiKladr1);
//     insKladr1.InsertInto();

//     TransformObjectInfo toiStreet1 = new TransformObjectInfo
//     {
//         TargetSchemaName = Street1MsSql.TargetSchemaName,
//         TargetTableName = Street1MsSql.TargetTableName,
//         ConnectionString = MsSqlConnectionString,
//         SelectSql = Street1MsSql.SQL,

//     };
//     InsertIntoMsSql insStreet1 = new InsertIntoMsSql(toiStreet1);
//     insStreet1.InsertInto();

//     TransformObjectInfo toiDoma1 = new TransformObjectInfo
//     {
//         TargetSchemaName = Doma1MsSql.TargetSchemaName,
//         TargetTableName = Doma1MsSql.TargetTableName,
//         ConnectionString = MsSqlConnectionString,
//         SelectSql = Doma1MsSql.SQL,

//     };
//     InsertIntoMsSql insDoma1 = new InsertIntoMsSql(toiDoma1);
//     insDoma1.InsertInto();

// }
/*
void TestMechPgSql()
{
    TransformObjectInfo toiKladr1 = new TransformObjectInfo
    {
        TargetSchemaName = Kladr1PgSql.TargetSchemaName,
        TargetTableName = Kladr1PgSql.TargetTableName,
        ConnectionString = PgSqlConnectionString,
        SelectSql = Kladr1PgSql.SQL
    };
    InsertIntoPgSql inKladr1 = new InsertIntoPgSql(toiKladr1);
    inKladr1.InsertInto();

    TransformObjectInfo toiStreet1 = new TransformObjectInfo
    {
        TargetSchemaName = Street1PgSql.TargetSchemaName,
        TargetTableName = Street1PgSql.TargetTableName,
        ConnectionString = PgSqlConnectionString,
        SelectSql = Street1PgSql.SQL
    };
    InsertIntoPgSql inStreet1 = new InsertIntoPgSql(toiStreet1);
    inStreet1.InsertInto();

    TransformObjectInfo toiDoma1 = new TransformObjectInfo
    {
        TargetSchemaName = Doma1PgSql.TargetSchemaName,
        TargetTableName = Doma1PgSql.TargetTableName,
        ConnectionString = PgSqlConnectionString,
        SelectSql = Doma1PgSql.SQL
    };
    InsertIntoPgSql inDoma1 = new InsertIntoPgSql(toiDoma1);
    inDoma1.InsertInto();
}
*/