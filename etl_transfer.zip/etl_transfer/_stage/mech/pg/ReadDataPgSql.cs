using System.Data;
using Newtonsoft.Json;
using Npgsql;
using static Shared.MyLogger;
using Data;

namespace Data.mesh.pgsql;

public class PgSqlData: IDataForJson
{
    public DataTable Data { get; set; }
    protected string connectionString { get; set; } = string.Empty;
    protected string selectSql { get; set; } = string.Empty;

    public string AsJson
    { 
        get
        {
            this.Read(); // reread data
            return JsonConvert.SerializeObject(this.Data, Formatting.Indented);
        } 
    }

    public PgSqlData(string connectionString, string selectSql)
    {
        this.connectionString = connectionString;
        this.selectSql = selectSql;
    }

    public PgSqlData(string connectionString, string selectSql, bool readAtStart)
        : this(connectionString, selectSql)
    {
        if (readAtStart)
        {
            this.Read();
        }
    }

    public void Read()
    {
        Log.Information("Загрузка данных...");
        Log.Debug("Загрузка данных из : \n{connstr}", this.connectionString);
        Log.Debug("SQL : \n{connstr}", this.selectSql);
        this.Data = new DataTable();
        int RecordCount = 0;

        using var conn = new NpgsqlConnection(this.connectionString);
        conn.Open();
        NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(this.selectSql, conn);
        try
        {
            RecordCount = adapter.Fill(this.Data);
            Log.Information("Загружено {recorcount} записей", RecordCount);
        }
        catch (Exception ex)
        {
           Log.Debug("Ошибка чтения даннтых \n {errmes}", ex.Message);
        }
    }
}
