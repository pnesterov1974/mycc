using System.Data;
using System.Text;
using Newtonsoft.Json;
using static Shared.MyLogger;

namespace Datamech.pgsql
{
    public class DbStruRow
    {
        public int ColumnOrdinal { get; set; } = 0;
        public int ColumnSize { get; set; } = 0;
        public int NumericPrecision { get; set; } = 0;
        public int NumericScale { get; set; } = 0;
        public string DataTypeName { get; set; } = string.Empty;
    }

    public class DbStru
    {
        public Dictionary<string, DbStruRow> Rows { get; set; } = new Dictionary<string, DbStruRow>();
        public DbStru(DataTable sourceDataTable)
        {
            int ColumnNameColIdx = sourceDataTable.Columns["ColumnName"].Ordinal;
            int ColumnOrdinalColIdx = sourceDataTable.Columns["ColumnOrdinal"].Ordinal;
            int ColumnSizeColIdx = sourceDataTable.Columns["ColumnSize"].Ordinal;
            int NumericPrecisionColIdx = sourceDataTable.Columns["NumericPrecision"].Ordinal;
            int NumericScaleColIdx = sourceDataTable.Columns["NumericScale"].Ordinal;
            int DataTypeNameColIdx = sourceDataTable.Columns["DataTypeName"].Ordinal;

            foreach (DataRow dataRow in sourceDataTable.Rows)
            {
                string KeyColumnName = dataRow[ColumnNameColIdx].ToString();

                DbStruRow dbr = new DbStruRow
                {
                    ColumnOrdinal = (int)dataRow[ColumnOrdinalColIdx],
                    ColumnSize = (int)dataRow[ColumnSizeColIdx],
                    NumericPrecision = (int)dataRow[NumericPrecisionColIdx],
                    NumericScale = (int)dataRow[NumericScaleColIdx],
                    DataTypeName = dataRow[DataTypeNameColIdx].ToString()
                };
                Log.Information(
                    "ColumnName: {0} => ColumnOrdinal: {1}, ColumnSize: {2}, NumericPrecision: {3}, NumericScale: {4}, DataTypeName: {5}",
                    KeyColumnName, dbr.ColumnOrdinal, dbr.ColumnSize, dbr.NumericPrecision, dbr.NumericScale, dbr.DataTypeName
                );
                this.Rows.Add(KeyColumnName, dbr);
            }
        }
    }

    public class Sqls
    {
        public DbStru Dbs { get; set; }
        public string SelectSql;
        public Sqls(DataTable objectStruct, string selectSql)
        {
            this.Dbs = new DbStru(objectStruct);
            this.SelectSql = selectSql;
        }

        public void SerializeToJson(string filePath)
        {
            string serialized = JsonConvert.SerializeObject(this.Dbs, Formatting.Indented);
            File.WriteAllText(filePath, serialized);
        }

        public string GetCreateTableSql()
        {
            List<string> sqlRows = new List<string>();
            foreach (var kv in this.Dbs.Rows)
            {
                string colName = kv.Key;
                DbStruRow dbr = kv.Value;
                string item = string.Join(' ', "  ", colName, dbr.DataTypeName);
                sqlRows.Add(item);
            }

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("CREATE TABLE mytable (");
            sb.AppendLine(string.Join(",\n", sqlRows));
            sb.AppendLine(");\n");
            return sb.ToString();
        }

        public string GetInsertIntoValuesSql()
        {
            List<string> cols = new List<string>();
            List<string> paramValues = new List<string>();

            foreach (var k in this.Dbs.Rows.Keys)
            {
                cols.Add(k);
                paramValues.Add(string.Concat("@", k));
            }

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("INSERT INTO mytable (");
            sb.AppendLine(string.Join(", ", cols));
            sb.AppendLine(") VALUES (");
            sb.AppendLine(string.Join(", ", paramValues));
            sb.AppendLine(");");
            return sb.ToString();
        }

        public string GetInsertIntoSql()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("INSERT INTO mytable");
            sb.AppendLine(this.SelectSql);
            sb.AppendLine("\n");
            return sb.ToString();
        }

        // private void fieldListFromDataReader()
        // {
        //     int ColumnNameColIdx = this.objectStruct.Columns["BaseColumnName"].Ordinal;
        //     int DataTypeNameColIdx = this.objectStruct.Columns["DataTypeName"].Ordinal;
        //     int ColumnSizeColIdx = this.objectStruct.Columns["ColumnSize"].Ordinal;

        //     Dictionary<string, string> Fields = new Dictionary<string, string>();

        //     Log.Information("first: {col} second: {type}", ColumnNameColIdx, DataTypeNameColIdx);
        //     foreach (DataRow dataRow in this.objectStruct.Rows)
        //     {
        //         string columnName = dataRow[ColumnNameColIdx].ToString();
        //         string columnType = dataRow[DataTypeNameColIdx].ToString();
        //         string columnSize = dataRow[ColumnSizeColIdx].ToString();

        //         string columnTypeSized = string.Empty;

        //         if (columnType.Equals("varchar") || columnType.Equals("nvarchar"))
        //         {
        //             columnTypeSized = $"{columnType}({columnSize})";
        //         }
        //         else
        //         {
        //             columnTypeSized = columnType;
        //         }
        //         Fields.Add(columnName, columnTypeSized);
        //         Log.Debug("columnName: {col} columnType: {type}", columnName, columnTypeSized);
        //     }
        //     //return Fields;
        // }
    }
}