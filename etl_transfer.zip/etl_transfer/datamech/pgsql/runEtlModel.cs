using System.Data;
using static Shared.MyLogger;

namespace Datamech.pgsql
{
    public class RunModel
    {
        public IEtlModel EtlModel { get; set; }
        public Source Source { get; set; }
        public Target Target { get; set; }
        public Sqls Sqls { get; set; }

        public RunModel(IEtlModel etlModel)
        {
            this.EtlModel = etlModel;

            this.Source = new Source(parentModel: this);
            this.Target = new Target(parentModel: this);
            this.Sqls = new Sqls(parentModel: this);
            this.Target.ReadIfObjectExists();
            // -------------------
            //this.RunInsertInto();
        }

        public void Run()
        {
            this.Target.TouchObject(deleteIfExists: true);
            this.RunBatches(10000);
        }

        public void RunInsertInto()
        {
            this.Target.TouchObject(deleteIfExists: true);
            this.Target.RunInsertInto();
        }

        public void RunBatches(int batchSize=100000)
        {
            int rnnInitialFrom = 0;
            int rnnInitialTo = batchSize;
            int rnnFrom = 0;
            int rnnTo = 0;
            int iterCount = 0;
            int RecordsQueried = 0;
            do
            {
                iterCount += 1;
                if (iterCount == 1)
                {
                    rnnFrom = rnnInitialFrom + 1;
                    rnnTo = rnnInitialTo;
                }
                else
                {
                    rnnFrom = rnnTo + 1;
                    rnnTo = rnnTo + batchSize;
                }
                Log.Information("Итерация {iterCount} Диапазон по счетчику Rnn от {from} до {to}", iterCount, rnnFrom, rnnTo);
                DataTable dt = this.Source.ReadBatch(rnnFrom, rnnTo, out RecordsQueried);
            }
            while (RecordsQueried > 0);
        }
    }
}
