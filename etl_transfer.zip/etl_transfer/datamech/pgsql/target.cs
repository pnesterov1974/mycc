using System.Data;
using System.Text;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Datamech.pgsql
{
    public class Target
    {
        public string Name;
        public string SchemaName;
        public string TableName;
        public string FullName
        {
            get => string.Join('.', this.SchemaName, this.TableName);
        }
        private string connectionString;
        private bool connectionOk;
        private bool isObjectExists;
        public Target(string targetName, string targetSchemaName, string targetTableName)
        {
            this.SchemaName = targetSchemaName;
            this.TableName = targetTableName;
            Connections conns = new Connections(TargetDb.pgsql);
            this.connectionString = conns.GetConnectionStringByName(targetName);
            this.connectionOk = this.tryPgSqlDbConnection();
            this.isObjectExists = this.getIfObjectExists();
        }

        private bool tryPgSqlDbConnection()
        {
            Log.Information("Проверка подключения target по строке: {connString}", this.connectionString);
            try
            {
                using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    string connInfo = this.getPgSqlConnectionInformation(conn);
                    Log.Debug("Информация о соединении:\n {conn}", connInfo);
                    using (NpgsqlCommand cmd = new NpgsqlCommand("SELECT NOW();", conn))
                    {
                        cmd.CommandType = CommandType.Text;
                        var dt = cmd.ExecuteScalar();
                        Log.Information("Подключено успешно...{dt}", dt);
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Ошибка проверки подключения с Базе Данных:\n SQL:{message}", ex.Message);
                return false;
            }
        }

        private string getPgSqlConnectionInformation(NpgsqlConnection cnn)
        {
            StringBuilder sb = new StringBuilder(1024);

            sb.AppendLine("Connection String: " + cnn.ConnectionString);
            sb.AppendLine("State: " + cnn.State.ToString());
            sb.AppendLine("Connection Timeout: " + cnn.ConnectionTimeout.ToString());
            sb.AppendLine("Database: " + cnn.Database);
            sb.AppendLine("Data Source: " + cnn.DataSource);
            sb.AppendLine("Server Version: " + cnn.ServerVersion);

            return sb.ToString();
        }

        private bool getIfObjectExists()
        {
            //SELECT COUNT(1) as a FROM pg_class WHERE relname = 'mytable'
            //if a = 0 then (CREATE IT)

            string checkSql = $"""
                SELECT COUNT(1)::INT FROM information_schema.tables 
                WHERE table_schema = '{this.SchemaName}'
                      AND table_name = '{this.TableName}';
            """;
            Log.Information("Проверка, существует ли уже объект {t}", this.FullName);
            Log.Debug("checkSql:\n{checkSql}", checkSql);
            using (NpgsqlConnection conn = new NpgsqlConnection(this.connectionString))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(checkSql, conn))
                {
                    try
                    {
                        conn.Open();
                        var result = cmd.ExecuteScalar();
                        int iresult = (int)result;
                        Log.Debug("Результат проверки: result {r}", iresult);
                        if (iresult == 1)
                        {
                            Log.Information("Объект {t} существует", this.FullName);
                            return true;
                        }
                        else
                        {
                            Log.Information("Объект {t} не существует", this.FullName);
                            return false;
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Ощибка проверки существования объекта {t}\n", this.FullName);
                        Log.Debug("{errmes}", ex.Message);
                        return false;
                    }
                }
            }
        }

        private void dropObject()
        {
            string dropSql = $"DROP TABLE {this.FullName}";
            Log.Information("Удаление объекта {t}", this.FullName);
            Log.Debug("checkSql:\n{checkSql}", dropSql);
            using (NpgsqlConnection conn = new NpgsqlConnection(this.connectionString))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(dropSql, conn))
                {
                    try
                    {
                        conn.Open();
                        int result = cmd.ExecuteNonQuery();
                        Log.Debug("Результат выполнения: result {r}", result);
                        Log.Information("Объект {t} успешно удален", this.FullName);
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Ощибка удаления объекта {t}\n", this.FullName);
                        Log.Debug("{errmes}", ex.Message);
                    }
                }
            }
        }
    }
}
