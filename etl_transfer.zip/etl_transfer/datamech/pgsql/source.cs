using System.Data;
using System.Text;
using Npgsql;
using Shared;
using static Shared.MyLogger;

namespace Datamech.pgsql
{
    public class Source
    {
        public string Name;
        public string SelectSql;
        private string connectionString;
        private bool connectionOk;
        private DataTable sourceDbStru;
        private bool sourceDbStruOk
        {
            get => this.sourceDbStru != null;
        }

        public Source(string sourceName, string selectSql)
        {
            this.Name = sourceName;
            this.SelectSql = selectSql;
            Connections conns = new Connections(TargetDb.pgsql);
            this.connectionString = conns.GetConnectionStringByName(sourceName);
            this.connectionOk = this.tryPgSqlDbConnection();
            this.readSourceDBStru();
            if (this.sourceDbStruOk)
            {
                Sqls sqls = new Sqls(this.sourceDbStru, this.SelectSql);
                Log.Information(sqls.GetCreateTableSql());
                Log.Information(sqls.GetInsertIntoValuesSql());
                Log.Information(sqls.GetInsertIntoSql());
            }
        }

        private bool tryPgSqlDbConnection() // 1:1 c target
        {
            Log.Information("Проверка подключения source по строке: {connString}", this.connectionString);
            try
            {
                using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    string connInfo = this.getPgSqlConnectionInformation(conn);
                    Log.Debug("Информация о соединении:\n {conn}", connInfo);
                    using (NpgsqlCommand cmd = new NpgsqlCommand("SELECT NOW();", conn))
                    {
                        cmd.CommandType = CommandType.Text;
                        var dt = cmd.ExecuteScalar();
                        Log.Information("Подключено успешно...{dt}", dt);
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Ошибка проверки подключения с Базе Данных:\n SQL:{message}", ex.Message);
                return false;
            }
        }

        private string getPgSqlConnectionInformation(NpgsqlConnection cnn) // 1:1 c target
        {
            StringBuilder sb = new StringBuilder(1024);

            sb.AppendLine("Connection String: " + cnn.ConnectionString);
            sb.AppendLine("State: " + cnn.State.ToString());
            sb.AppendLine("Connection Timeout: " + cnn.ConnectionTimeout.ToString());
            sb.AppendLine("Database: " + cnn.Database);
            sb.AppendLine("Data Source: " + cnn.DataSource);
            sb.AppendLine("Server Version: " + cnn.ServerVersion);

            return sb.ToString();
        }

        private void readSourceDBStru() // Определение схемы НД источника, по которому можно сделать CREATE целевой объект
        {
            Log.Information("Загрузка схемы данных источника {source}", this.Name);
            Log.Debug("SQL:\n{sql}", this.SelectSql);

            this.sourceDbStru = new DataTable();
            using (NpgsqlConnection conn = new NpgsqlConnection(this.connectionString))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(this.SelectSql, conn))
                {
                    cmd.CommandTimeout = 100000;
                    try
                    {
                        conn.Open();
                        using (NpgsqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.KeyInfo))
                        {
                            this.sourceDbStru = rdr.GetSchemaTable();
                            Log.Information("Схема данных успешно загружена");
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Ошибка загрузки схемы данных.");
                        Log.Debug("{errmes}", ex.Message);
                        this.sourceDbStru = null;
                    }
                }
            }
        }
    }
}