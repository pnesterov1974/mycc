using System.Data;
using static Shared.MyLogger;

namespace Datamech.pgsql
{
    public class RunModel
    {
        public IEtlModel EtlModel;
        private DataTable sourceStru;
        private string sourceConnectionString;
        private bool SourceAndTargetSameConnection = false;
        private bool sourceConnectionOk = false;
        private bool targetConnectionOk = false;
        private bool isTargetObjectExists = false;
        private string targetConnectionString;
        public RunModel(IEtlModel etlModel)
        { // try-finally
            this.EtlModel = etlModel;
            Target t = new Target(
                targetName: this.EtlModel.TargetName,
                targetSchemaName: this.EtlModel.TargetSchemaName,
                targetTableName: this.EtlModel.TargetTableName
            );
            Source s = new Source(
                sourceName: this.EtlModel.SourceName,
                selectSql: this.EtlModel.SourceSql
            );  
        }
    }
}
