using Newtonsoft.Json;
//using System.Xml.Serialization;
using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;

namespace Datamech
{
    public interface IEtlModel
    {
        string ModelName { get; set; }
        string SourceName { get; set; }
        string TargetName { get; set; }
        string SourceSql { get; set; }
        string TargetTableName { get; set; }
        string TargetSchemaName { get; set; }
        string SerializedJsonFileName { get; }
        string SerializedYamlFileName { get; }
        string SerializedXmlFileName { get; }
        string TargetTableFullName { get; }
    }

    public class EtlModelBase
    {
        public virtual string ModelName { get; set; } = string.Empty;
        public virtual string TargetTableName { get; set; } = string.Empty;
        public virtual string TargetSchemaName { get; set; } = string.Empty;
        public string SerializedJsonFileName
        {
            get => Path.Combine(Directory.GetCurrentDirectory(), "models", String.Join('.', this.ModelName, "json"));
        }
        public string SerializedYamlFileName
        {
            get => Path.Combine(Directory.GetCurrentDirectory(), "models", String.Join('.', this.ModelName, "yaml"));
        }
        public string SerializedXmlFileName
        {
            get => Path.Combine(Directory.GetCurrentDirectory(), "models", String.Join('.', this.ModelName, "xml"));
        }
        public string TargetTableFullName
        {
            get => string.Join('.', this.TargetSchemaName, this.TargetTableName);
        }
    }

    public class Serializator
    {
        public IEtlModel EtlModel;
        public Serializator(IEtlModel etlModel) => this.EtlModel = etlModel;
        public void SerializeToJson()
        {
            string serialized = JsonConvert.SerializeObject(this.EtlModel, Formatting.Indented);
            File.WriteAllText(this.EtlModel.SerializedJsonFileName, serialized);
        }
        public void SerializeToYaml()
        {
            var serializer = new SerializerBuilder()
                .WithNamingConvention(CamelCaseNamingConvention.Instance)
                .Build();
            var yaml = serializer.Serialize(this.EtlModel);
            File.WriteAllText(this.EtlModel.SerializedYamlFileName, yaml);
        }
        public void SerializeToXml()
        {
            //XmlSerializer xmlSerializer = new XmlSerializer(typeof(this.EtlModel));
            //using (FileStream fs = new FileStream(this.EtlModel.SerializedXmlFileName, FileMode.OpenOrCreate))
            //{
            //    xmlSerializer.Serialize(fs, this.EtlModel);
            //    Console.WriteLine("Object model1 has been serialized in XML");
            //}
            ;
        }
    }
}