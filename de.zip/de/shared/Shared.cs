﻿namespace shared;

public class Shared
{

}
