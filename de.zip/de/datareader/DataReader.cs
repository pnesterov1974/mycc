﻿namespace datareader;

public class DataReader
{

}
