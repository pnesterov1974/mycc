﻿namespace datamesh;

public class datamesh
{

}
